// API service layer for Invoice Processing System

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || '/api';

// Types based on API response
export interface DashboardStatistics {
  total_invoices: number;
  processed_count: number;
  pending_count: number;
  failed_count: number;
  total_amount: number;
}

export interface RecentInvoice {
  invoice_id: number;
  invoice_number: string;
  store_name: string;
  total_amount: number;
  status: 'uploaded' | 'processing' | 'completed' | 'failed';
  upload_time: string;
  processed_time: string | null;
}

export interface Invoice {
  invoice_id: number;
  invoice_number: string;
  invoice_date: string | null;
  store_name: string;
  store_address: string;
  total_amount: number;
  status: 'uploaded' | 'processing' | 'completed' | 'failed';
  upload_time: string;
  processed_time: string | null;
  uploaded_by: number;
  original_file_name?: string;
  file_type?: string;
  file_path?: string;
  accuracy?: number;
}

export interface User {
  user_id: number;
  username: string;
  email: string;
  role: string;
  created_at: string;
  full_name?: string;
  password_hash?: string;
  is_active?: boolean;
}

export interface InvoiceItem {
  item_id: number;
  invoice_id: number;
  product_name: string;
  quantity: number;
  unit_price: number;
  total_price: number;
}

export interface InvoiceLog {
  log_id: number;
  invoice_id: number;
  message: string;
  step: string;
  status: string;
  timestamp: string;
}

export interface DashboardSummaryResponse {
  success: boolean;
  data: {
    statistics: DashboardStatistics;
    recent_invoices: RecentInvoice[];
    pagination: {
      limit: number;
      offset: number;
      total: number;
    };
  };
}

export interface InvoicesListResponse {
  success: boolean;
  data: {
    invoices: Invoice[];
    pagination: {
      limit: number;
      offset: number;
      total: number;
      has_next: boolean;
      has_prev: boolean;
    };
    filters: {
      query: string | null;
      status: string | null;
    };
  };
}

export interface InvoiceDetailResponse {
  success: boolean;
  data: {
    invoice: Invoice & {
      items?: InvoiceItem[];
    };
    logs: InvoiceLog[];
  };
}

export interface UserInvoicesResponse {
  success: boolean;
  data: {
    invoices: Invoice[];
    total: number;
    limit: number;
    offset: number;
  };
}

export interface InvoiceFilters {
  search?: string;
  status?: string;
  store?: string[];
  dateFrom?: string;
  dateTo?: string;
  minAmount?: number;
  maxAmount?: number;
  minAccuracy?: number;
  page: number;
  limit: number;
}

export interface UploadResponse {
  success: boolean;
  message: string;
  data: {
    invoice_id: number;
    status: string;
    file_path: string;
    [key: string]: any;
  };
}

export interface ExtractResponse {
  success: boolean;
  message: string;
  data: {
    invoice_id: number;
    processing_results: {
      docunet: {
        detected_regions: Array<{
          type: string;
          text: string;
          confidence: number;
        }>;
        processing_time: number;
      };
      paddle_ocr: {
        text_lines: Array<{
          text: string;
          confidence: number;
          bbox: number[];
        }>;
        processing_time: number;
      };
      schema_parsing: {
        extracted_info: {
          store_name?: string;
          store_address?: string;
          total_amount?: number;
          items?: Array<{
            product_name: string;
            quantity: number;
            unit_price: number;
            total_price: number;
          }>;
        };
      };
    };
  };
}

export interface ProcessResponse {
  success: boolean;
  message: string;
  data: {
    invoice_id: number;
    docunet_result: {
      detected_regions: Array<{
        type: string;
        text: string;
        confidence: number;
      }>;
      processing_time: number;
    };
    paddle_result: {
      text_lines: Array<{
        text: string;
        confidence: number;
        bbox: number[];
      }>;
      processing_time: number;
    };
    extracted_info: {
      store_name?: string;
      store_address?: string;
      total_amount?: number;
      items_count?: number;
    };
  };
}

export interface HealthCheckResponse {
  status: 'healthy' | 'unhealthy';
  database: {
    status: 'healthy' | 'unhealthy';
    [key: string]: any;
  };
  timestamp: string;
  version: string;
  service: string;
}

// API client class
class ApiClient {
  private baseURL: string;

  constructor(baseURL: string = API_BASE_URL) {
    this.baseURL = baseURL;
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    const url = `${this.baseURL}${endpoint}`;
    
    const config: RequestInit = {
      mode: 'cors',
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    };

    console.log(`Making API request to: ${url}`);
    
    try {
      const response = await fetch(url, config);
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error(`HTTP error! status: ${response.status}, response: ${errorText}`);
        throw new Error(`HTTP error! status: ${response.status} - ${errorText}`);
      }
      
      const data = await response.json();
      console.log(`API response from ${url}:`, data);
      return data;
    } catch (error) {
      console.error(`API request failed: ${url}`, error);
      
      // Check if it's a network error
      if (error instanceof TypeError && error.message.includes('fetch')) {
        throw new Error(`Network error: Unable to connect to API server at ${this.baseURL}. Please check if the server is running.`);
      }
      
      throw error;
    }
  }

  // Health check
  async healthCheck(): Promise<HealthCheckResponse> {
    return this.request<HealthCheckResponse>('/health');
  }

  // Dashboard endpoints
  async getDashboardSummary(
    limit: number = 10,
    offset: number = 0
  ): Promise<DashboardSummaryResponse> {
    return this.request<DashboardSummaryResponse>(
      `/dashboard/summary?limit=${limit}&offset=${offset}`
    );
  }

  // Invoice endpoints
  async uploadInvoice(
    file: File,
    options: {
      uploaded_by?: number;
      vendor?: string;
      invoice_date?: string;
    } = {}
  ): Promise<UploadResponse> {
    const formData = new FormData();
    formData.append('file', file);
    
    if (options.uploaded_by) {
      formData.append('uploaded_by', options.uploaded_by.toString());
    }
    if (options.vendor) {
      formData.append('vendor', options.vendor);
    }
    if (options.invoice_date) {
      formData.append('invoice_date', options.invoice_date);
    }

    return this.request('/invoices/upload', {
      method: 'POST',
      headers: {}, // Remove Content-Type to let browser set it for FormData
      body: formData,
    });
  }

  async getInvoice(invoiceId: number): Promise<InvoiceDetailResponse> {
    return this.request<InvoiceDetailResponse>(`/invoices/${invoiceId}`);
  }

  async getUserInvoices(
    userId: number,
    limit: number = 50,
    offset: number = 0
  ): Promise<UserInvoicesResponse> {
    return this.request<UserInvoicesResponse>(
      `/users/${userId}/invoices?limit=${limit}&offset=${offset}`
    );
  }

  async listInvoices(
    query?: string,
    status?: string,
    limit: number = 10,
    offset: number = 0
  ): Promise<InvoicesListResponse> {
    const params = new URLSearchParams();
    if (query) params.append('query', query);
    if (status) params.append('status', status);
    params.append('limit', limit.toString());
    params.append('offset', offset.toString());

    return this.request<InvoicesListResponse>(`/invoices?${params.toString()}`);
  }

  async extractInvoice(
    file: File,
    uploadedBy: number = 1
  ): Promise<ExtractResponse> {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('uploaded_by', uploadedBy.toString());

    return this.request('/invoices/extract', {
      method: 'POST',
      headers: {}, // Remove Content-Type to let browser set it for FormData
      body: formData,
    });
  }

  async processInvoice(invoiceId: number): Promise<ProcessResponse> {
    return this.request<ProcessResponse>(`/invoices/${invoiceId}/process`, {
      method: 'POST',
    });
  }

  // User endpoints
  async createUser(
    username: string,
    email: string,
    password: string,
    role: string = 'user',
    full_name?: string
  ): Promise<{ success: boolean; data: User; message: string }> {
    return this.request('/users', {
      method: 'POST',
      body: JSON.stringify({
        username,
        email,
        password_hash: password, // API expects password_hash
        role,
        full_name,
      }),
    });
  }

  async getUser(userId: number): Promise<{ success: boolean; data: User }> {
    return this.request<{ success: boolean; data: User }>(`/users/${userId}`);
  }

  // Invoice logs
  async createInvoiceLog(
    invoiceId: number,
    message: string,
    step: string,
    status: string = 'info'
  ): Promise<{ success: boolean; message: string; data: InvoiceLog }> {
    return this.request(`/invoices/${invoiceId}/logs`, {
      method: 'POST',
      body: JSON.stringify({
        message,
        step,
        status,
      }),
    });
  }
}

// Export singleton instance
export const apiClient = new ApiClient();

// Convenience functions
export const dashboardApi = {
  getSummary: (limit?: number, offset?: number) => 
    apiClient.getDashboardSummary(limit, offset),
  
  healthCheck: () => 
    apiClient.healthCheck(),
};

export const invoiceApi = {
  upload: (file: File, options?: Parameters<typeof apiClient.uploadInvoice>[1]) =>
    apiClient.uploadInvoice(file, options),
  
  extract: (file: File, uploadedBy?: number) =>
    apiClient.extractInvoice(file, uploadedBy),
  
  process: (invoiceId: number) =>
    apiClient.processInvoice(invoiceId),
  
  getById: (invoiceId: number) =>
    apiClient.getInvoice(invoiceId),
  
  list: (query?: string, status?: string, limit?: number, offset?: number) =>
    apiClient.listInvoices(query, status, limit, offset),
  
  getUserInvoices: (userId: number, limit?: number, offset?: number) =>
    apiClient.getUserInvoices(userId, limit, offset),
  
  addLog: (invoiceId: number, message: string, step: string, status?: string) =>
    apiClient.createInvoiceLog(invoiceId, message, step, status),
};

export const userApi = {
  create: (username: string, email: string, password: string, role?: string, full_name?: string) =>
    apiClient.createUser(username, email, password, role, full_name),
  
  getById: (userId: number) =>
    apiClient.getUser(userId),
};