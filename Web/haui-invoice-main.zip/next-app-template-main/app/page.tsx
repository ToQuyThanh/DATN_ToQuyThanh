import { AppShellLayout } from '@/components/AppShell/AppShell';

export default function HomePage() {
  return <AppShellLayout />;
}
