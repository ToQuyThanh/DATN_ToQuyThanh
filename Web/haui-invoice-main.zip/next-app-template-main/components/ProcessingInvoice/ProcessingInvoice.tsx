'use client';

import { useState, useEffect } from 'react';
import {
  Stack,
  Text,
  Card,
  Group,
  Progress,
  Badge,
  Grid,
  Timeline,
  ThemeIcon,
  Alert,
  Button,
  Table,
  ScrollArea,
  ActionIcon,
  Modal,
  JsonInput,
  Tabs,
  Image,
  Center,
  Loader,
  Select,
} from '@mantine/core';
import { useDisclosure } from '@mantine/hooks';
import { notifications } from '@mantine/notifications';
import {
  IconCheck,
  IconClock,
  IconX,
  IconAlertTriangle,
  IconEye,
  IconRefresh,
  IconFileText,
  IconBrain,
  IconDatabase,
  IconCloudUpload,
  IconScan,
  IconRobot,
} from '@tabler/icons-react';
import { invoiceApi, Invoice } from '../../lib/api';

interface ProcessingStep {
  id: string;
  title: string;
  description: string;
  status: 'pending' | 'processing' | 'completed' | 'error';
  progress: number;
  duration?: number;
  error?: string;
  icon: any;
}

interface ProcessingJob {
  id: string;
  fileName: string;
  fileSize: string;
  uploadTime: string;
  status: 'queued' | 'processing' | 'completed' | 'error';
  progress: number;
  steps: ProcessingStep[];
  result?: {
    accuracy: number;
    extractedData: any;
    confidence: number;
    warnings: string[];
  };
  error?: string;
}

const initialSteps: ProcessingStep[] = [
  {
    id: 'upload',
    title: 'Tải lên file',
    description: 'Kiểm tra định dạng và kích thước file',
    status: 'pending',
    progress: 0,
    icon: IconCloudUpload,
  },
  {
    id: 'preprocess',
    title: 'Tiền xử lý',
    description: 'Chuẩn hóa và tối ưu hóa hình ảnh',
    status: 'pending',
    progress: 0,
    icon: IconScan,
  },
  {
    id: 'docunet',
    title: 'DocUnet',
    description: 'Phân đoạn và nhận dạng cấu trúc tài liệu',
    status: 'pending',
    progress: 0,
    icon: IconBrain,
  },
  {
    id: 'ocr',
    title: 'PaddleOCR',
    description: 'Trích xuất văn bản từ hình ảnh',
    status: 'pending',
    progress: 0,
    icon: IconRobot,
  },
  {
    id: 'postprocess',
    title: 'Hậu xử lý',
    description: 'Chuẩn hóa và xác thực dữ liệu',
    status: 'pending',
    progress: 0,
    icon: IconFileText,
  },
  {
    id: 'save',
    title: 'Lưu trữ',
    description: 'Lưu kết quả vào cơ sở dữ liệu',
    status: 'pending',
    progress: 0,
    icon: IconDatabase,
  },
];

export function ProcessingInvoice() {
  const [jobs, setJobs] = useState<ProcessingJob[]>([]);
  const [selectedJob, setSelectedJob] = useState<ProcessingJob | null>(null);
  const [detailOpened, { open: openDetail, close: closeDetail }] = useDisclosure(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<string | undefined>(undefined);

  // Update job status and log to database
  const updateJobStatus = async (jobId: string, newStatus: string, step: string, message: string) => {
    try {
      // Log the status change
      await invoiceApi.addLog(Number(jobId), message, step, 'info');
      
      // Refresh the jobs list to reflect changes
      fetchProcessingJobs();
    } catch (err) {
      console.error('Failed to update job status:', err);
      notifications.show({
        title: 'Lỗi',
        message: 'Không thể cập nhật trạng thái công việc',
        color: 'red',
      });
    }
  };

  // Fetch processing jobs from API
  const fetchProcessingJobs = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await invoiceApi.list(undefined, statusFilter, 50, 0);
      // Convert Invoice[] to ProcessingJob[]
      const processingJobs: ProcessingJob[] = response.data.invoices.map((invoice, index) => ({
        id: invoice.invoice_id.toString(),
        fileName: invoice.original_file_name || `invoice_${invoice.invoice_id}`,
        fileSize: '2.5 MB', // Default size since not available in API
        uploadTime: invoice.upload_time,
        status: invoice.status === 'uploaded' ? 'queued' : 
                invoice.status === 'processing' ? 'processing' :
                invoice.status === 'completed' ? 'completed' : 'error',
        progress: invoice.status === 'completed' ? 100 : 
                 invoice.status === 'processing' ? 50 : 
                 invoice.status === 'failed' ? 0 : 25,
        steps: initialSteps.map(step => ({
          ...step,
          status: invoice.status === 'completed' ? 'completed' :
                 invoice.status === 'processing' ? (step.id === 'upload' ? 'completed' : 'pending') :
                 invoice.status === 'failed' ? 'error' : 'pending'
        })),
        result: invoice.accuracy ? {
          accuracy: invoice.accuracy,
          extractedData: {},
          confidence: invoice.accuracy,
          warnings: []
        } : undefined
      }));
      setJobs(processingJobs);
    } catch (err) {
      setError('Không thể tải danh sách công việc xử lý');
      notifications.show({
        title: 'Lỗi',
        message: 'Không thể tải danh sách công việc xử lý',
        color: 'red',
      });
    } finally {
      setLoading(false);
    }
  };

  // Retry a failed job
  const retryJob = async (jobId: string) => {
    try {
      // Log the retry action
      await invoiceApi.addLog(Number(jobId), 'Khởi động lại xử lý hóa đơn', 'retry', 'info');
      
      await invoiceApi.process(Number(jobId));
      
      // Log successful retry
      await invoiceApi.addLog(Number(jobId), 'Đã khởi động lại xử lý thành công', 'retry_success', 'info');
      
      notifications.show({
        title: 'Thành công',
        message: 'Đã khởi động lại công việc xử lý',
        color: 'green',
      });
      fetchProcessingJobs(); // Refresh the list
    } catch (err) {
      // Log failed retry
      await invoiceApi.addLog(Number(jobId), `Lỗi khởi động lại: ${err}`, 'retry_error', 'error');
      
      notifications.show({
        title: 'Lỗi',
        message: 'Không thể khởi động lại công việc',
        color: 'red',
      });
    }
  };

  // Cancel a job
  const cancelJob = async (jobId: string) => {
    try {
      // TODO: Implement cancel functionality when API is available
      // await invoiceApi.cancel(Number(jobId));
      notifications.show({
        title: 'Thông báo',
        message: 'Chức năng hủy công việc chưa được hỗ trợ',
        color: 'yellow',
      });
      // fetchProcessingJobs(); // Refresh the list
    } catch (err) {
      notifications.show({
        title: 'Lỗi',
        message: 'Không thể hủy công việc',
        color: 'red',
      });
    }
  };

  // Get job details
  const getJobDetails = async (jobId: string) => {
    try {
      const response = await invoiceApi.getById(Number(jobId));
      const invoice = response.data.invoice;
      // Convert Invoice to ProcessingJob for display
      const jobDetails: ProcessingJob = {
        id: invoice.invoice_id.toString(),
        fileName: invoice.original_file_name || `invoice_${invoice.invoice_id}`,
        fileSize: '2.5 MB',
        uploadTime: invoice.upload_time,
        status: invoice.status === 'uploaded' ? 'queued' : 
                invoice.status === 'processing' ? 'processing' :
                invoice.status === 'completed' ? 'completed' : 'error',
        progress: invoice.status === 'completed' ? 100 : 
                 invoice.status === 'processing' ? 50 : 
                 invoice.status === 'failed' ? 0 : 25,
        steps: initialSteps.map(step => ({
          ...step,
          status: invoice.status === 'completed' ? 'completed' :
                 invoice.status === 'processing' ? (step.id === 'upload' ? 'completed' : 'pending') :
                 invoice.status === 'failed' ? 'error' : 'pending'
        })),
        result: invoice.accuracy ? {
          accuracy: invoice.accuracy,
          extractedData: {},
          confidence: invoice.accuracy,
          warnings: []
        } : undefined
      };
      setSelectedJob(jobDetails);
      openDetail();
    } catch (err) {
      notifications.show({
        title: 'Lỗi',
        message: 'Không thể tải chi tiết công việc',
        color: 'red',
      });
    }
  };

  // Initial load and real-time updates
  useEffect(() => {
    fetchProcessingJobs();

    // Set up real-time updates
    const interval = setInterval(() => {
      fetchProcessingJobs();
    }, 5000); // Refresh every 5 seconds

    return () => clearInterval(interval);
  }, [statusFilter]);

  const getStatusBadge = (status: ProcessingJob['status']) => {
    const statusConfig = {
      queued: { color: 'gray', label: 'Đang chờ' },
      processing: { color: 'orange', label: 'Đang xử lý' },
      completed: { color: 'green', label: 'Hoàn thành' },
      error: { color: 'red', label: 'Lỗi' },
    };
    
    const config = statusConfig[status];
    return <Badge color={config.color} variant="light">{config.label}</Badge>;
  };

  const getStepIcon = (step: ProcessingStep) => {
    if (step.status === 'completed') return <IconCheck size="1rem" />;
    if (step.status === 'error') return <IconX size="1rem" />;
    if (step.status === 'processing') return <Loader size="1rem" />;
    return <IconClock size="1rem" />;
  };

  const getStepColor = (status: ProcessingStep['status']) => {
    switch (status) {
      case 'completed': return 'green';
      case 'error': return 'red';
      case 'processing': return 'blue';
      default: return 'gray';
    }
  };



  const jobRows = jobs.map((job) => (
    <Table.Tr key={job.id}>
      <Table.Td>
        <div>
          <Text size="sm" fw={500}>
            {job.fileName}
          </Text>
          <Text size="xs" c="dimmed">
            {job.fileSize} • {job.uploadTime}
          </Text>
        </div>
      </Table.Td>
      <Table.Td>
        {getStatusBadge(job.status)}
      </Table.Td>
      <Table.Td>
        <Group gap="xs">
          <Progress
            value={job.progress}
            size="sm"
            style={{ flex: 1 }}
            color={job.status === 'error' ? 'red' : 'blue'}
          />
          <Text size="xs" c="dimmed">
            {Math.round(job.progress)}%
          </Text>
        </Group>
      </Table.Td>
      <Table.Td>
        {job.result && (
          <Text size="sm" fw={500}>
            {job.result.accuracy}%
          </Text>
        )}
        {job.error && (
          <Text size="sm" c="red">
            Lỗi
          </Text>
        )}
      </Table.Td>
      <Table.Td>
        <Group gap="xs">
          <ActionIcon
            variant="light"
            size="sm"
            onClick={() => getJobDetails(job.id)}
          >
            <IconEye size="0.8rem" />
          </ActionIcon>
          {job.status === 'error' && (
            <ActionIcon
              variant="light"
              color="blue"
              size="sm"
              onClick={() => retryJob(job.id)}
            >
              <IconRefresh size="0.8rem" />
            </ActionIcon>
          )}
        </Group>
      </Table.Td>
    </Table.Tr>
  ));

  const processingCount = jobs.filter((job) => job.status === 'processing').length;
  const completedCount = jobs.filter((job) => job.status === 'completed').length;
  const errorCount = jobs.filter((job) => job.status === 'error').length;
  const queuedCount = jobs.filter((job) => job.status === 'queued').length;

  return (
    <Stack gap="lg">
      {/* Header */}
      <Group justify="space-between">
        <div>
          <Text size="xl" fw={700}>
            Xử lý hóa đơn
          </Text>
          <Text c="dimmed" size="sm">
            Theo dõi quá trình xử lý và trích xuất thông tin
          </Text>
        </div>
        <Group>
          <Select
            placeholder="Lọc theo trạng thái"
            value={statusFilter}
            onChange={(value) => setStatusFilter(value || undefined)}
            data={[
              { value: '', label: 'Tất cả' },
              { value: 'uploaded', label: 'Đang chờ' },
              { value: 'processing', label: 'Đang xử lý' },
              { value: 'completed', label: 'Hoàn thành' },
              { value: 'failed', label: 'Lỗi' },
            ]}
            clearable
            w={200}
          />
          <Button
            variant="light"
            leftSection={<IconRefresh size="1rem" />}
            onClick={fetchProcessingJobs}
            loading={loading}
          >
            Làm mới
          </Button>
        </Group>
      </Group>

      {/* Loading State */}
      {loading && jobs.length === 0 && (
        <Center py="xl">
          <Loader size="lg" />
        </Center>
      )}

      {/* Error State */}
      {error && (
        <Alert
          icon={<IconAlertTriangle size="1rem" />}
          title="Lỗi tải dữ liệu"
          color="red"
          withCloseButton
          onClose={() => setError(null)}
        >
          {error}
          <Button
            variant="light"
            size="xs"
            mt="sm"
            onClick={fetchProcessingJobs}
          >
            Thử lại
          </Button>
        </Alert>
      )}

      {/* Stats Cards */}
      {!loading && !error && (
        <Grid>
          <Grid.Col span={{ base: 6, sm: 3 }}>
            <Card withBorder p="md" radius="md">
              <Group justify="space-between">
                <div>
                  <Text c="dimmed" size="sm">Đang chờ</Text>
                  <Text fw={700} size="xl">{queuedCount}</Text>
                </div>
                <ThemeIcon color="gray" variant="light" size="xl">
                  <IconClock size="1.5rem" />
                </ThemeIcon>
              </Group>
            </Card>
          </Grid.Col>
          <Grid.Col span={{ base: 6, sm: 3 }}>
            <Card withBorder p="md" radius="md">
              <Group justify="space-between">
                <div>
                  <Text c="dimmed" size="sm">Đang xử lý</Text>
                  <Text fw={700} size="xl">{processingCount}</Text>
                </div>
                <ThemeIcon color="orange" variant="light" size="xl">
                  <Loader size="1.5rem" />
                </ThemeIcon>
              </Group>
            </Card>
          </Grid.Col>
          <Grid.Col span={{ base: 6, sm: 3 }}>
            <Card withBorder p="md" radius="md">
              <Group justify="space-between">
                <div>
                  <Text c="dimmed" size="sm">Hoàn thành</Text>
                  <Text fw={700} size="xl">{completedCount}</Text>
                </div>
                <ThemeIcon color="green" variant="light" size="xl">
                  <IconCheck size="1.5rem" />
                </ThemeIcon>
              </Group>
            </Card>
          </Grid.Col>
          <Grid.Col span={{ base: 6, sm: 3 }}>
            <Card withBorder p="md" radius="md">
              <Group justify="space-between">
                <div>
                  <Text c="dimmed" size="sm">Lỗi</Text>
                  <Text fw={700} size="xl">{errorCount}</Text>
                </div>
                <ThemeIcon color="red" variant="light" size="xl">
                  <IconX size="1.5rem" />
                </ThemeIcon>
              </Group>
            </Card>
          </Grid.Col>
        </Grid>
      )}

      {/* Processing Jobs Table */}
      {!loading && !error && (
        <Card withBorder p="lg" radius="md">
          <Group justify="space-between" mb="md">
            <Text fw={600} size="lg">
              Danh sách công việc
            </Text>
            <Badge variant="light">
              {jobs.length} công việc
            </Badge>
          </Group>
          
          {jobs.length === 0 ? (
            <Center py="xl">
              <Text c="dimmed">Không có công việc xử lý nào</Text>
            </Center>
          ) : (
            <ScrollArea>
              <Table verticalSpacing="sm">
                <Table.Thead>
                  <Table.Tr>
                    <Table.Th>File</Table.Th>
                    <Table.Th>Trạng thái</Table.Th>
                    <Table.Th>Tiến độ</Table.Th>
                    <Table.Th>Độ chính xác</Table.Th>
                    <Table.Th>Thao tác</Table.Th>
                  </Table.Tr>
                </Table.Thead>
                <Table.Tbody>{jobRows}</Table.Tbody>
              </Table>
            </ScrollArea>
          )}
        </Card>
      )}

      {/* Processing Steps for Active Job */}
      {processingCount > 0 && (
        <Card withBorder p="lg" radius="md">
          <Text fw={600} size="lg" mb="md">
            Chi tiết xử lý
          </Text>
          
          {jobs
            .filter((job) => job.status === 'processing')
            .map((job) => (
              <div key={job.id}>
                <Group mb="md">
                  <Text fw={500}>{job.fileName}</Text>
                  <Progress value={job.progress} style={{ flex: 1 }} />
                  <Text size="sm" c="dimmed">{Math.round(job.progress)}%</Text>
                </Group>
                
                <Timeline active={job.steps.findIndex((step) => step.status === 'processing')} bulletSize={24} lineWidth={2}>
                  {job.steps.map((step, index) => (
                    <Timeline.Item
                      key={step.id}
                      bullet={
                        <ThemeIcon color={getStepColor(step.status)} size={24} radius="xl">
                          {getStepIcon(step)}
                        </ThemeIcon>
                      }
                      title={step.title}
                    >
                      <Text c="dimmed" size="sm">
                        {step.description}
                      </Text>
                      {step.status === 'processing' && (
                        <Progress value={step.progress} size="xs" mt="xs" />
                      )}
                      {step.error && (
                        <Alert icon={<IconAlertTriangle size="1rem" />} color="red" mt="xs">
                          {step.error}
                        </Alert>
                      )}
                    </Timeline.Item>
                  ))}
                </Timeline>
              </div>
            ))}
        </Card>
      )}

      {/* Job Detail Modal */}
      <Modal
        opened={detailOpened}
        onClose={closeDetail}
        title={`Chi tiết: ${selectedJob?.fileName}`}
        size="xl"
      >
        {selectedJob && (
          <Tabs defaultValue="overview">
            <Tabs.List>
              <Tabs.Tab value="overview">Tổng quan</Tabs.Tab>
              <Tabs.Tab value="steps">Các bước xử lý</Tabs.Tab>
              {selectedJob.result && <Tabs.Tab value="result">Kết quả</Tabs.Tab>}
            </Tabs.List>

            <Tabs.Panel value="overview" pt="md">
              <Stack gap="md">
                <Group>
                  <Text fw={500}>Trạng thái:</Text>
                  {getStatusBadge(selectedJob.status)}
                </Group>
                <Group>
                  <Text fw={500}>Tiến độ:</Text>
                  <Progress value={selectedJob.progress} style={{ flex: 1 }} />
                  <Text>{Math.round(selectedJob.progress)}%</Text>
                </Group>
                <Group>
                  <Text fw={500}>Kích thước:</Text>
                  <Text>{selectedJob.fileSize}</Text>
                </Group>
                <Group>
                  <Text fw={500}>Thời gian upload:</Text>
                  <Text>{selectedJob.uploadTime}</Text>
                </Group>
                {selectedJob.error && (
                  <Alert icon={<IconAlertTriangle size="1rem" />} color="red">
                    {selectedJob.error}
                  </Alert>
                )}
              </Stack>
            </Tabs.Panel>

            <Tabs.Panel value="steps" pt="md">
              <Timeline active={-1} bulletSize={24} lineWidth={2}>
                {selectedJob.steps.map((step) => (
                  <Timeline.Item
                    key={step.id}
                    bullet={
                      <ThemeIcon color={getStepColor(step.status)} size={24} radius="xl">
                        {getStepIcon(step)}
                      </ThemeIcon>
                    }
                    title={step.title}
                  >
                    <Text c="dimmed" size="sm">
                      {step.description}
                    </Text>
                    <Progress value={step.progress} size="xs" mt="xs" />
                    {step.error && (
                      <Alert icon={<IconAlertTriangle size="1rem" />} color="red" mt="xs">
                        {step.error}
                      </Alert>
                    )}
                  </Timeline.Item>
                ))}
              </Timeline>
            </Tabs.Panel>

            {selectedJob.result && (
              <Tabs.Panel value="result" pt="md">
                <Stack gap="md">
                  <Group>
                    <Text fw={500}>Độ chính xác:</Text>
                    <Badge color="green" size="lg">{selectedJob.result.accuracy}%</Badge>
                  </Group>
                  <Group>
                    <Text fw={500}>Độ tin cậy:</Text>
                    <Badge color="blue" size="lg">{Math.round(selectedJob.result.confidence * 100)}%</Badge>
                  </Group>
                  {selectedJob.result.warnings.length > 0 && (
                    <Alert icon={<IconAlertTriangle size="1rem" />} color="orange">
                      <Text fw={500} mb="xs">Cảnh báo:</Text>
                      {selectedJob.result.warnings.map((warning, index) => (
                        <Text key={index} size="sm">• {warning}</Text>
                      ))}
                    </Alert>
                  )}
                  <Text fw={500}>Dữ liệu trích xuất:</Text>
                  <JsonInput
                    value={JSON.stringify(selectedJob.result.extractedData, null, 2)}
                    readOnly
                    autosize
                    minRows={10}
                  />
                </Stack>
              </Tabs.Panel>
            )}
          </Tabs>
        )}
      </Modal>
    </Stack>
  );
}