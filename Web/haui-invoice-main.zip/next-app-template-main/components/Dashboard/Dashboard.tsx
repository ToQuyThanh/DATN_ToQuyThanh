'use client';

import { useState, useEffect } from 'react';
import {
  Grid,
  Card,
  Text,
  Group,
  Stack,
  Progress,
  Badge,
  ActionIcon,
  Table,
  Avatar,
  ScrollArea,
  RingProgress,
  SimpleGrid,
  ThemeIcon,
  Timeline,
  Loader,
  Alert,
} from '@mantine/core';
import {
  IconFileText,
  IconUpload,
  IconCheck,
  IconX,
  IconClock,
  IconTrendingUp,
  IconEye,
  IconDownload,
  IconAlertTriangle,
  IconRefresh,
} from '@tabler/icons-react';
import { notifications } from '@mantine/notifications';
import { dashboardApi, type DashboardSummaryResponse, type RecentInvoice } from '../../lib/api';

interface DashboardData {
  statistics: {
    total_invoices: number;
    processed_count: number;
    pending_count: number;
    failed_count: number;
    total_amount: number;
  };
  recent_invoices: RecentInvoice[];
  pagination: {
    limit: number;
    offset: number;
    total: number;
  };
}

// System activity mock data (this could be extended to real API later)
const systemActivity = [
  {
    title: 'Hóa đơn mới được upload',
    description: 'Hóa đơn mới đã được tải lên hệ thống',
    time: '2 phút trước',
    icon: IconUpload,
    color: 'blue',
  },
  {
    title: 'Xử lý hoàn thành',
    description: 'Hóa đơn đã được xử lý thành công',
    time: '5 phút trước',
    icon: IconCheck,
    color: 'green',
  },
  {
    title: 'Cảnh báo hệ thống',
    description: 'Kiểm tra kết nối API',
    time: '10 phút trước',
    icon: IconAlertTriangle,
    color: 'orange',
  },
];

function StatCard({ title, value, diff, icon: Icon, color }: any) {
  return (
    <Card withBorder p="lg" radius="md">
      <Group justify="space-between">
        <div>
          <Text c="dimmed" tt="uppercase" fw={700} fz="xs">
            {title}
          </Text>
          <Text fw={700} fz="xl">
            {value}
          </Text>
        </div>
        <ThemeIcon color={color} variant="light" size="xl" radius="md">
          <Icon size="1.8rem" stroke={1.5} />
        </ThemeIcon>
      </Group>
      <Text c="dimmed" fz="sm" mt="md">
        <Text component="span" c={diff.startsWith('+') ? 'teal' : 'red'} fw={700}>
          {diff}
        </Text>{' '}
        so với tháng trước
      </Text>
    </Card>
  );
}

function getStatusBadge(status: string) {
  const statusConfig = {
    completed: { color: 'green', label: 'Hoàn thành' },
    processing: { color: 'orange', label: 'Đang xử lý' },
    pending: { color: 'blue', label: 'Chờ xử lý' },
    failed: { color: 'red', label: 'Thất bại' },
    error: { color: 'red', label: 'Lỗi' },
  };
  
  const config = statusConfig[status as keyof typeof statusConfig];
  
  // Fallback for unknown status
  if (!config) {
    return <Badge color="gray" variant="light">{status || 'Không xác định'}</Badge>;
  }
  
  return <Badge color={config.color} variant="light">{config.label}</Badge>;
}

export function Dashboard() {
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Fallback data when API is unavailable
  const fallbackData = {
    statistics: {
      total_invoices: 0,
      processed_count: 0,
      pending_count: 0,
      failed_count: 0,
      total_amount: 0,
    },
    recent_invoices: [],
    pagination: {
      limit: 10,
      offset: 0,
      total: 0,
    },
  };

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await dashboardApi.getSummary(10, 0);
      
      if (response.success) {
        setDashboardData(response.data);
      } else {
        throw new Error('Failed to fetch dashboard data');
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error occurred';
      setError(errorMessage);
      
      // Use fallback data when API fails
      setDashboardData(fallbackData);
      
      notifications.show({
        title: 'Cảnh báo',
        message: 'Không thể kết nối đến server. Hiển thị dữ liệu mặc định.',
        color: 'yellow',
      });
      
      console.warn('Dashboard API failed, using fallback data:', errorMessage);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  // Generate stats from API data
  const stats = dashboardData ? [
    {
      title: 'Tổng hóa đơn',
      value: dashboardData.statistics.total_invoices.toLocaleString(),
      diff: '+12%', // This could be calculated from historical data
      icon: IconFileText,
      color: 'blue',
    },
    {
      title: 'Đã xử lý',
      value: dashboardData.statistics.processed_count.toLocaleString(),
      diff: '+8%',
      icon: IconCheck,
      color: 'green',
    },
    {
      title: 'Đang xử lý',
      value: dashboardData.statistics.pending_count.toLocaleString(),
      diff: '-2%',
      icon: IconClock,
      color: 'orange',
    },
    {
      title: 'Lỗi xử lý',
      value: dashboardData.statistics.failed_count.toLocaleString(),
      diff: '-15%',
      icon: IconX,
      color: 'red',
    },
  ] : [];

  const statsCards = stats.map((stat) => (
    <StatCard key={stat.title} {...stat} />
  ));

  const invoiceRows = dashboardData?.recent_invoices.map((invoice) => (
    <Table.Tr key={invoice.invoice_id}>
      <Table.Td>
        <Group gap="sm">
          <Avatar size="sm" color="blue" radius="xl">
            <IconFileText size="0.8rem" />
          </Avatar>
          <div>
            <Text fz="sm" fw={500}>
              {invoice.invoice_number || `INV-${invoice.invoice_id}`}
            </Text>
            <Text fz="xs" c="dimmed">
              {new Date(invoice.upload_time).toLocaleDateString('vi-VN')}
            </Text>
          </div>
        </Group>
      </Table.Td>
      <Table.Td>
        <Text fz="sm">{invoice.store_name || 'N/A'}</Text>
      </Table.Td>
      <Table.Td>
        <Text fz="sm" fw={500}>
          {invoice.total_amount.toLocaleString()} VNĐ
        </Text>
      </Table.Td>
      <Table.Td>
        {getStatusBadge(invoice.status)}
      </Table.Td>
      <Table.Td>
        <Group gap="xs">
          <Text fz="sm">95%</Text> {/* Default accuracy, could be from API */}
          <Progress value={95} size="sm" style={{ flex: 1 }} />
        </Group>
      </Table.Td>
      <Table.Td>
        <Group gap="xs">
          <ActionIcon variant="light" size="sm">
            <IconEye size="0.8rem" />
          </ActionIcon>
          <ActionIcon variant="light" size="sm">
            <IconDownload size="0.8rem" />
          </ActionIcon>
        </Group>
      </Table.Td>
    </Table.Tr>
  )) || [];

  if (loading) {
    return (
      <Stack gap="lg" align="center" justify="center" style={{ minHeight: '400px' }}>
        <Loader size="xl" />
        <Text>Đang tải dữ liệu dashboard...</Text>
      </Stack>
    );
  }

  if (error) {
    return (
      <Stack gap="lg">
        <Alert color="red" title="Lỗi kết nối" icon={<IconAlertTriangle size="1rem" />}>
          {error}
          <Group mt="md">
            <ActionIcon variant="light" onClick={fetchDashboardData}>
              <IconRefresh size="1rem" />
            </ActionIcon>
            <Text size="sm">Nhấn để thử lại</Text>
          </Group>
        </Alert>
      </Stack>
    );
  }

  return (
    <Stack gap="lg">
      {/* Header */}
      <Group justify="space-between">
        <div>
          <Text size="xl" fw={700}>
            Dashboard
          </Text>
          <Text c="dimmed" size="sm">
            Tổng quan hệ thống xử lý hóa đơn
          </Text>
        </div>
        <ActionIcon variant="light" onClick={fetchDashboardData} loading={loading}>
          <IconRefresh size="1rem" />
        </ActionIcon>
      </Group>

      {/* Stats Cards */}
      <SimpleGrid cols={{ base: 1, sm: 2, lg: 4 }}>
        {statsCards}
      </SimpleGrid>

      <Grid>
        {/* Processing Overview */}
        <Grid.Col span={{ base: 12, md: 8 }}>
          <Card withBorder p="lg" radius="md" h="100%">
            <Group justify="space-between" mb="md">
              <Text fw={600} size="lg">
                Hóa đơn gần đây
              </Text>
              <Badge variant="light">
                {dashboardData?.recent_invoices?.length || 0} hóa đơn
              </Badge>
            </Group>
            
            <ScrollArea>
              <Table verticalSpacing="sm">
                <Table.Thead>
                  <Table.Tr>
                    <Table.Th>Mã hóa đơn</Table.Th>
                    <Table.Th>Cửa hàng</Table.Th>
                    <Table.Th>Số tiền</Table.Th>
                    <Table.Th>Trạng thái</Table.Th>
                    <Table.Th>Độ chính xác</Table.Th>
                    <Table.Th>Thao tác</Table.Th>
                  </Table.Tr>
                </Table.Thead>
                <Table.Tbody>{invoiceRows}</Table.Tbody>
              </Table>
            </ScrollArea>
          </Card>
        </Grid.Col>

        {/* System Activity */}
        <Grid.Col span={{ base: 12, md: 4 }}>
          <Card withBorder p="lg" radius="md" h="100%">
            <Text fw={600} size="lg" mb="md">
              Hoạt động hệ thống
            </Text>
            
            <Timeline active={-1} bulletSize={24} lineWidth={2}>
              {systemActivity.map((activity, index) => (
                <Timeline.Item
                  key={index}
                  bullet={
                    <ThemeIcon color={activity.color} size={24} radius="xl">
                      <activity.icon size="0.8rem" />
                    </ThemeIcon>
                  }
                  title={activity.title}
                >
                  <Text c="dimmed" size="sm">
                    {activity.description}
                  </Text>
                  <Text size="xs" mt={4} c="dimmed">
                    {activity.time}
                  </Text>
                </Timeline.Item>
              ))}
            </Timeline>
          </Card>
        </Grid.Col>

        {/* Performance Overview */}
        <Grid.Col span={{ base: 12, md: 6 }}>
          <Card withBorder p="lg" radius="md">
            <Text fw={600} size="lg" mb="md">
              Hiệu suất xử lý
            </Text>
            
            <Group justify="center">
              {dashboardData && (() => {
                const total = dashboardData.statistics.total_invoices;
                const processed = dashboardData.statistics.processed_count;
                const pending = dashboardData.statistics.pending_count;
                const failed = dashboardData.statistics.failed_count;
                
                const processedPercent = total > 0 ? (processed / total) * 100 : 0;
                const pendingPercent = total > 0 ? (pending / total) * 100 : 0;
                const failedPercent = total > 0 ? (failed / total) * 100 : 0;
                
                return (
                  <RingProgress
                    size={180}
                    thickness={12}
                    sections={[
                      { value: processedPercent, color: 'green', tooltip: `Thành công - ${processedPercent.toFixed(1)}%` },
                      { value: pendingPercent, color: 'orange', tooltip: `Đang xử lý - ${pendingPercent.toFixed(1)}%` },
                      { value: failedPercent, color: 'red', tooltip: `Lỗi - ${failedPercent.toFixed(1)}%` },
                    ]}
                    label={
                      <div style={{ textAlign: 'center' }}>
                        <Text fw={700} size="xl">
                          {processedPercent.toFixed(1)}%
                        </Text>
                        <Text c="dimmed" size="sm">
                          Tỷ lệ thành công
                        </Text>
                      </div>
                    }
                  />
                );
              })()}
            </Group>
          </Card>
        </Grid.Col>

        {/* Quick Actions */}
        <Grid.Col span={{ base: 12, md: 6 }}>
          <Card withBorder p="lg" radius="md">
            <Text fw={600} size="lg" mb="md">
              Thao tác nhanh
            </Text>
            
            <Stack gap="sm">
              <Card withBorder p="md" radius="sm" style={{ cursor: 'pointer' }}>
                <Group>
                  <ThemeIcon color="blue" variant="light">
                    <IconUpload size="1rem" />
                  </ThemeIcon>
                  <div>
                    <Text fw={500}>Upload hóa đơn mới</Text>
                    <Text size="sm" c="dimmed">
                      Tải lên và xử lý hóa đơn
                    </Text>
                  </div>
                </Group>
              </Card>
              
              <Card withBorder p="md" radius="sm" style={{ cursor: 'pointer' }}>
                <Group>
                  <ThemeIcon color="green" variant="light">
                    <IconTrendingUp size="1rem" />
                  </ThemeIcon>
                  <div>
                    <Text fw={500}>Xem báo cáo</Text>
                    <Text size="sm" c="dimmed">
                      Thống kê chi tiết
                    </Text>
                  </div>
                </Group>
              </Card>
            </Stack>
          </Card>
        </Grid.Col>
      </Grid>
    </Stack>
  );
}