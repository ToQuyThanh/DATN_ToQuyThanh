'use client';

import { useState, useEffect } from 'react';
import {
  Stack,
  Text,
  Card,
  Group,
  Switch,
  NumberInput,
  Select,
  Button,
  Divider,
  Alert,
  Progress,
  Badge,
  Grid,
  Tabs,
  TextInput,
  PasswordInput,
  Textarea,
  ActionIcon,
  Table,
  ScrollArea,
  useMantineColorScheme,
} from '@mantine/core';
import { notifications } from '@mantine/notifications';
import {
  IconSettings,
  IconDatabase,
  IconBrain,
  IconBell,
  IconShield,
  IconCheck,
  IconAlertTriangle,
  IconRefresh,
  IconTrash,
  IconDownload,
  IconUpload,
  IconEye,
  IconEyeOff,
  IconPalette,
} from '@tabler/icons-react';

interface SystemConfig {
  ocr: {
    enabled: boolean;
    confidence_threshold: number;
    language: string;
    max_file_size: number;
  };
  docunet: {
    enabled: boolean;
    model_version: string;
    accuracy_threshold: number;
  };
  database: {
    auto_backup: boolean;
    backup_interval: number;
    retention_days: number;
  };
  notifications: {
    email_enabled: boolean;
    email_address: string;
    webhook_enabled: boolean;
    webhook_url: string;
  };
  security: {
    require_auth: boolean;
    session_timeout: number;
    max_login_attempts: number;
  };
  appearance: {
    theme: string;
    auto_theme: boolean;
  };
}

const initialConfig: SystemConfig = {
  ocr: {
    enabled: true,
    confidence_threshold: 80,
    language: 'vi',
    max_file_size: 10,
  },
  docunet: {
    enabled: true,
    model_version: 'v2.1',
    accuracy_threshold: 85,
  },
  database: {
    auto_backup: true,
    backup_interval: 24,
    retention_days: 30,
  },
  notifications: {
    email_enabled: false,
    email_address: '',
    webhook_enabled: false,
    webhook_url: '',
  },
  security: {
    require_auth: true,
    session_timeout: 60,
    max_login_attempts: 5,
  },
  appearance: {
    theme: 'auto',
    auto_theme: true,
  },
};

const systemLogs = [
  {
    id: '1',
    timestamp: '2024-01-15 14:30:25',
    level: 'INFO',
    component: 'OCR',
    message: 'Processed invoice INV-001 successfully',
  },
  {
    id: '2',
    timestamp: '2024-01-15 14:28:10',
    level: 'WARNING',
    component: 'DocUnet',
    message: 'Low confidence score for document structure detection',
  },
  {
    id: '3',
    timestamp: '2024-01-15 14:25:45',
    level: 'ERROR',
    component: 'Database',
    message: 'Failed to save processed data for INV-003',
  },
  {
    id: '4',
    timestamp: '2024-01-15 14:20:30',
    level: 'INFO',
    component: 'System',
    message: 'Automatic backup completed successfully',
  },
];

export function Settings() {
  const [config, setConfig] = useState<SystemConfig>(initialConfig);
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const { setColorScheme } = useMantineColorScheme();

  const updateConfig = (section: keyof SystemConfig, key: string, value: any) => {
    setConfig(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [key]: value,
      },
    }));
  };

  // Đồng bộ theme changes với Mantine color scheme
  useEffect(() => {
    if (config.appearance.theme !== 'auto') {
      setColorScheme(config.appearance.theme as 'light' | 'dark');
    } else {
      setColorScheme('auto');
    }
  }, [config.appearance.theme, setColorScheme]);

  const saveConfig = async () => {
    setLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    notifications.show({
      title: 'Cấu hình đã được lưu',
      message: 'Các thay đổi đã được áp dụng thành công',
      color: 'green',
      icon: <IconCheck size="1rem" />,
    });
    setLoading(false);
  };

  const resetConfig = () => {
    setConfig(initialConfig);
    notifications.show({
      title: 'Đã khôi phục cấu hình mặc định',
      message: 'Tất cả cài đặt đã được đặt lại về giá trị mặc định',
      color: 'blue',
      icon: <IconRefresh size="1rem" />,
    });
  };

  const testConnection = async (type: 'database' | 'email' | 'webhook') => {
    setLoading(true);
    // Simulate test
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const success = Math.random() > 0.3; // 70% success rate
    
    notifications.show({
      title: success ? 'Kết nối thành công' : 'Kết nối thất bại',
      message: success 
        ? `Kết nối ${type} hoạt động bình thường`
        : `Không thể kết nối đến ${type}`,
      color: success ? 'green' : 'red',
      icon: success ? <IconCheck size="1rem" /> : <IconAlertTriangle size="1rem" />,
    });
    setLoading(false);
  };

  const getLevelBadge = (level: string) => {
    const levelConfig = {
      INFO: { color: 'blue', label: 'INFO' },
      WARNING: { color: 'orange', label: 'WARNING' },
      ERROR: { color: 'red', label: 'ERROR' },
    };
    
    const config = levelConfig[level as keyof typeof levelConfig];
    return <Badge color={config.color} variant="light" size="xs">{config.label}</Badge>;
  };

  return (
    <Stack gap="lg">
      {/* Header */}
      <Group justify="space-between">
        <div>
          <Text size="xl" fw={700}>
            Cài đặt hệ thống
          </Text>
          <Text c="dimmed" size="sm">
            Cấu hình và quản lý hệ thống xử lý hóa đơn
          </Text>
        </div>
        <Group>
          <Button
            variant="light"
            leftSection={<IconRefresh size="1rem" />}
            onClick={resetConfig}
          >
            Khôi phục mặc định
          </Button>
          <Button
            leftSection={<IconCheck size="1rem" />}
            onClick={saveConfig}
            loading={loading}
          >
            Lưu cấu hình
          </Button>
        </Group>
      </Group>

      <Tabs defaultValue="ocr">
        <Tabs.List>
          <Tabs.Tab value="ocr" leftSection={<IconBrain size="1rem" />}>
            OCR & DocUnet
          </Tabs.Tab>
          <Tabs.Tab value="database" leftSection={<IconDatabase size="1rem" />}>
            Cơ sở dữ liệu
          </Tabs.Tab>
          <Tabs.Tab value="notifications" leftSection={<IconBell size="1rem" />}>
            Thông báo
          </Tabs.Tab>
          <Tabs.Tab value="security" leftSection={<IconShield size="1rem" />}>
            Bảo mật
          </Tabs.Tab>
          <Tabs.Tab value="appearance" leftSection={<IconPalette size="1rem" />}>
            Giao diện
          </Tabs.Tab>
          <Tabs.Tab value="logs" leftSection={<IconSettings size="1rem" />}>
            System Logs
          </Tabs.Tab>
        </Tabs.List>

        {/* OCR & DocUnet Settings */}
        <Tabs.Panel value="ocr" pt="md">
          <Grid>
            <Grid.Col span={{ base: 12, md: 6 }}>
              <Card withBorder p="lg" radius="md">
                <Stack gap="md">
                  <Group justify="space-between">
                    <Text fw={600} size="lg">Cấu hình OCR</Text>
                    <Switch
                      checked={config.ocr.enabled}
                      onChange={(e) => updateConfig('ocr', 'enabled', e.currentTarget.checked)}
                    />
                  </Group>
                  
                  <NumberInput
                    label="Ngưỡng độ tin cậy (%)"
                    description="Độ tin cậy tối thiểu để chấp nhận kết quả OCR"
                    value={config.ocr.confidence_threshold}
                    onChange={(value) => updateConfig('ocr', 'confidence_threshold', value)}
                    min={0}
                    max={100}
                    disabled={!config.ocr.enabled}
                  />
                  
                  <Select
                    label="Ngôn ngữ"
                    description="Ngôn ngữ chính để nhận dạng văn bản"
                    value={config.ocr.language}
                    onChange={(value) => updateConfig('ocr', 'language', value)}
                    data={[
                      { value: 'vi', label: 'Tiếng Việt' },
                      { value: 'en', label: 'English' },
                      { value: 'auto', label: 'Tự động phát hiện' },
                    ]}
                    disabled={!config.ocr.enabled}
                  />
                  
                  <NumberInput
                    label="Kích thước file tối đa (MB)"
                    description="Giới hạn kích thước file upload"
                    value={config.ocr.max_file_size}
                    onChange={(value) => updateConfig('ocr', 'max_file_size', value)}
                    min={1}
                    max={50}
                    disabled={!config.ocr.enabled}
                  />
                </Stack>
              </Card>
            </Grid.Col>
            
            <Grid.Col span={{ base: 12, md: 6 }}>
              <Card withBorder p="lg" radius="md">
                <Stack gap="md">
                  <Group justify="space-between">
                    <Text fw={600} size="lg">Cấu hình DocUnet</Text>
                    <Switch
                      checked={config.docunet.enabled}
                      onChange={(e) => updateConfig('docunet', 'enabled', e.currentTarget.checked)}
                    />
                  </Group>
                  
                  <Select
                    label="Phiên bản mô hình"
                    description="Chọn phiên bản mô hình DocUnet"
                    value={config.docunet.model_version}
                    onChange={(value) => updateConfig('docunet', 'model_version', value)}
                    data={[
                      { value: 'v2.1', label: 'Version 2.1 (Stable)' },
                      { value: 'v2.2', label: 'Version 2.2 (Beta)' },
                      { value: 'v1.9', label: 'Version 1.9 (Legacy)' },
                    ]}
                    disabled={!config.docunet.enabled}
                  />
                  
                  <NumberInput
                    label="Ngưỡng độ chính xác (%)"
                    description="Độ chính xác tối thiểu để chấp nhận kết quả"
                    value={config.docunet.accuracy_threshold}
                    onChange={(value) => updateConfig('docunet', 'accuracy_threshold', value)}
                    min={0}
                    max={100}
                    disabled={!config.docunet.enabled}
                  />
                  
                  <Alert icon={<IconAlertTriangle size="1rem" />} color="orange">
                    Thay đổi cấu hình DocUnet có thể ảnh hưởng đến hiệu suất xử lý
                  </Alert>
                </Stack>
              </Card>
            </Grid.Col>
          </Grid>
        </Tabs.Panel>

        {/* Database Settings */}
        <Tabs.Panel value="database" pt="md">
          <Card withBorder p="lg" radius="md">
            <Stack gap="md">
              <Group justify="space-between">
                <Text fw={600} size="lg">Cấu hình cơ sở dữ liệu</Text>
                <Button
                  variant="light"
                  leftSection={<IconDatabase size="1rem" />}
                  onClick={() => testConnection('database')}
                  loading={loading}
                >
                  Kiểm tra kết nối
                </Button>
              </Group>
              
              <Grid>
                <Grid.Col span={{ base: 12, md: 6 }}>
                  <Switch
                    label="Tự động sao lưu"
                    description="Tự động tạo bản sao lưu dữ liệu"
                    checked={config.database.auto_backup}
                    onChange={(e) => updateConfig('database', 'auto_backup', e.currentTarget.checked)}
                  />
                </Grid.Col>
                
                <Grid.Col span={{ base: 12, md: 6 }}>
                  <NumberInput
                    label="Khoảng thời gian sao lưu (giờ)"
                    description="Tần suất tự động sao lưu"
                    value={config.database.backup_interval}
                    onChange={(value) => updateConfig('database', 'backup_interval', value)}
                    min={1}
                    max={168}
                    disabled={!config.database.auto_backup}
                  />
                </Grid.Col>
                
                <Grid.Col span={{ base: 12, md: 6 }}>
                  <NumberInput
                    label="Thời gian lưu trữ (ngày)"
                    description="Số ngày lưu trữ bản sao lưu"
                    value={config.database.retention_days}
                    onChange={(value) => updateConfig('database', 'retention_days', value)}
                    min={1}
                    max={365}
                    disabled={!config.database.auto_backup}
                  />
                </Grid.Col>
              </Grid>
              
              <Divider />
              
              <Group>
                <Button leftSection={<IconDownload size="1rem" />} variant="light">
                  Tạo bản sao lưu ngay
                </Button>
                <Button leftSection={<IconUpload size="1rem" />} variant="light">
                  Khôi phục từ sao lưu
                </Button>
                <Button leftSection={<IconTrash size="1rem" />} color="red" variant="light">
                  Xóa dữ liệu cũ
                </Button>
              </Group>
            </Stack>
          </Card>
        </Tabs.Panel>

        {/* Notifications Settings */}
        <Tabs.Panel value="notifications" pt="md">
          <Grid>
            <Grid.Col span={{ base: 12, md: 6 }}>
              <Card withBorder p="lg" radius="md">
                <Stack gap="md">
                  <Group justify="space-between">
                    <Text fw={600} size="lg">Thông báo Email</Text>
                    <Switch
                      checked={config.notifications.email_enabled}
                      onChange={(e) => updateConfig('notifications', 'email_enabled', e.currentTarget.checked)}
                    />
                  </Group>
                  
                  <TextInput
                    label="Địa chỉ email"
                    placeholder="admin@example.com"
                    value={config.notifications.email_address}
                    onChange={(e) => updateConfig('notifications', 'email_address', e.target.value)}
                    disabled={!config.notifications.email_enabled}
                  />
                  
                  <Button
                    variant="light"
                    onClick={() => testConnection('email')}
                    disabled={!config.notifications.email_enabled}
                    loading={loading}
                  >
                    Gửi email thử nghiệm
                  </Button>
                </Stack>
              </Card>
            </Grid.Col>
            
            <Grid.Col span={{ base: 12, md: 6 }}>
              <Card withBorder p="lg" radius="md">
                <Stack gap="md">
                  <Group justify="space-between">
                    <Text fw={600} size="lg">Webhook</Text>
                    <Switch
                      checked={config.notifications.webhook_enabled}
                      onChange={(e) => updateConfig('notifications', 'webhook_enabled', e.currentTarget.checked)}
                    />
                  </Group>
                  
                  <TextInput
                    label="URL Webhook"
                    placeholder="https://api.example.com/webhook"
                    value={config.notifications.webhook_url}
                    onChange={(e) => updateConfig('notifications', 'webhook_url', e.target.value)}
                    disabled={!config.notifications.webhook_enabled}
                  />
                  
                  <Button
                    variant="light"
                    onClick={() => testConnection('webhook')}
                    disabled={!config.notifications.webhook_enabled}
                    loading={loading}
                  >
                    Kiểm tra webhook
                  </Button>
                </Stack>
              </Card>
            </Grid.Col>
          </Grid>
        </Tabs.Panel>

        {/* Security Settings */}
        <Tabs.Panel value="security" pt="md">
          <Card withBorder p="lg" radius="md">
            <Stack gap="md">
              <Text fw={600} size="lg">Cài đặt bảo mật</Text>
              
              <Grid>
                <Grid.Col span={{ base: 12, md: 6 }}>
                  <Switch
                    label="Yêu cầu xác thực"
                    description="Bắt buộc đăng nhập để truy cập hệ thống"
                    checked={config.security.require_auth}
                    onChange={(e) => updateConfig('security', 'require_auth', e.currentTarget.checked)}
                  />
                </Grid.Col>
                
                <Grid.Col span={{ base: 12, md: 6 }}>
                  <NumberInput
                    label="Thời gian hết hạn phiên (phút)"
                    description="Tự động đăng xuất sau thời gian không hoạt động"
                    value={config.security.session_timeout}
                    onChange={(value) => updateConfig('security', 'session_timeout', value)}
                    min={5}
                    max={480}
                    disabled={!config.security.require_auth}
                  />
                </Grid.Col>
                
                <Grid.Col span={{ base: 12, md: 6 }}>
                  <NumberInput
                    label="Số lần đăng nhập tối đa"
                    description="Khóa tài khoản sau số lần đăng nhập sai"
                    value={config.security.max_login_attempts}
                    onChange={(value) => updateConfig('security', 'max_login_attempts', value)}
                    min={3}
                    max={10}
                    disabled={!config.security.require_auth}
                  />
                </Grid.Col>
              </Grid>
              
              <Divider />
              
              <Text fw={500}>Thay đổi mật khẩu</Text>
              <Grid>
                <Grid.Col span={{ base: 12, md: 6 }}>
                  <PasswordInput
                    label="Mật khẩu hiện tại"
                    placeholder="Nhập mật khẩu hiện tại"
                    visible={showPassword}
                    onVisibilityChange={setShowPassword}
                  />
                </Grid.Col>
                <Grid.Col span={{ base: 12, md: 6 }}>
                  <PasswordInput
                    label="Mật khẩu mới"
                    placeholder="Nhập mật khẩu mới"
                    visible={showPassword}
                    onVisibilityChange={setShowPassword}
                  />
                </Grid.Col>
              </Grid>
              
              <Button variant="light" style={{ alignSelf: 'flex-start' }}>
                Cập nhật mật khẩu
              </Button>
            </Stack>
          </Card>
        </Tabs.Panel>

        {/* Appearance Settings */}
        <Tabs.Panel value="appearance" pt="md">
          <Card withBorder p="lg" radius="md">
            <Stack gap="lg">
              <Text fw={600} size="lg">Cài đặt giao diện</Text>
              
              <Grid>
                <Grid.Col span={{ base: 12, md: 6 }}>
                  <Select
                    label="Chế độ hiển thị"
                    description="Chọn chế độ hiển thị cho ứng dụng"
                    value={config.appearance.theme}
                    onChange={(value) => updateConfig('appearance', 'theme', value || 'auto')}
                    data={[
                      { value: 'light', label: 'Sáng' },
                      { value: 'dark', label: 'Tối' },
                      { value: 'auto', label: 'Tự động theo hệ thống' },
                    ]}
                  />
                </Grid.Col>
                
                <Grid.Col span={{ base: 12, md: 6 }}>
                  <Group justify="space-between" mt="lg">
                    <div>
                      <Text fw={500}>Tự động chuyển đổi theme</Text>
                      <Text size="sm" c="dimmed">
                        Tự động chuyển đổi giữa sáng/tối theo thời gian
                      </Text>
                    </div>
                    <Switch
                      checked={config.appearance.auto_theme}
                      onChange={(e) => updateConfig('appearance', 'auto_theme', e.currentTarget.checked)}
                      disabled={config.appearance.theme !== 'auto'}
                    />
                  </Group>
                </Grid.Col>
              </Grid>
              
              <Divider />
              
              <Alert color="blue" variant="light">
                <Text size="sm">
                  Thay đổi theme sẽ được áp dụng ngay lập tức. Bạn cũng có thể sử dụng nút chuyển đổi theme ở góc trên bên phải.
                </Text>
              </Alert>
            </Stack>
          </Card>
        </Tabs.Panel>

        {/* System Logs */}
        <Tabs.Panel value="logs" pt="md">
          <Card withBorder p="lg" radius="md">
            <Group justify="space-between" mb="md">
              <Text fw={600} size="lg">Logs hệ thống</Text>
              <Group>
                <Button variant="light" leftSection={<IconRefresh size="1rem" />}>
                  Làm mới
                </Button>
                <Button variant="light" leftSection={<IconDownload size="1rem" />}>
                  Tải xuống logs
                </Button>
              </Group>
            </Group>
            
            <ScrollArea>
              <Table verticalSpacing="sm">
                <Table.Thead>
                  <Table.Tr>
                    <Table.Th>Thời gian</Table.Th>
                    <Table.Th>Cấp độ</Table.Th>
                    <Table.Th>Component</Table.Th>
                    <Table.Th>Thông điệp</Table.Th>
                  </Table.Tr>
                </Table.Thead>
                <Table.Tbody>
                  {systemLogs.map((log) => (
                    <Table.Tr key={log.id}>
                      <Table.Td>
                        <Text size="sm">{log.timestamp}</Text>
                      </Table.Td>
                      <Table.Td>
                        {getLevelBadge(log.level)}
                      </Table.Td>
                      <Table.Td>
                        <Badge variant="light" size="sm">{log.component}</Badge>
                      </Table.Td>
                      <Table.Td>
                        <Text size="sm">{log.message}</Text>
                      </Table.Td>
                    </Table.Tr>
                  ))}
                </Table.Tbody>
              </Table>
            </ScrollArea>
          </Card>
        </Tabs.Panel>
      </Tabs>
    </Stack>
  );
}