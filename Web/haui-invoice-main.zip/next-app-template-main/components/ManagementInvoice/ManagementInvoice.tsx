'use client';

import { useState, useEffect } from 'react';
import {
  Stack,
  Text,
  Card,
  Group,
  Button,
  Table,
  Badge,
  ActionIcon,
  TextInput,
  Select,
  MultiSelect,
  NumberInput,
  Grid,
  ScrollArea,
  Pagination,
  Checkbox,
  Modal,
  Tabs,
  Alert,
  JsonInput,
  Menu,
  Tooltip,
  Loader,
  Center,
} from '@mantine/core';
import { DateInput } from '@mantine/dates';
import { useDisclosure } from '@mantine/hooks';
import { notifications } from '@mantine/notifications';
import { rem } from '@mantine/core';
import {
  IconSearch,
  IconX,
  IconEye,
  IconDownload,
  IconEdit,
  IconTrash,
  IconRefresh,
  IconFileExport,
  IconChevronDown,
  IconFile,
  IconFileText,
  IconPhoto,
  IconAlertTriangle,
} from '@tabler/icons-react';
import { invoiceApi, type Invoice, type InvoiceFilters } from '../../lib/api';

interface InvoiceData {
  id: string;
  fileName: string;
  fileType: 'pdf' | 'jpg' | 'png';
  storeName: string;
  storeAddress: string;
  invoiceNumber: string;
  date: string;
  time: string;
  total: number;
  tax: number;
  items: Array<{
    name: string;
    quantity: number;
    price: number;
  }>;
  status: 'completed' | 'error' | 'pending';
  accuracy: number;
  confidence: number;
  processedAt: string;
  warnings: string[];
}

export function ManagementInvoice() {
  // State for all invoices (unfiltered from API)
  const [allInvoices, setAllInvoices] = useState<Invoice[]>([]);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [detailOpened, { open: openDetail, close: closeDetail }] = useDisclosure(false);
  const [selectedRows, setSelectedRows] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // Filter states
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string | null>(null);
  const [storeFilter, setStoreFilter] = useState<string[]>([]);
  const [dateFrom, setDateFrom] = useState<Date | null>(null);
  const [dateTo, setDateTo] = useState<Date | null>(null);
  const [minAmount, setMinAmount] = useState<number | string>('');
  const [maxAmount, setMaxAmount] = useState<number | string>('');
  const [minAccuracy, setMinAccuracy] = useState<number | string>('');
  
  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // Fetch invoices from API
  const fetchInvoices = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // API chỉ hỗ trợ query và status filter
      const response = await invoiceApi.list(
        searchQuery || undefined,
        statusFilter || undefined,
        100, // Lấy nhiều hơn để filter phía client
        0
      );
      
      setAllInvoices(response.data.invoices);
    } catch (err) {
      setError('Không thể tải danh sách hóa đơn. Vui lòng thử lại.');
      console.error('Error fetching invoices:', err);
      notifications.show({
        title: 'Lỗi',
        message: 'Không thể tải danh sách hóa đơn',
        color: 'red',
      });
    } finally {
      setLoading(false);
    }
  };

  // Client-side filtering
  const filteredInvoices = allInvoices.filter(invoice => {
    // Store filter
    if (storeFilter.length > 0 && !storeFilter.includes(invoice.store_name)) {
      return false;
    }
    
    // Date range filter
     if (dateFrom || dateTo) {
       if (!invoice.invoice_date) return false; // Skip invoices without date
       const invoiceDate = new Date(invoice.invoice_date);
       if (dateFrom && invoiceDate < dateFrom) return false;
       if (dateTo && invoiceDate > dateTo) return false;
     }
    
    // Amount range filter
    if (minAmount && invoice.total_amount < Number(minAmount)) return false;
    if (maxAmount && invoice.total_amount > Number(maxAmount)) return false;
    
    // Accuracy filter
    if (minAccuracy && (!invoice.accuracy || invoice.accuracy < Number(minAccuracy))) return false;
    
    return true;
  });

  // Pagination
  const totalPages = Math.ceil(filteredInvoices.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const invoices = filteredInvoices.slice(startIndex, startIndex + itemsPerPage);

  // Load invoices on component mount and when API filters change
  useEffect(() => {
    fetchInvoices();
  }, [searchQuery, statusFilter]);

  // Reset pagination when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [storeFilter, dateFrom, dateTo, minAmount, maxAmount, minAccuracy]);

  // Get unique store options from all invoices
  const storeOptions = Array.from(new Set(allInvoices.map(inv => inv.store_name))).map(store => ({
    value: store,
    label: store,
  }));

  const statusOptions = [
    { value: 'completed', label: 'Hoàn thành' },
    { value: 'error', label: 'Lỗi' },
    { value: 'pending', label: 'Đang xử lý' },
  ];

  // Handle invoice deletion
  const handleDeleteInvoice = async (invoiceId: string) => {
    try {
      // TODO: Implement delete API endpoint
      notifications.show({
        title: 'Thông báo',
        message: 'Chức năng xóa hóa đơn đang được phát triển',
        color: 'blue',
      });
    } catch (err) {
      notifications.show({
        title: 'Lỗi',
        message: 'Không thể xóa hóa đơn',
        color: 'red',
      });
    }
  };

  // Handle invoice reprocessing
  const handleReprocessInvoice = async (invoiceId: string) => {
    try {
      await invoiceApi.process(Number(invoiceId));
      await fetchInvoices(); // Refresh the list
      notifications.show({
        title: 'Thành công',
        message: 'Đã gửi yêu cầu xử lý lại hóa đơn',
        color: 'green',
      });
    } catch (err) {
      notifications.show({
        title: 'Lỗi',
        message: 'Không thể xử lý lại hóa đơn',
        color: 'red',
      });
    }
  };

  // Handle bulk operations
  const deleteSelected = async () => {
    try {
      // TODO: Implement bulk delete API endpoint
      setSelectedRows([]);
      notifications.show({
        title: 'Thông báo',
        message: 'Chức năng xóa hàng loạt đang được phát triển',
        color: 'blue',
      });
    } catch (err) {
      notifications.show({
        title: 'Lỗi',
        message: 'Không thể xóa các hóa đơn đã chọn',
        color: 'red',
      });
    }
  };

  const exportSelected = async () => {
    try {
      const selectedInvoices = invoices.filter(inv => selectedRows.includes(inv.invoice_id.toString()));
      // Here you would typically call an export API
      console.log('Exporting:', selectedInvoices);
      notifications.show({
        title: 'Thành công',
        message: `Đã xuất ${selectedRows.length} hóa đơn`,
        color: 'green',
      });
    } catch (err) {
      notifications.show({
        title: 'Lỗi',
        message: 'Không thể xuất các hóa đơn đã chọn',
        color: 'red',
      });
    }
  };

  const clearFilters = () => {
    setSearchQuery('');
    setStatusFilter(null);
    setStoreFilter([]);
    setDateFrom(null);
    setDateTo(null);
    setMinAmount('');
    setMaxAmount('');
    setMinAccuracy('');
    setCurrentPage(1);
  };

  const getStatusBadge = (status: Invoice['status']) => {
    const statusConfig = {
      uploaded: { color: 'blue', label: 'Đã tải lên' },
      processing: { color: 'orange', label: 'Đang xử lý' },
      completed: { color: 'green', label: 'Hoàn thành' },
      failed: { color: 'red', label: 'Thất bại' },
    };
    
    const config = statusConfig[status] || { color: 'gray', label: status };
    return <Badge color={config.color} variant="light">{config.label}</Badge>;
  };

  const getFileIcon = (fileType: string) => {
    switch (fileType) {
      case 'pdf': return <IconFile size="1rem" color="red" />;
      case 'jpg':
      case 'png': return <IconPhoto size="1rem" color="blue" />;
      default: return <IconFileText size="1rem" />;
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND',
    }).format(amount);
  };

  const viewInvoiceDetail = (invoice: Invoice) => {
    setSelectedInvoice(invoice);
    openDetail();
  };

  const toggleRowSelection = (invoiceId: string) => {
    setSelectedRows(prev => 
      prev.includes(invoiceId) 
        ? prev.filter(id => id !== invoiceId)
        : [...prev, invoiceId]
    );
  };

  const toggleAllRows = () => {
    if (selectedRows.length === invoices.length) {
      setSelectedRows([]);
    } else {
      setSelectedRows(invoices.map(inv => inv.invoice_id.toString()));
    }
  };

  // Show loading state
  if (loading) {
    return (
      <Center h={400}>
        <Stack align="center" gap="md">
          <Loader size="lg" />
          <Text>Đang tải danh sách hóa đơn...</Text>
        </Stack>
      </Center>
    );
  }

  // Show error state
  if (error) {
    return (
      <Alert
        icon={<IconAlertTriangle size="1rem" />}
        title="Lỗi tải dữ liệu"
        color="red"
        variant="light"
      >
        <Stack gap="md">
          <Text>{error}</Text>
          <Button
            leftSection={<IconRefresh size="1rem" />}
            onClick={fetchInvoices}
            variant="light"
          >
            Thử lại
          </Button>
        </Stack>
      </Alert>
    );
  }

  const invoiceRows = invoices.map((invoice) => (
    <Table.Tr key={invoice.invoice_id.toString()} bg={selectedRows.includes(invoice.invoice_id.toString()) ? 'var(--mantine-color-blue-light)' : undefined}>
      <Table.Td>
        <Checkbox
          checked={selectedRows.includes(invoice.invoice_id.toString())}
          onChange={() => toggleRowSelection(invoice.invoice_id.toString())}
        />
      </Table.Td>
      <Table.Td>
        <Group gap="sm">
          {getFileIcon('pdf')}
          <div>
            <Text size="sm" fw={500}>
              {invoice.invoice_number}
            </Text>
            <Text size="xs" c="dimmed">
              ID: {invoice.invoice_id}
            </Text>
          </div>
        </Group>
      </Table.Td>
      <Table.Td>
        <div>
          <Text size="sm" fw={500}>
            {invoice.store_name}
          </Text>
          <Text size="xs" c="dimmed">
            {invoice.store_address}
          </Text>
        </div>
      </Table.Td>
      <Table.Td>
        <Text size="sm">
          {invoice.invoice_date || 'N/A'}
        </Text>
      </Table.Td>
      <Table.Td>
        <Text size="sm" fw={500}>
          {formatCurrency(invoice.total_amount)}
        </Text>
      </Table.Td>
      <Table.Td>
        {getStatusBadge(invoice.status)}
      </Table.Td>
      <Table.Td>
        <Group gap="xs">
          <Text size="sm">{invoice.accuracy ?? 'N/A'}{invoice.accuracy ? '%' : ''}</Text>
          {invoice.accuracy && (
            <Badge
              color={invoice.accuracy >= 95 ? 'green' : invoice.accuracy >= 80 ? 'orange' : 'red'}
              variant="light"
              size="xs"
            >
              {invoice.accuracy >= 95 ? 'Cao' : invoice.accuracy >= 80 ? 'Trung bình' : 'Thấp'}
            </Badge>
          )}
        </Group>
      </Table.Td>
      <Table.Td>
        <Group gap="xs">
          <Tooltip label="Xem chi tiết">
            <ActionIcon
              variant="light"
              size="sm"
              onClick={() => viewInvoiceDetail(invoice)}
            >
              <IconEye size="0.8rem" />
            </ActionIcon>
          </Tooltip>
          <Tooltip label="Tải xuống">
            <ActionIcon variant="light" size="sm">
              <IconDownload size="0.8rem" />
            </ActionIcon>
          </Tooltip>
          <Menu shadow="md" width={200}>
            <Menu.Target>
              <ActionIcon variant="light" size="sm">
                <IconChevronDown size="0.8rem" />
              </ActionIcon>
            </Menu.Target>
            <Menu.Dropdown>
              <Menu.Item leftSection={<IconEdit style={{ width: rem(14), height: rem(14) }} />}>
                Chỉnh sửa
              </Menu.Item>
              <Menu.Item 
                leftSection={<IconRefresh style={{ width: rem(14), height: rem(14) }} />}
                onClick={() => handleReprocessInvoice(invoice.invoice_id.toString())}
              >
                Xử lý lại
              </Menu.Item>
              <Menu.Divider />
              <Menu.Item 
                color="red"
                leftSection={<IconTrash style={{ width: rem(14), height: rem(14) }} />}
                onClick={() => handleDeleteInvoice(invoice.invoice_id.toString())}
              >
                Xóa
              </Menu.Item>
            </Menu.Dropdown>
          </Menu>
        </Group>
      </Table.Td>
    </Table.Tr>
  ));

  return (
    <Stack gap="lg">
      {/* Header */}
      <Group justify="space-between">
        <div>
          <Text size="xl" fw={700}>
            Quản lý hóa đơn
          </Text>
          <Text c="dimmed" size="sm">
            Tìm kiếm, lọc và quản lý dữ liệu hóa đơn đã xử lý
          </Text>
        </div>
        <Group>
          {selectedRows.length > 0 && (
            <>
              <Button
                leftSection={<IconFileExport size="1rem" />}
                variant="light"
                onClick={exportSelected}
              >
                Xuất ({selectedRows.length})
              </Button>
              <Button
                leftSection={<IconTrash size="1rem" />}
                color="red"
                variant="light"
                onClick={deleteSelected}
              >
                Xóa ({selectedRows.length})
              </Button>
            </>
          )}
        </Group>
      </Group>

      {/* Filters */}
      <Card withBorder p="lg" radius="md">
        <Group justify="space-between" mb="md">
          <Text fw={600} size="lg">
            Bộ lọc tìm kiếm
          </Text>
          <Button
            variant="light"
            leftSection={<IconX size="1rem" />}
            onClick={clearFilters}
          >
            Xóa bộ lọc
          </Button>
        </Group>
        
        <Grid>
          <Grid.Col span={{ base: 12, md: 6, lg: 3 }}>
            <TextInput
              label="Tìm kiếm"
              placeholder="Tên cửa hàng, số hóa đơn, tên file..."
              leftSection={<IconSearch size="1rem" />}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </Grid.Col>
          <Grid.Col span={{ base: 12, md: 6, lg: 3 }}>
            <Select
              label="Trạng thái"
              placeholder="Chọn trạng thái"
              data={statusOptions}
              value={statusFilter}
              onChange={setStatusFilter}
              clearable
            />
          </Grid.Col>
          <Grid.Col span={{ base: 12, md: 6, lg: 3 }}>
            <MultiSelect
              label="Cửa hàng"
              placeholder="Chọn cửa hàng"
              data={storeOptions}
              value={storeFilter}
              onChange={setStoreFilter}
              searchable
              clearable
            />
          </Grid.Col>
          <Grid.Col span={{ base: 12, md: 6, lg: 3 }}>
            <NumberInput
              label="Độ chính xác tối thiểu (%)"
              placeholder="80"
              min={0}
              max={100}
              value={minAccuracy}
              onChange={setMinAccuracy}
            />
          </Grid.Col>
          <Grid.Col span={{ base: 12, md: 6, lg: 3 }}>
            <DateInput
              label="Từ ngày"
              placeholder="Chọn ngày"
              value={dateFrom}
              onChange={(value) => setDateFrom(value ? new Date(value) : null)}
              clearable
            />
          </Grid.Col>
          <Grid.Col span={{ base: 12, md: 6, lg: 3 }}>
            <DateInput
              label="Đến ngày"
              placeholder="Chọn ngày"
              value={dateTo}
              onChange={(value) => setDateTo(value ? new Date(value) : null)}
              clearable
            />
          </Grid.Col>
          <Grid.Col span={{ base: 12, md: 6, lg: 3 }}>
            <NumberInput
              label="Số tiền từ (VNĐ)"
              placeholder="0"
              min={0}
              value={minAmount}
              onChange={setMinAmount}
              thousandSeparator=","
            />
          </Grid.Col>
          <Grid.Col span={{ base: 12, md: 6, lg: 3 }}>
            <NumberInput
              label="Số tiền đến (VNĐ)"
              placeholder="10,000,000"
              min={0}
              value={maxAmount}
              onChange={setMaxAmount}
              thousandSeparator=","
            />
          </Grid.Col>
        </Grid>
      </Card>

      {/* Results */}
      <Card withBorder p="lg" radius="md">
        <Group justify="space-between" mb="md">
          <Text fw={600} size="lg">
            Kết quả tìm kiếm
          </Text>
          <Group>
            <Badge variant="light">
              {invoices.length} hóa đơn
            </Badge>
            <Button
              leftSection={<IconRefresh size="1rem" />}
              variant="light"
              size="sm"
              onClick={fetchInvoices}
              loading={loading}
            >
              Làm mới
            </Button>
          </Group>
        </Group>
        
        <ScrollArea>
          <Table verticalSpacing="sm">
            <Table.Thead>
              <Table.Tr>
                <Table.Th>
                  <Checkbox
                    checked={selectedRows.length === invoices.length && invoices.length > 0}
                    indeterminate={selectedRows.length > 0 && selectedRows.length < invoices.length}
                    onChange={toggleAllRows}
                  />
                </Table.Th>
                <Table.Th>Số hóa đơn</Table.Th>
                <Table.Th>Cửa hàng</Table.Th>
                <Table.Th>Ngày</Table.Th>
                <Table.Th>Tổng tiền</Table.Th>
                <Table.Th>Trạng thái</Table.Th>
                <Table.Th>Độ chính xác</Table.Th>
                <Table.Th>Thao tác</Table.Th>
              </Table.Tr>
            </Table.Thead>
            <Table.Tbody>
                {invoices.length === 0 ? (
                  <Table.Tr>
                    <Table.Td colSpan={8}>
                      <Center py="xl">
                        <Stack align="center" gap="md">
                          <IconAlertTriangle size="3rem" color="gray" />
                          <Text size="lg" c="dimmed">
                            Không tìm thấy hóa đơn nào
                          </Text>
                          <Text size="sm" c="dimmed">
                            Thử điều chỉnh bộ lọc tìm kiếm của bạn
                          </Text>
                        </Stack>
                      </Center>
                    </Table.Td>
                  </Table.Tr>
                ) : (
                  invoiceRows
                )}
              </Table.Tbody>
            </Table>
          </ScrollArea>
        
        {/* Pagination */}
        {totalPages > 1 && (
          <Group justify="center" mt="md">
            <Pagination
              value={currentPage}
              onChange={setCurrentPage}
              total={totalPages}
              size="sm"
            />
          </Group>
        )}
      </Card>

      {/* Invoice Detail Modal */}
      <Modal
        opened={detailOpened}
        onClose={closeDetail}
        title={`Chi tiết hóa đơn: ${selectedInvoice?.invoice_number}`}
        size="xl"
      >
        {selectedInvoice && (
          <Tabs defaultValue="info">
            <Tabs.List>
              <Tabs.Tab value="info">Thông tin</Tabs.Tab>
              <Tabs.Tab value="raw">Dữ liệu thô</Tabs.Tab>
            </Tabs.List>

            <Tabs.Panel value="info" pt="md">
              <Stack gap="md">
                <Grid>
                  <Grid.Col span={6}>
                    <Text fw={500}>Tên cửa hàng:</Text>
                    <Text>{selectedInvoice.store_name}</Text>
                  </Grid.Col>
                  <Grid.Col span={6}>
                    <Text fw={500}>Số hóa đơn:</Text>
                    <Text>{selectedInvoice.invoice_number}</Text>
                  </Grid.Col>
                  <Grid.Col span={6}>
                    <Text fw={500}>Ngày:</Text>
                    <Text>{selectedInvoice.invoice_date || 'N/A'}</Text>
                  </Grid.Col>
                  <Grid.Col span={6}>
                    <Text fw={500}>Địa chỉ:</Text>
                    <Text>{selectedInvoice.store_address}</Text>
                  </Grid.Col>
                  <Grid.Col span={6}>
                    <Text fw={500}>Tổng tiền:</Text>
                    <Text fw={600}>{formatCurrency(selectedInvoice.total_amount)}</Text>
                  </Grid.Col>
                  <Grid.Col span={6}>
                    <Text fw={500}>Trạng thái:</Text>
                    <Badge color={selectedInvoice.status === 'completed' ? 'green' : selectedInvoice.status === 'processing' ? 'orange' : selectedInvoice.status === 'uploaded' ? 'blue' : 'red'}>
                      {selectedInvoice.status}
                    </Badge>
                  </Grid.Col>
                  <Grid.Col span={6}>
                    <Text fw={500}>Thời gian tải lên:</Text>
                    <Text>{selectedInvoice.upload_time || 'N/A'}</Text>
                  </Grid.Col>
                  <Grid.Col span={6}>
                    <Text fw={500}>Thời gian xử lý:</Text>
                    <Text>{selectedInvoice.processed_time || 'N/A'}</Text>
                  </Grid.Col>
                </Grid>
              </Stack>
            </Tabs.Panel>



            <Tabs.Panel value="raw" pt="md">
              <JsonInput
                value={JSON.stringify(selectedInvoice, null, 2)}
                readOnly
                autosize
                minRows={15}
              />
            </Tabs.Panel>
          </Tabs>
        )}
      </Modal>
    </Stack>
  );
}