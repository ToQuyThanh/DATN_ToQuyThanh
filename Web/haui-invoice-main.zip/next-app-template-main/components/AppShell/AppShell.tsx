'use client';

import { useState } from 'react';
import {
  AppShell,
  Burger,
  Group,
  Text,
  NavLink,
  TextInput,
  ActionIcon,
  Menu,
  Avatar,
  UnstyledButton,
  rem,
  Divider,
} from '@mantine/core';
import { useDisclosure } from '@mantine/hooks';
import { ColorSchemeToggle } from '../ColorSchemeToggle/ColorSchemeToggle';
import { Dashboard } from '../Dashboard/Dashboard';
import { UploadInvoice } from '../UploadInvoice/UploadInvoice';
import { ProcessingInvoice } from '../ProcessingInvoice/ProcessingInvoice';
import { ManagementInvoice } from '../ManagementInvoice/ManagementInvoice';
import { Settings } from '../Settings/Settings';
import {
  IconDashboard,
  IconFileUpload,
  IconFileText,
  IconDatabase,
  IconSettings,
  IconSearch,
  IconBell,
  IconUser,
  IconLogout,
  IconChevronDown,
} from '@tabler/icons-react';

interface AppShellLayoutProps {
  children?: React.ReactNode;
}

export function AppShellLayout({ children }: AppShellLayoutProps) {
  const [opened, { toggle }] = useDisclosure();
  const [active, setActive] = useState('dashboard');

  const menuItems = [
    { icon: IconDashboard, label: 'Dashboard', value: 'dashboard' },
    { icon: IconFileUpload, label: 'Nhận hóa đơn', value: 'upload' },
    { icon: IconFileText, label: 'Xử lý hóa đơn', value: 'process' },
    { icon: IconDatabase, label: 'Quản lý hóa đơn', value: 'manage' },
    { icon: IconSettings, label: 'Cài đặt', value: 'settings' },
  ];

  const renderContent = () => {
    switch (active) {
      case 'dashboard':
        return <Dashboard />;
      case 'upload':
        return <UploadInvoice />;
      case 'process':
        return <ProcessingInvoice />;
      case 'manage':
        return <ManagementInvoice />;
      case 'settings':
        return <Settings />;
      default:
        return children || <Dashboard />;
    }
  };

  return (
    <AppShell
      header={{ height: 60 }}
      navbar={{
        width: 280,
        breakpoint: 'sm',
        collapsed: { mobile: !opened },
      }}
      padding="md"
    >
      <AppShell.Header>
        <Group h="100%" px="md" justify="space-between">
          <Group>
            <Burger opened={opened} onClick={toggle} hiddenFrom="sm" size="sm" />
            <Text size="lg" fw={700} c="blue">
              Invoice Processing System
            </Text>
          </Group>

          <Group>
            <TextInput
              placeholder="Tìm kiếm..."
              leftSection={<IconSearch size="1rem" />}
              visibleFrom="md"
              style={{ width: rem(300) }}
            />
            
            <ActionIcon variant="light" size="lg">
              <IconBell size="1.2rem" />
            </ActionIcon>

            <ColorSchemeToggle />

            <Menu shadow="md" width={200}>
              <Menu.Target>
                <UnstyledButton>
                  <Group gap="xs">
                    <Avatar size="sm" color="blue">
                      A
                    </Avatar>
                    <Text size="sm" fw={500} visibleFrom="md">
                      Admin User
                    </Text>
                    <IconChevronDown size="1rem" />
                  </Group>
                </UnstyledButton>
              </Menu.Target>

              <Menu.Dropdown>
                <Menu.Item leftSection={<IconUser size="1rem" />}>
                  Hồ sơ cá nhân
                </Menu.Item>
                <Menu.Item leftSection={<IconSettings size="1rem" />}>
                  Cài đặt tài khoản
                </Menu.Item>
                <Menu.Divider />
                <Menu.Item leftSection={<IconLogout size="1rem" />} color="red">
                  Đăng xuất
                </Menu.Item>
              </Menu.Dropdown>
            </Menu>
          </Group>
        </Group>
      </AppShell.Header>

      <AppShell.Navbar p="md">
        <AppShell.Section grow>
          <Text size="xs" tt="uppercase" fw={700} c="dimmed" mb="md">
            Menu chính
          </Text>
          
          {menuItems.map((item) => (
            <NavLink
              key={item.value}
              active={active === item.value}
              label={item.label}
              leftSection={<item.icon size="1rem" />}
              onClick={() => setActive(item.value)}
              mb="xs"
            />
          ))}
        </AppShell.Section>

        <AppShell.Section>
          <Divider mb="md" />
          <Text size="xs" c="dimmed">
            Version 1.0.0
          </Text>
        </AppShell.Section>
      </AppShell.Navbar>

      <AppShell.Main>{renderContent()}</AppShell.Main>
    </AppShell>
  );
}