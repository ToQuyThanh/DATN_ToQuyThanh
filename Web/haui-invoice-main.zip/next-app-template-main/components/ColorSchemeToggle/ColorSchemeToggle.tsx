'use client';

import { ActionIcon, useMantineColorScheme, useComputedColorScheme, Tooltip } from '@mantine/core';
import { IconSun, IconMoon } from '@tabler/icons-react';

export function ColorSchemeToggle() {
  const { setColorScheme } = useMantineColorScheme();
  const computedColorScheme = useComputedColorScheme('light', { getInitialValueInEffect: true });

  return (
    <Tooltip label={computedColorScheme === 'dark' ? 'Chế độ sáng' : 'Chế độ tối'}>
      <ActionIcon
        onClick={() => setColorScheme(computedColorScheme === 'dark' ? 'light' : 'dark')}
        variant="light"
        size="lg"
        aria-label="Toggle color scheme"
      >
        {computedColorScheme === 'dark' ? (
          <IconSun size="1.2rem" />
        ) : (
          <IconMoon size="1.2rem" />
        )}
      </ActionIcon>
    </Tooltip>
  );
}
