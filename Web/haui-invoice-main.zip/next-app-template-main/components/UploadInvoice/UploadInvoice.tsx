'use client';

import { useState } from 'react';
import {
  Stack,
  Text,
  Card,
  Group,
  Button,
  Grid,
  Table,
  Badge,
  Progress,
  ActionIcon,
  ThemeIcon,
  List,
  Alert,
  ScrollArea,
  Divider,
  Loader,
} from '@mantine/core';
import { Dropzone, FileWithPath, MIME_TYPES } from '@mantine/dropzone';
import { notifications } from '@mantine/notifications';
import {
  IconCloudUpload,
  IconUpload,
  IconX,
  IconFileText,
  IconPhoto,
  IconFile,
  IconEye,
  IconTrash,
  IconInfoCircle,
  IconAlertCircle,
} from '@tabler/icons-react';
import { invoiceApi, type UploadResponse, type ExtractResponse } from '../../lib/api';

interface UploadedFile {
  id: string;
  file: FileWithPath;
  status: 'uploading' | 'uploaded' | 'processing' | 'completed' | 'error';
  progress: number;
  error?: string;
  result?: {
    invoice_id: number;
    accuracy?: number;
    extractedData?: any;
  };
}

const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
const ACCEPTED_TYPES = [MIME_TYPES.pdf, MIME_TYPES.png, MIME_TYPES.jpeg];

export function UploadInvoice() {
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleDrop = (droppedFiles: FileWithPath[]) => {
    const validFiles = droppedFiles.filter((file) => {
      if (file.size > MAX_FILE_SIZE) {
        notifications.show({
          title: 'File quá lớn',
          message: `File ${file.name} vượt quá 10MB`,
          color: 'red',
          icon: <IconX size="1rem" />,
        });
        return false;
      }
      return true;
    });

    const newFiles: UploadedFile[] = validFiles.map((file) => ({
      id: Math.random().toString(36).substr(2, 9),
      file,
      status: 'uploading',
      progress: 0,
    }));

    setFiles((prev) => [...prev, ...newFiles]);

    // Upload files using real API
    newFiles.forEach((uploadFile) => {
      uploadFileToServer(uploadFile.id, uploadFile.file);
    });
  };

  const uploadFileToServer = async (fileId: string, file: FileWithPath) => {
    try {

      // Simulate progress updates
      const progressInterval = setInterval(() => {
        setFiles((prev) =>
          prev.map((f) => {
            if (f.id === fileId && f.status === 'uploading') {
              const newProgress = Math.min(f.progress + Math.random() * 30, 90);
              return { ...f, progress: newProgress };
            }
            return f;
          })
        );
      }, 200);

      const response = await invoiceApi.upload(file, { uploaded_by: 1 });
      
      clearInterval(progressInterval);
      
      setFiles((prev) =>
        prev.map((f) =>
          f.id === fileId
            ? { 
                ...f, 
                status: 'uploaded', 
                progress: 100, 
                result: { 
                  invoice_id: response.data.invoice_id,
                  accuracy: 95, // Default accuracy
                  extractedData: response.data 
                } 
              }
            : f
        )
      );

      notifications.show({
        title: 'Upload thành công',
        message: `File ${file.name} đã được upload thành công`,
        color: 'green',
      });
    } catch (error) {
      setFiles((prev) =>
        prev.map((f) =>
          f.id === fileId
            ? { ...f, status: 'error', progress: 100, error: 'Lỗi xử lý file' }
            : f
        )
      );

      notifications.show({
        title: 'Lỗi upload',
        message: 'Không thể upload file',
        color: 'red',
        icon: <IconX size="1rem" />,
      });
    }
  };

  const processFile = async (fileId: string) => {
    try {
      const file = files.find(f => f.id === fileId);
      if (!file || !file.result?.invoice_id) return;

      setFiles((prev) =>
        prev.map((f) =>
          f.id === fileId ? { ...f, status: 'processing', progress: 0 } : f
        )
      );

      // Simulate processing progress
      const progressInterval = setInterval(() => {
        setFiles((prev) =>
          prev.map((f) => {
            if (f.id === fileId && f.status === 'processing') {
              const newProgress = Math.min(f.progress + Math.random() * 20, 90);
              return { ...f, progress: newProgress };
            }
            return f;
          })
        );
      }, 300);

      const response = await invoiceApi.process(file.result.invoice_id);
      
      clearInterval(progressInterval);

      setFiles((prev) =>
        prev.map((f) =>
          f.id === fileId
            ? {
                ...f,
                status: 'completed',
                progress: 100,
                result: {
                  invoice_id: f.result?.invoice_id || 0,
                  accuracy: 90, // Default accuracy for processed files
                  extractedData: response.data || {},
                },
              }
            : f
        )
      );

      notifications.show({
        title: 'Xử lý thành công',
        message: 'Hóa đơn đã được xử lý thành công',
        color: 'green',
      });
    } catch (error) {
      setFiles((prev) =>
        prev.map((f) =>
          f.id === fileId
            ? { ...f, status: 'error', progress: 100, error: 'Lỗi xử lý file' }
            : f
        )
      );

      notifications.show({
        title: 'Lỗi xử lý',
        message: 'Không thể xử lý file',
        color: 'red',
        icon: <IconX size="1rem" />,
      });
    }
  };

  const processAllFiles = async () => {
    setIsProcessing(true);
    const uploadedFiles = files.filter((file) => file.status === 'uploaded');
    
    try {
      await Promise.all(uploadedFiles.map((file) => processFile(file.id)));
    } catch (error) {
      notifications.show({
        title: 'Lỗi xử lý hàng loạt',
        message: 'Một số file không thể xử lý được',
        color: 'orange',
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const removeFile = (fileId: string) => {
    setFiles((prev) => prev.filter((file) => file.id !== fileId));
  };

  const getStatusBadge = (status: UploadedFile['status']) => {
    const statusConfig = {
      uploading: { color: 'blue', label: 'Đang tải lên' },
      uploaded: { color: 'green', label: 'Đã tải lên' },
      processing: { color: 'orange', label: 'Đang xử lý' },
      completed: { color: 'green', label: 'Hoàn thành' },
      error: { color: 'red', label: 'Lỗi' },
    };
    
    const config = statusConfig[status];
    return <Badge color={config.color} variant="light">{config.label}</Badge>;
  };

  const getFileIcon = (fileName: string) => {
    const extension = fileName.split('.').pop()?.toLowerCase();
    if (extension === 'pdf') return <IconFileText size="1rem" />;
    if (['jpg', 'jpeg', 'png'].includes(extension || '')) return <IconPhoto size="1rem" />;
    return <IconFile size="1rem" />;
  };

  const fileRows = files.map((uploadFile) => (
    <Table.Tr key={uploadFile.id}>
      <Table.Td>
        <Group gap="sm">
          <ThemeIcon variant="light" size="sm">
            {getFileIcon(uploadFile.file.name)}
          </ThemeIcon>
          <div>
            <Text size="sm" fw={500}>
              {uploadFile.file.name}
            </Text>
            <Text size="xs" c="dimmed">
              {(uploadFile.file.size / 1024 / 1024).toFixed(2)} MB
            </Text>
          </div>
        </Group>
      </Table.Td>
      <Table.Td>
        {getStatusBadge(uploadFile.status)}
      </Table.Td>
      <Table.Td>
        <Group gap="xs">
          <Progress
            value={uploadFile.progress}
            size="sm"
            style={{ flex: 1 }}
            color={uploadFile.status === 'error' ? 'red' : 'blue'}
          />
          <Text size="xs" c="dimmed">
            {Math.round(uploadFile.progress)}%
          </Text>
        </Group>
      </Table.Td>
      <Table.Td>
        {uploadFile.result && (
          <Text size="sm" fw={500}>
            {uploadFile.result.accuracy}%
          </Text>
        )}
        {uploadFile.error && (
          <Text size="sm" c="red">
            Lỗi
          </Text>
        )}
      </Table.Td>
      <Table.Td>
        <Group gap="xs">
          {uploadFile.status === 'uploaded' && (
            <Button
              size="xs"
              variant="light"
              onClick={() => processFile(uploadFile.id)}
              disabled={isProcessing}
            >
              Xử lý
            </Button>
          )}
          {uploadFile.status === 'completed' && (
            <ActionIcon variant="light" size="sm">
              <IconEye size="0.8rem" />
            </ActionIcon>
          )}
          <ActionIcon
            variant="light"
            color="red"
            size="sm"
            onClick={() => removeFile(uploadFile.id)}
          >
            <IconTrash size="0.8rem" />
          </ActionIcon>
        </Group>
      </Table.Td>
    </Table.Tr>
  ));

  const uploadedCount = files.filter((f) => f.status === 'uploaded').length;
  const processingCount = files.filter((f) => f.status === 'processing').length;
  const completedCount = files.filter((f) => f.status === 'completed').length;
  const errorCount = files.filter((f) => f.status === 'error').length;

  return (
    <Stack gap="lg">
      {/* Header */}
      <Group justify="space-between">
        <div>
          <Text size="xl" fw={700}>
            Nhận hóa đơn
          </Text>
          <Text c="dimmed" size="sm">
            Upload và xử lý hóa đơn bằng OCR và DocUnet
          </Text>
        </div>
      </Group>

      <Grid>
        {/* Upload Area */}
        <Grid.Col span={{ base: 12, md: 8 }}>
          <Card withBorder p="lg" radius="md">
            <Stack gap="md">
              <Group justify="space-between">
                <Text fw={600} size="lg">
                  Tải lên hóa đơn
                </Text>
                {uploadedCount > 0 && (
                  <Button
                    leftSection={<IconCloudUpload size="1rem" />}
                    onClick={processAllFiles}
                    disabled={isProcessing || uploadedCount === 0}
                    loading={isProcessing}
                  >
                    Xử lý tất cả ({uploadedCount})
                  </Button>
                )}
              </Group>

              <Dropzone
                onDrop={handleDrop}
                onReject={(rejectedFiles) => {
                  rejectedFiles.forEach((file) => {
                    notifications.show({
                      title: 'File không hợp lệ',
                      message: `${file.file.name}: ${file.errors[0]?.message}`,
                      color: 'red',
                      icon: <IconX size="1rem" />,
                    });
                  });
                }}
                maxSize={MAX_FILE_SIZE}
                accept={ACCEPTED_TYPES}
                multiple
              >
                <Group justify="center" gap="xl" mih={220} style={{ pointerEvents: 'none' }}>
                  <Dropzone.Accept>
                    <IconUpload size="3.2rem" stroke={1.5} />
                  </Dropzone.Accept>
                  <Dropzone.Reject>
                    <IconX size="3.2rem" stroke={1.5} />
                  </Dropzone.Reject>
                  <Dropzone.Idle>
                    <IconCloudUpload size="3.2rem" stroke={1.5} />
                  </Dropzone.Idle>

                  <div>
                    <Text size="xl" inline>
                      Kéo thả file vào đây hoặc click để chọn
                    </Text>
                    <Text size="sm" c="dimmed" inline mt={7}>
                      Hỗ trợ file PDF, JPG, PNG (tối đa 10MB mỗi file)
                    </Text>
                  </div>
                </Group>
              </Dropzone>

              {files.length > 0 && (
                <>
                  <Divider />
                  <ScrollArea>
                    <Table verticalSpacing="sm">
                      <Table.Thead>
                        <Table.Tr>
                          <Table.Th>File</Table.Th>
                          <Table.Th>Trạng thái</Table.Th>
                          <Table.Th>Tiến độ</Table.Th>
                          <Table.Th>Độ chính xác</Table.Th>
                          <Table.Th>Thao tác</Table.Th>
                        </Table.Tr>
                      </Table.Thead>
                      <Table.Tbody>{fileRows}</Table.Tbody>
                    </Table>
                  </ScrollArea>
                </>
              )}
            </Stack>
          </Card>
        </Grid.Col>

        {/* Instructions & Stats */}
        <Grid.Col span={{ base: 12, md: 4 }}>
          <Stack gap="md">
            {/* Instructions */}
            <Card withBorder p="lg" radius="md">
              <Group mb="md">
                <ThemeIcon color="blue" variant="light">
                  <IconInfoCircle size="1rem" />
                </ThemeIcon>
                <Text fw={600}>Hướng dẫn sử dụng</Text>
              </Group>
              
              <List spacing="xs" size="sm">
                <List.Item>Chọn file hóa đơn (PDF, JPG, PNG)</List.Item>
                <List.Item>Kích thước file tối đa 10MB</List.Item>
                <List.Item>Hóa đơn cần rõ nét, không bị mờ</List.Item>
                <List.Item>Hệ thống sẽ tự động xử lý và trích xuất thông tin</List.Item>
                <List.Item>Kiểm tra độ chính xác sau khi xử lý</List.Item>
              </List>
            </Card>

            {/* Processing Stats */}
            {files.length > 0 && (
              <Card withBorder p="lg" radius="md">
                <Text fw={600} mb="md">
                  Thống kê xử lý
                </Text>
                
                <Stack gap="xs">
                  <Group justify="space-between">
                    <Text size="sm">Tổng file:</Text>
                    <Badge variant="light">{files.length}</Badge>
                  </Group>
                  <Group justify="space-between">
                    <Text size="sm">Đã tải lên:</Text>
                    <Badge color="green" variant="light">{uploadedCount}</Badge>
                  </Group>
                  <Group justify="space-between">
                    <Text size="sm">Đang xử lý:</Text>
                    <Badge color="orange" variant="light">{processingCount}</Badge>
                  </Group>
                  <Group justify="space-between">
                    <Text size="sm">Hoàn thành:</Text>
                    <Badge color="green" variant="light">{completedCount}</Badge>
                  </Group>
                  {errorCount > 0 && (
                    <Group justify="space-between">
                      <Text size="sm">Lỗi:</Text>
                      <Badge color="red" variant="light">{errorCount}</Badge>
                    </Group>
                  )}
                </Stack>
              </Card>
            )}

            {/* Warnings */}
            <Alert
              icon={<IconAlertCircle size="1rem" />}
              title="Lưu ý quan trọng"
              color="orange"
            >
              <Text size="sm">
                Đảm bảo hóa đơn có chất lượng tốt để đạt độ chính xác cao nhất. 
                Hệ thống sẽ từ chối xử lý các file không đọc được.
              </Text>
            </Alert>
          </Stack>
        </Grid.Col>
      </Grid>
    </Stack>
  );
}