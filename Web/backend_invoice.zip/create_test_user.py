#!/usr/bin/env python3
"""
Script to create a test user for testing upload functionality
"""
import asyncio
import sys
import os
from datetime import datetime

# Add the src directory to Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from backend_invoice.database import get_async_db
from backend_invoice.db_models import User

async def create_test_user():
    """Create a test user in the database"""
    async for session in get_async_db():
        try:
            # Create test user
            test_user = User(
                username="testuser",
                email="test@example.com",
                full_name="Test User",
                password_hash="test_hash_123"  # In real app, this would be properly hashed
            )
            
            session.add(test_user)
            await session.commit()
            await session.refresh(test_user)
            
            print(f"✅ Test user created successfully!")
            print(f"   User ID: {test_user.user_id}")
            print(f"   Username: {test_user.username}")
            print(f"   Email: {test_user.email}")
            print(f"   Full Name: {test_user.full_name}")
            
            return test_user.user_id
            
        except Exception as e:
            print(f"❌ Error creating test user: {e}")
            await session.rollback()
            return None
        finally:
            await session.close()

if __name__ == "__main__":
    user_id = asyncio.run(create_test_user())
    if user_id:
        print(f"\n🎉 You can now test upload with user_id: {user_id}")
    else:
        print("\n💥 Failed to create test user")