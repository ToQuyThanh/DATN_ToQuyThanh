# Invoice Processing API Documentation

## Tổng quan

API xử lý hóa đơn sử dụng FastAPI với các chức năng chính:
- Upload và xử lý hóa đơn bằng AI (DocUNet + PaddleOCR)
- Quản lý hóa đơn và người dùng
- Dashboard và báo cáo thống kê
- Trích xuất thông tin tự động

**Base URL**: `http://localhost:8000`

**API Documentation**: 
- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

---

## 🏥 Health Check

### GET /health
Kiểm tra tình trạng sức khỏe của API và database.

**Response:**
```json
{
  "status": "healthy",
  "database": {
    "status": "healthy",
    "connection": "ok"
  },
  "timestamp": "2024-01-15T10:30:00.000Z",
  "version": "1.0.0",
  "service": "Invoice Processing API"
}
```

---

## 📊 Dashboard & Analytics

### GET /dashboard/summary
Lấy tổng quan dashboard với thống kê và danh sách hóa đơn gần đây.

**Parameters:**
- `limit` (query, optional): Số lượng hóa đơn gần đây (default: 10)
- `offset` (query, optional): Vị trí bắt đầu (default: 0)

**Response:**
```json
{
  "success": true,
  "data": {
    "statistics": {
      "total_invoices": 150,
      "processed_count": 120,
      "pending_count": 25,
      "failed_count": 5,
      "total_amount": 15750000.0
    },
    "recent_invoices": [
      {
        "invoice_id": 1,
        "invoice_number": "HD001",
        "store_name": "Siêu thị ABC",
        "total_amount": 150000.0,
        "status": "completed",
        "upload_time": "2024-01-15T09:30:00.000Z",
        "processed_time": "2024-01-15T09:35:00.000Z"
      }
    ],
    "pagination": {
      "limit": 10,
      "offset": 0,
      "total": 150
    }
  }
}
```

---

## 📋 Invoice Management

### GET /invoices
Lấy danh sách hóa đơn với filter và pagination.

**Parameters:**
- `query` (query, optional): Tìm kiếm theo tên cửa hàng, số hóa đơn
- `status` (query, optional): Lọc theo trạng thái (`uploaded`, `processing`, `completed`, `failed`)
- `limit` (query, optional): Số lượng kết quả (default: 10)
- `offset` (query, optional): Vị trí bắt đầu (default: 0)

**Response:**
```json
{
  "success": true,
  "data": {
    "invoices": [
      {
        "invoice_id": 1,
        "invoice_number": "HD001",
        "invoice_date": "2024-01-15",
        "store_name": "Siêu thị ABC",
        "store_address": "123 Đường XYZ, Quận 1, TP.HCM",
        "total_amount": 150000.0,
        "status": "completed",
        "upload_time": "2024-01-15T09:30:00.000Z",
        "processed_time": "2024-01-15T09:35:00.000Z",
        "uploaded_by": 1
      }
    ],
    "pagination": {
      "limit": 10,
      "offset": 0,
      "total": 150,
      "has_next": true,
      "has_prev": false
    },
    "filters": {
      "query": null,
      "status": null
    }
  }
}
```

### GET /invoices/{invoice_id}
Lấy thông tin chi tiết hóa đơn theo ID.

**Parameters:**
- `invoice_id` (path): ID của hóa đơn

**Response:**
```json
{
  "success": true,
  "data": {
    "invoice": {
      "invoice_id": 1,
      "invoice_number": "HD001",
      "invoice_date": "2024-01-15",
      "store_name": "Siêu thị ABC",
      "store_address": "123 Đường XYZ, Quận 1, TP.HCM",
      "total_amount": 150000.0,
      "status": "completed",
      "upload_time": "2024-01-15T09:30:00.000Z",
      "processed_time": "2024-01-15T09:35:00.000Z",
      "uploaded_by": 1,
      "original_file_name": "invoice.jpg",
      "file_type": "image/jpeg",
      "items": [
        {
          "item_id": 1,
          "product_name": "Sữa Vinamilk",
          "quantity": 2,
          "unit_price": 30000.0,
          "total_price": 60000.0
        }
      ]
    },
    "logs": [
      {
        "log_id": 1,
        "log_time": "2024-01-15T09:30:00.000Z",
        "message": "Hóa đơn đã được upload thành công",
        "step": "upload",
        "status": "completed"
      }
    ]
  }
}
```

### GET /users/{user_id}/invoices
Lấy danh sách hóa đơn của một user cụ thể.

**Parameters:**
- `user_id` (path): ID của user
- `limit` (query, optional): Số lượng kết quả (default: 50)
- `offset` (query, optional): Vị trí bắt đầu (default: 0)

**Response:**
```json
{
  "success": true,
  "data": {
    "invoices": [
      {
        "invoice_id": 1,
        "invoice_number": "HD001",
        "store_name": "Siêu thị ABC",
        "total_amount": 150000.0,
        "status": "completed",
        "upload_time": "2024-01-15T09:30:00.000Z"
      }
    ],
    "total": 25,
    "limit": 50,
    "offset": 0
  }
}
```

---

## 📤 Invoice Upload & Processing

### POST /invoices/extract
Upload ảnh hóa đơn và trích xuất thông tin ngay lập tức.

**Content-Type**: `multipart/form-data`

**Parameters:**
- `file` (form-data): File ảnh hóa đơn (JPEG, PNG, PDF)
- `uploaded_by` (form-data): ID của user upload (default: 1)

**Supported file types:**
- `image/jpeg`
- `image/png` 
- `image/jpg`
- `application/pdf`

**Response:**
```json
{
  "success": true,
  "message": "Invoice extracted successfully",
  "data": {
    "invoice_id": 123,
    "processing_results": {
      "docunet": {
        "detected_regions": [
          {
            "type": "store_name",
            "text": "Siêu thị ABC",
            "confidence": 0.95
          }
        ],
        "processing_time": 2.5
      },
      "paddle_ocr": {
        "text_lines": [
          {
            "text": "Siêu thị ABC",
            "confidence": 0.98,
            "bbox": [100, 50, 300, 80]
          }
        ],
        "processing_time": 1.8
      },
      "schema_parsing": {
        "extracted_info": {
          "store_name": "Siêu thị ABC",
          "store_address": "123 Đường XYZ",
          "total_amount": 150000.0,
          "items": [
            {
              "product_name": "Sữa Vinamilk",
              "quantity": 2,
              "unit_price": 30000.0,
              "total_price": 60000.0
            }
          ]
        }
      }
    }
  }
}
```

### POST /invoices/{invoice_id}/process
Xử lý trích xuất thông tin hóa đơn đã upload theo ID.

**Parameters:**
- `invoice_id` (path): ID của hóa đơn cần xử lý

**Response:**
```json
{
  "success": true,
  "message": "Invoice processed successfully",
  "data": {
    "invoice_id": 123,
    "docunet_result": {
      "detected_regions": [...],
      "processing_time": 2.5
    },
    "paddle_result": {
      "text_lines": [...],
      "processing_time": 1.8
    },
    "extracted_info": {
      "store_name": "Siêu thị ABC",
      "total_amount": 150000.0,
      "items_count": 3
    }
  }
}
```

---

## 👤 User Management

### POST /users
Tạo user mới trong hệ thống.

**Request Body:**
```json
{
  "username": "testuser",
  "full_name": "Test User",
  "email": "test@example.com",
  "password_hash": "hashed_password",
  "role": "user"
}
```

**Response:**
```json
{
  "user_id": 1,
  "created_at": "2024-01-15T10:30:00.000Z",
  "username": "testuser",
  "full_name": "Test User",
  "email": "test@example.com",
  "role": "user"
}
```

### GET /users/{user_id}
Lấy thông tin chi tiết user theo ID.

**Parameters:**
- `user_id` (path): ID của user

**Response:**
```json
{
  "success": true,
  "data": {
    "user_id": 1,
    "created_at": "2024-01-15T10:30:00.000Z",
    "username": "testuser",
    "full_name": "Test User",
    "email": "test@example.com",
    "role": "user",
    "is_active": "true"
  }
}
```

---

## 📊 Data Models

### Invoice
```json
{
  "invoice_id": 1,
  "invoice_date": "2024-01-15",
  "upload_time": "2024-01-15T09:30:00.000Z",
  "processed_time": "2024-01-15T09:35:00.000Z",
  "uploaded_by": 1,
  "invoice_number": "HD001",
  "store_name": "Siêu thị ABC",
  "store_address": "123 Đường XYZ, Quận 1, TP.HCM",
  "total_amount": 150000.0,
  "status": "completed",
  "original_file_name": "invoice.jpg",
  "file_type": "image/jpeg",
  "file_path": "/path/to/file.jpg"
}
```

### InvoiceItem
```json
{
  "item_id": 1,
  "invoice_id": 1,
  "product_name": "Sữa Vinamilk",
  "quantity": 2,
  "unit_price": 30000.0,
  "total_price": 60000.0
}
```

### InvoiceLog
```json
{
  "log_id": 1,
  "invoice_id": 1,
  "log_time": "2024-01-15T09:30:00.000Z",
  "message": "Hóa đơn đã được upload thành công",
  "step": "upload",
  "status": "completed"
}
```

### User
```json
{
  "user_id": 1,
  "created_at": "2024-01-15T10:30:00.000Z",
  "username": "testuser",
  "full_name": "Test User",
  "email": "test@example.com",
  "password_hash": "hashed_password",
  "role": "user"
}
```

---

## 🔄 Status Values

### Invoice Status
- `uploaded`: Hóa đơn đã được upload
- `processing`: Đang xử lý trích xuất thông tin
- `completed`: Đã hoàn thành xử lý
- `failed`: Xử lý thất bại

### Log Status
- `pending`: Đang chờ xử lý
- `in_progress`: Đang thực hiện
- `done`: Hoàn thành
- `failed`: Thất bại

### Log Steps
- `upload`: Bước upload file
- `processing`: Bước xử lý AI
- `completed`: Hoàn thành toàn bộ
- `error`: Có lỗi xảy ra

---

## ⚠️ Error Handling

### Common Error Responses

**400 Bad Request:**
```json
{
  "detail": "Unsupported file type: text/plain. Allowed: {'image/jpeg', 'image/png', 'image/jpg', 'application/pdf'}"
}
```

**404 Not Found:**
```json
{
  "detail": "Invoice not found"
}
```

**500 Internal Server Error:**
```json
{
  "detail": "Failed to process invoice: Internal processing error"
}
```

---

## 🚀 Integration Tips

### 1. File Upload
```javascript
const formData = new FormData();
formData.append('file', fileInput.files[0]);
formData.append('uploaded_by', userId);

const response = await fetch('/invoices/extract', {
  method: 'POST',
  body: formData
});
```

### 2. Pagination
```javascript
const getInvoices = async (page = 1, limit = 10) => {
  const offset = (page - 1) * limit;
  const response = await fetch(`/invoices?limit=${limit}&offset=${offset}`);
  return response.json();
};
```

### 3. Real-time Status Updates
Sử dụng polling để kiểm tra trạng thái xử lý:
```javascript
const checkProcessingStatus = async (invoiceId) => {
  const response = await fetch(`/invoices/${invoiceId}`);
  const data = await response.json();
  return data.data.invoice.status;
};
```

### 4. Error Handling
```javascript
try {
  const response = await fetch('/invoices/extract', options);
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.detail);
  }
  const data = await response.json();
  return data;
} catch (error) {
  console.error('API Error:', error.message);
}
```

---

## 📝 Notes

1. **Authentication**: Hiện tại API chưa có authentication, cần implement JWT/OAuth2 cho production
2. **Rate Limiting**: Chưa có rate limiting, nên thêm để tránh abuse
3. **File Size**: Nên giới hạn kích thước file upload (recommend: max 10MB)
4. **Caching**: Có thể cache kết quả dashboard để tăng performance
5. **WebSocket**: Có thể thêm WebSocket để real-time updates cho UI

---

*Tài liệu này được tạo tự động từ source code. Cập nhật lần cuối: 2024-01-15*