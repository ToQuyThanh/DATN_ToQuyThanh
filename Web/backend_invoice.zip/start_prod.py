#!/usr/bin/env python3
"""
Production start script
Script khởi động cho production
"""

import subprocess
import sys
from pathlib import Path

def main():
    """Khởi động server production"""
    project_root = Path(__file__).parent
    prod_script = project_root / "scripts" / "run_api.py"
    
    print("🚀 Starting production server...")
    print("📁 Project root:", project_root)
    
    try:
        # Chạy script production
        subprocess.run([sys.executable, str(prod_script)], cwd=project_root)
    except KeyboardInterrupt:
        print("\n👋 Production server stopped")
    except Exception as e:
        print(f"❌ Error starting production server: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()