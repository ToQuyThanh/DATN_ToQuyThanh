# Scripts Directory

Thư mục này chứa các script để khởi chạy và quản lý Invoice Processing API.

## Scripts Available

### 1. `run_api.py` - Production Server
Script chính để chạy API server trong môi trường production với đầy đủ tính năng:

```bash
# Chạy với uv
uv run python scripts/run_api.py

# Hoặc chạy trực tiếp
python scripts/run_api.py
```

**Tính năng:**
- ✅ Logging chuyên nghiệp
- ✅ Environment configuration
- ✅ Graceful shutdown
- ✅ Error handling
- ✅ Multiple workers support
- ✅ Production-ready

### 2. `dev.py` - Development Server
Script đơn giản để chạy development server với hot reload:

```bash
# Chạy với uv
uv run python scripts/dev.py

# Hoặc chạy trực tiếp
python scripts/dev.py
```

**Tính năng:**
- ✅ Hot reload
- ✅ Debug logging
- ✅ Development-friendly
- ✅ Automatic restart on code changes

## Environment Variables

Tạo file `.env` từ `.env.example` để cấu hình:

```bash
cp .env.example .env
```

### Available Variables:

| Variable | Default | Description |
|----------|---------|-------------|
| `HOST` | `0.0.0.0` | Server host |
| `PORT` | `8000` | Server port |
| `ENVIRONMENT` | `production` | Environment mode (`development`/`production`) |
| `WORKERS` | `1` | Number of worker processes |
| `LOG_LEVEL` | `INFO` | Logging level (`DEBUG`/`INFO`/`WARNING`/`ERROR`) |

## API Endpoints

Sau khi khởi chạy, bạn có thể truy cập:

- **API Documentation (Swagger):** http://localhost:8000/docs
- **Alternative Documentation (ReDoc):** http://localhost:8000/redoc
- **Health Check:** http://localhost:8000/health

## Examples

### Development
```bash
# Khởi chạy development server
uv run python scripts/dev.py
```

### Production
```bash
# Khởi chạy production server
ENVIRONMENT=production LOG_LEVEL=INFO uv run python scripts/run_api.py

# Hoặc với nhiều workers
WORKERS=4 uv run python scripts/run_api.py
```

### Custom Configuration
```bash
# Chạy trên port khác
PORT=9000 uv run python scripts/run_api.py

# Chạy với debug logging
LOG_LEVEL=DEBUG uv run python scripts/run_api.py
```

## Logs

Logs được lưu trong thư mục `logs/`:
- `logs/api.log` - Application logs
- Console output - Real-time logs

## Health Check

API cung cấp health check endpoint:

```bash
curl http://localhost:8000/health
```

Response:
```json
{
  "status": "healthy",
  "timestamp": "2024-01-01T12:00:00",
  "version": "1.0.0",
  "service": "Invoice Processing API"
}
```