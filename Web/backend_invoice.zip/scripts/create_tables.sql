-- SQL Scripts để tạo các bảng cho Invoice Management System
-- SQLite Database Schema

-- Bảng Users - Quản lý người dùng
CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    full_name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) DEFAULT 'user'
);

-- Bảng Invoices - Hóa đơn chính
CREATE TABLE IF NOT EXISTS invoices (
    invoice_id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_date DATE NOT NULL,
    upload_time DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
    processed_time DATETIME,
    uploaded_by INTEGER NOT NULL,
    invoice_number VARCHAR(50),
    store_name VARCHAR(200),
    store_address TEXT,
    total_amount DECIMAL(15, 2),
    status VARCHAR(20) DEFAULT 'uploaded',
    original_file_name VARCHAR(255),
    file_type VARCHAR(10),
    FOREIGN KEY (uploaded_by) REFERENCES users (user_id)
);

-- Bảng Invoice Items - Chi tiết sản phẩm trong hóa đơn
CREATE TABLE IF NOT EXISTS invoice_items (
    item_id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_id INTEGER NOT NULL,
    product_name VARCHAR(200) NOT NULL,
    quantity INTEGER NOT NULL,
    unit_price DECIMAL(15, 2) NOT NULL,
    total_price DECIMAL(15, 2) NOT NULL,
    FOREIGN KEY (invoice_id) REFERENCES invoices (invoice_id) ON DELETE CASCADE
);

-- Bảng Invoice Logs - Log xử lý hóa đơn
CREATE TABLE IF NOT EXISTS invoice_logs (
    log_id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_id INTEGER NOT NULL,
    log_time DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
    message TEXT,
    step VARCHAR(50),  -- upload, processing, completed, error
    status VARCHAR(20), -- pending, in_progress, done, failed
    FOREIGN KEY (invoice_id) REFERENCES invoices (invoice_id) ON DELETE CASCADE
);

-- Tạo indexes để tối ưu performance
CREATE INDEX IF NOT EXISTS idx_users_username ON users (username);
CREATE INDEX IF NOT EXISTS idx_users_email ON users (email);

CREATE INDEX IF NOT EXISTS idx_invoices_number ON invoices (invoice_number);
CREATE INDEX IF NOT EXISTS idx_invoices_user_date ON invoices (uploaded_by, invoice_date);
CREATE INDEX IF NOT EXISTS idx_invoices_status_date ON invoices (status, upload_time);

CREATE INDEX IF NOT EXISTS idx_items_invoice ON invoice_items (invoice_id);

CREATE INDEX IF NOT EXISTS idx_logs_invoice_time ON invoice_logs (invoice_id, log_time);

-- Thêm dữ liệu mẫu (optional)
INSERT OR IGNORE INTO users (username, full_name, email, password_hash, role) VALUES 
('admin', 'Administrator', 'admin@example.com', 'hashed_password_here', 'admin'),
('user1', 'Nguyen Van A', 'user1@example.com', 'hashed_password_here', 'user');

-- Thông báo hoàn thành
SELECT 'Database tables created successfully!' as message;