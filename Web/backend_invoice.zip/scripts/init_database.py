#!/usr/bin/env python3
"""
Database Initialization Script
Script khởi tạo database và tạo tables
"""

import asyncio
import logging
import sys
from pathlib import Path

# Thêm src vào Python path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from backend_invoice.database import init_database, close_database, check_database_health
from backend_invoice.db_models import User, Invoice, InvoiceItem, InvoiceLog

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

async def create_sample_data():
    """Tạo dữ liệu mẫu cho testing"""
    from backend_invoice.database import AsyncSessionLocal
    from sqlalchemy import select
    import hashlib
    
    logger.info("🔄 Creating sample data...")
    
    async with AsyncSessionLocal() as session:
        try:
            # Kiểm tra xem đã có user admin chưa
            result = await session.execute(select(User).where(User.username == "admin"))
            admin_user = result.scalar_one_or_none()
            
            if not admin_user:
                # Tạo admin user
                admin_password = hashlib.sha256("admin123".encode()).hexdigest()
                admin_user = User(
                    username="admin",
                    full_name="Administrator",
                    email="admin@invoiceapp.com",
                    password_hash=admin_password,
                    role="admin"
                )
                session.add(admin_user)
                logger.info("✅ Created admin user")
            
            # Kiểm tra user thường
            result = await session.execute(select(User).where(User.username == "user1"))
            regular_user = result.scalar_one_or_none()
            
            if not regular_user:
                # Tạo user thường
                user_password = hashlib.sha256("user123".encode()).hexdigest()
                regular_user = User(
                    username="user1",
                    full_name="Nguyen Van A",
                    email="user1@example.com",
                    password_hash=user_password,
                    role="user"
                )
                session.add(regular_user)
                logger.info("✅ Created regular user")
            
            await session.commit()
            logger.info("✅ Sample data created successfully!")
            
        except Exception as e:
            logger.error(f"❌ Failed to create sample data: {e}")
            await session.rollback()
            raise

async def main():
    """Main function để khởi tạo database"""
    logger.info("🚀 Starting database initialization...")
    
    try:
        # 1. Khởi tạo database và tạo tables
        await init_database()
        
        # 2. Kiểm tra health
        health = await check_database_health()
        if health["status"] == "healthy":
            logger.info("✅ Database health check passed!")
        else:
            logger.error(f"❌ Database health check failed: {health}")
            return False
        
        # 3. Tạo dữ liệu mẫu
        await create_sample_data()
        
        # 4. Thống kê tables
        from backend_invoice.database import AsyncSessionLocal
        async with AsyncSessionLocal() as session:
            # Đếm số lượng records
            from sqlalchemy import text
            
            tables_info = []
            for table_name in ["users", "invoices", "invoice_items", "invoice_logs"]:
                result = await session.execute(text(f"SELECT COUNT(*) FROM {table_name}"))
                count = result.scalar()
                tables_info.append(f"  📊 {table_name}: {count} records")
            
            logger.info("📈 Database Statistics:")
            for info in tables_info:
                logger.info(info)
        
        logger.info("🎉 Database initialization completed successfully!")
        return True
        
    except Exception as e:
        logger.error(f"💥 Database initialization failed: {e}")
        return False
    
    finally:
        await close_database()

def run_sql_script():
    """Chạy SQL script trực tiếp (alternative method)"""
    import sqlite3
    from pathlib import Path
    
    logger.info("🔄 Running SQL script...")
    
    try:
        # Đọc SQL script
        sql_file = Path(__file__).parent / "create_tables.sql"
        if not sql_file.exists():
            logger.error(f"❌ SQL file not found: {sql_file}")
            return False
        
        with open(sql_file, 'r', encoding='utf-8') as f:
            sql_content = f.read()
        
        # Kết nối và chạy script
        conn = sqlite3.connect("invoices.db")
        cursor = conn.cursor()
        
        # Chạy từng statement
        statements = sql_content.split(';')
        for statement in statements:
            statement = statement.strip()
            if statement:
                cursor.execute(statement)
        
        conn.commit()
        conn.close()
        
        logger.info("✅ SQL script executed successfully!")
        return True
        
    except Exception as e:
        logger.error(f"❌ Failed to run SQL script: {e}")
        return False

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Initialize Invoice Database")
    parser.add_argument("--sql-only", action="store_true", 
                       help="Run SQL script only (no SQLAlchemy)")
    parser.add_argument("--no-sample-data", action="store_true",
                       help="Skip creating sample data")
    
    args = parser.parse_args()
    
    if args.sql_only:
        success = run_sql_script()
    else:
        success = asyncio.run(main())
    
    if success:
        print("\n🎉 Database setup completed successfully!")
        print("📝 You can now:")
        print("   - Start the API server: uv run python scripts/run_api.py")
        print("   - Run tests: uv run pytest tests/")
        print("   - Check database: sqlite3 invoices.db")
    else:
        print("\n💥 Database setup failed!")
        sys.exit(1)