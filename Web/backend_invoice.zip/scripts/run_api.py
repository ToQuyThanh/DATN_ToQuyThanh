#!/usr/bin/env python3
"""
Invoice Processing API Server
Khởi chạy server FastAPI với các cấu hình chuyên nghiệp
"""

import os
import sys
import logging
import signal
import asyncio
from pathlib import Path

# Thêm src vào Python path để import được modules
project_root = Path(__file__).parent.parent
src_path = project_root / "src"
sys.path.insert(0, str(src_path))

import uvicorn

def check_database():
    """Kiểm tra database có tồn tại không"""
    db_path = project_root / "invoices.db"
    if not db_path.exists():
        print("WARNING: Database not found. Creating database...")
        try:
            # Import và chạy init database
            from backend_invoice.database import init_database
            asyncio.run(init_database())
            print("SUCCESS: Database created successfully!")
        except Exception as e:
            print(f"ERROR: Failed to create database: {e}")
            print("HINT: Please run: python scripts/init_database.py")
            return False
    return True

def check_dependencies():
    """Kiểm tra các dependencies cần thiết"""
    try:
        import fastapi
        import sqlalchemy
        import pydantic
        return True
    except ImportError as e:
        print(f"ERROR: Missing dependency: {e}")
        print("HINT: Please run: uv sync")
        return False

def check_environment():
    """Kiểm tra môi trường production"""
    print("INFO: Checking production environment...")
    
    # Kiểm tra dependencies
    if not check_dependencies():
        return False
    
    # Kiểm tra database
    if not check_database():
        return False
    
    # Kiểm tra thư mục logs
    logs_dir = project_root / "logs"
    if not logs_dir.exists():
        logs_dir.mkdir(exist_ok=True)
        print("SUCCESS: Created logs directory")
    
    # Kiểm tra thư mục upload
    upload_dir = project_root / "src" / "backend_invoices"
    if not upload_dir.exists():
        upload_dir.mkdir(parents=True, exist_ok=True)
        print("SUCCESS: Created upload directory")
    
    print("SUCCESS: Environment check completed")
    return True

# Cấu hình logging
def setup_logging():
    """Thiết lập logging cho ứng dụng"""
    log_level = os.getenv("LOG_LEVEL", "INFO").upper()
    log_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    
    logging.basicConfig(
        level=getattr(logging, log_level),
        format=log_format,
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler("logs/api.log", mode="a") if os.path.exists("logs") else logging.StreamHandler()
        ]
    )
    
    # Tắt log verbose của uvicorn
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)
    
    logger = logging.getLogger(__name__)
    logger.info(f"Logging configured with level: {log_level}")
    return logger

# Cấu hình môi trường
def get_config():
    """Lấy cấu hình từ environment variables"""
    return {
        "host": os.getenv("HOST", "0.0.0.0"),
        "port": int(os.getenv("PORT", "8000")),
        "reload": os.getenv("ENVIRONMENT", "production").lower() == "development",
        "workers": int(os.getenv("WORKERS", "1")),
        "log_level": os.getenv("LOG_LEVEL", "info").lower(),
    }

# Graceful shutdown handler
def signal_handler(signum, frame):
    """Xử lý tín hiệu shutdown một cách graceful"""
    logger = logging.getLogger(__name__)
    logger.info(f"Received signal {signum}. Shutting down gracefully...")
    sys.exit(0)

def main():
    """Hàm chính để khởi chạy API server"""
    # Kiểm tra môi trường trước khi khởi động
    if not check_environment():
        sys.exit(1)
    
    # Thiết lập logging
    logger = setup_logging()
    
    # Đăng ký signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Lấy cấu hình
    config = get_config()
    
    logger.info("Starting Invoice Processing API Server...")
    logger.info(f"Configuration: {config}")
    logger.info(f"API Documentation: http://{config['host']}:{config['port']}/docs")
    logger.info(f"Health Check: http://{config['host']}:{config['port']}/health")
    logger.info(f"Dashboard: http://{config['host']}:{config['port']}/dashboard/summary")
    
    try:
        # Khởi chạy server
        uvicorn.run(
            "backend_invoice.api:app",
            host=config["host"],
            port=config["port"],
            reload=config["reload"],
            workers=config["workers"] if not config["reload"] else 1,
            log_level=config["log_level"],
            access_log=True,
            server_header=False,
            date_header=False
        )
    except Exception as e:
        logger.error(f"ERROR: Failed to start server: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
    
