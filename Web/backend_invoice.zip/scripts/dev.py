#!/usr/bin/env python3
"""
Development server script
Khởi chạy server ở chế độ development với hot reload
"""

import os
import sys
import asyncio
from pathlib import Path

# Thêm src vào Python path
project_root = Path(__file__).parent.parent
src_path = project_root / "src"
sys.path.insert(0, str(src_path))

import uvicorn

def check_database():
    """Kiểm tra database có tồn tại không"""
    db_path = project_root / "invoices.db"
    if not db_path.exists():
        print("⚠️  Database not found. Creating database...")
        try:
            # Import và chạy init database
            from backend_invoice.database import init_database
            asyncio.run(init_database())
            print("✅ Database created successfully!")
        except Exception as e:
            print(f"❌ Failed to create database: {e}")
            print("💡 Please run: python scripts/init_database.py")
            return False
    else:
        print("✅ Database found")
    return True

def check_dependencies():
    """Kiểm tra các dependencies cần thiết"""
    try:
        import fastapi
        import sqlalchemy
        import pydantic
        print("✅ Core dependencies available")
        return True
    except ImportError as e:
        print(f"❌ Missing dependency: {e}")
        print("💡 Please run: uv sync")
        return False

if __name__ == "__main__":
    print("🔍 Checking development environment...")
    
    # Kiểm tra dependencies
    if not check_dependencies():
        sys.exit(1)
    
    # Kiểm tra database
    if not check_database():
        sys.exit(1)
    
    # Set environment variables for development
    os.environ["ENVIRONMENT"] = "development"
    os.environ["LOG_LEVEL"] = "DEBUG"
    
    print("\n🚀 Starting Invoice Processing API in DEVELOPMENT mode...")
    print("📝 Hot reload enabled")
    print("🔗 API Documentation: http://localhost:8000/docs")
    print("🔗 Interactive API: http://localhost:8000/redoc")
    print("🔗 Health Check: http://localhost:8000/health")
    print("📊 Dashboard Summary: http://localhost:8000/dashboard/summary")
    print("📄 Invoices List: http://localhost:8000/invoices")
    print("👤 Users API: http://localhost:8000/users")
    print("⏹️  Press CTRL+C to stop")
    print("-" * 60)
    
    try:
        uvicorn.run(
            "backend_invoice.api:app",
            host="0.0.0.0",  # Cho phép truy cập từ bên ngoài
            port=8000,
            reload=True,
            log_level="info",  # Thay đổi từ debug để giảm noise
            reload_dirs=[str(src_path)],
            access_log=True
        )
    except KeyboardInterrupt:
        print("\n👋 Server stopped by user")
    except Exception as e:
        print(f"\n❌ Server error: {e}")
        sys.exit(1)