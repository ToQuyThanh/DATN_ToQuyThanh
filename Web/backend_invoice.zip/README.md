# Invoice Processing API

Hệ thống xử lý hóa đơn với FastAPI, SQLAlchemy và AI processing.

## Khởi động nhanh

### Development Mode
```bash
# Cách 1: Script khởi động nhanh
python start_dev.py

# Cách 2: Script development chi tiết
python scripts/dev.py
```

### Production Mode
```bash
# Cách 1: Script khởi động nhanh
python start_prod.py

# Cách 2: Script production chi tiết
python scripts/run_api.py
```

## API Endpoints

### Dashboard & Analytics
- `GET /dashboard/summary` - Tổng quan dashboard
- `GET /dashboard/invoices` - Danh sách hóa đơn với phân trang

### Invoice Management
- `POST /invoices/upload` - Upload hóa đơn
- `POST /invoices/{invoice_id}/process` - Xử lý hóa đơn
- `GET /invoices/{invoice_id}` - Chi tiết hóa đơn
- `GET /users/{user_id}/invoices` - Hóa đơn của user

### User Management
- `POST /users` - Tạo user mới
- `GET /users/{user_id}` - Thông tin user

### Health Check
- `GET /health` - Kiểm tra trạng thái API

## API Documentation

Khi server đang chạy, truy cập:
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

## Cấu trúc thư mục

```
backend_invoice/
├── scripts/           # Scripts khởi động
│   ├── dev.py        # Development server
│   ├── run_api.py    # Production server
│   └── init_database.py
├── src/              # Source code
│   └── backend_invoice/
├── start_dev.py      # Quick start development
├── start_prod.py     # Quick start production
└── README.md
```

## Tính năng

✅ Upload và xử lý hóa đơn (JPG, PNG, PDF)
✅ AI processing với DocUNet và Paddle OCR
✅ Quản lý user và authentication
✅ Dashboard analytics
✅ Database SQLite với SQLAlchemy
✅ API documentation với Swagger
✅ Error handling và validation
✅ File upload với validation
✅ Pagination cho danh sách

## Yêu cầu hệ thống

- Python 3.8+
- FastAPI
- SQLAlchemy
- Pydantic
- Uvicorn

## Cài đặt

```bash
# Cài đặt dependencies
uv sync

# Khởi tạo database (tự động khi chạy lần đầu)
python scripts/init_database.py
```