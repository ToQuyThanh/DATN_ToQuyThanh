import pytest
from fastapi.testclient import TestClient
from datetime import datetime, date
from decimal import Decimal
import io
import sys
import os
from unittest.mock import Mock

# Thêm src vào Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from backend_invoice.api import app
from backend_invoice.models import Invoice, InvoiceItem, InvoiceLog, User

# Tạo test client
client = TestClient(app)

class TestDashboardSummary:
    """Test cho endpoint GET /dashboard/summary"""
    
    def test_get_dashboard_summary_default_params(self):
        """Test lấy dashboard summary với tham số mặc định"""
        response = client.get("/dashboard/summary")
        assert response.status_code == 200
        
        data = response.json()
        assert isinstance(data, list)
        assert len(data) == 1
        
        invoice = data[0]
        assert invoice["invoice_id"] == 1
        assert invoice["invoice_number"] == "HD001"
        assert invoice["store_name"] == "VinMart"
        assert invoice["store_address"] == "123 Đường A"
        assert invoice["total_amount"] == "100000.00"
        assert invoice["status"] == "processed"
    
    def test_get_dashboard_summary_with_params(self):
        """Test lấy dashboard summary với tham số limit và offset"""
        response = client.get("/dashboard/summary?limit=5&offset=10")
        assert response.status_code == 200
        
        data = response.json()
        assert isinstance(data, list)
        # Vì đây là mock data, kết quả vẫn trả về 1 item
        assert len(data) == 1


class TestUploadInvoice:
    """Test cho endpoint POST /invoices/upload"""
    
    def test_upload_invoice_success(self):
        """Test upload hóa đơn thành công"""
        # Tạo file giả
        file_content = b"fake image content"
        files = {"file": ("test_invoice.jpg", io.BytesIO(file_content), "image/jpeg")}
        
        response = client.post("/invoices/upload", files=files)
        assert response.status_code == 200
        
        data = response.json()
        assert data["invoice_id"] == 2
        assert data["status"] == "uploaded"
        assert data["original_file_name"] == "test_invoice.jpg"
        assert data["file_type"] == "image/jpeg"
        assert data["uploaded_by"] == 1
    
    def test_upload_invoice_no_file(self):
        """Test upload hóa đơn khi không có file"""
        response = client.post("/invoices/upload")
        assert response.status_code == 422  # Validation error


class TestInvoiceStatus:
    """Test cho endpoint GET /invoices/status"""
    
    def test_get_invoice_status_no_params(self):
        """Test lấy trạng thái hóa đơn không có tham số"""
        response = client.get("/invoices/status")
        assert response.status_code == 200
        
        data = response.json()
        assert isinstance(data, list)
        assert len(data) == 1
        
        invoice = data[0]
        assert invoice["invoice_id"] == 1
        assert invoice["status"] == "processed"
        assert "logs" in invoice
        assert len(invoice["logs"]) == 1
        
        log = invoice["logs"][0]
        assert log["log_id"] == 1
        assert log["invoice_id"] == 1
        assert log["step"] == "upload"
        assert log["status"] == "done"
        assert log["message"] == "File uploaded"
    
    def test_get_invoice_status_with_invoice_id(self):
        """Test lấy trạng thái hóa đơn với invoice_id"""
        response = client.get("/invoices/status?invoice_id=1")
        assert response.status_code == 200
        
        data = response.json()
        assert isinstance(data, list)
        assert len(data) == 1
    
    def test_get_invoice_status_with_status_filter(self):
        """Test lấy trạng thái hóa đơn với filter status"""
        response = client.get("/invoices/status?status=processed")
        assert response.status_code == 200
        
        data = response.json()
        assert isinstance(data, list)
        assert len(data) == 1


class TestListInvoices:
    """Test cho endpoint GET /invoices"""
    
    def test_list_invoices_no_params(self):
        """Test lấy danh sách hóa đơn không có tham số"""
        response = client.get("/invoices")
        assert response.status_code == 200
        
        data = response.json()
        assert isinstance(data, list)
        assert len(data) == 1
        
        invoice = data[0]
        assert invoice["invoice_id"] == 3
        assert invoice["status"] == "pending"
        assert invoice["uploaded_by"] == 1
    
    def test_list_invoices_with_query(self):
        """Test lấy danh sách hóa đơn với query"""
        response = client.get("/invoices?query=VinMart")
        assert response.status_code == 200
        
        data = response.json()
        assert isinstance(data, list)
    
    def test_list_invoices_with_status_filter(self):
        """Test lấy danh sách hóa đơn với filter status"""
        response = client.get("/invoices?status=pending")
        assert response.status_code == 200
        
        data = response.json()
        assert isinstance(data, list)
    
    def test_list_invoices_with_pagination(self):
        """Test lấy danh sách hóa đơn với phân trang"""
        response = client.get("/invoices?limit=5&offset=10")
        assert response.status_code == 200
        
        data = response.json()
        assert isinstance(data, list)


class TestExtractInvoice:
    """Test cho endpoint POST /invoices/extract"""
    
    def test_extract_invoice_with_invoice_id(self):
        """Test trích xuất thông tin hóa đơn với invoice_id"""
        response = client.post("/invoices/extract?invoice_id=1")
        assert response.status_code == 200
        
        data = response.json()
        assert data["invoice_id"] == 1
        assert data["status"] == "processed"
        assert data["invoice_number"] == "HD004"
        assert data["store_name"] == "VinMart"
        assert data["total_amount"] == "60000.00"
        
        # Kiểm tra items
        assert "items" in data
        assert len(data["items"]) == 1
        
        item = data["items"][0]
        assert item["item_id"] == 1
        assert item["product_name"] == "Sữa Vinamilk"
        assert item["quantity"] == 2
        assert item["unit_price"] == "30000.00"
        assert item["total_price"] == "60000.00"
    
    def test_extract_invoice_with_file(self):
        """Test trích xuất thông tin hóa đơn với file upload"""
        file_content = b"fake image content"
        files = {"file": ("test_invoice.jpg", io.BytesIO(file_content), "image/jpeg")}
        
        response = client.post("/invoices/extract", files=files)
        assert response.status_code == 200
        
        data = response.json()
        assert data["invoice_id"] == 4
        assert data["status"] == "processed"
        assert "items" in data
    
    def test_extract_invoice_no_params(self):
        """Test trích xuất thông tin hóa đơn không có tham số"""
        response = client.post("/invoices/extract")
        assert response.status_code == 200
        
        data = response.json()
        assert data["invoice_id"] == 4
        assert data["status"] == "processed"


class TestCreateUser:
    """Test cho endpoint POST /users"""
    
    def test_create_user_success(self):
        """Test tạo user thành công"""
        user_data = {
            "user_id": 0,  # Sẽ được ghi đè trong API
            "created_at": "2024-01-01T00:00:00",  # Sẽ được ghi đè trong API
            "username": "testuser",
            "full_name": "Test User",
            "email": "test@example.com",
            "password_hash": "hashed_password",
            "role": "user"
        }
        
        response = client.post("/users", json=user_data)
        assert response.status_code == 200
        
        data = response.json()
        assert data["user_id"] == 1  # Được set trong API
        assert data["username"] == "testuser"
        assert data["full_name"] == "Test User"
        assert data["email"] == "test@example.com"
        assert data["role"] == "user"
        assert "created_at" in data
    
    def test_create_user_invalid_email(self):
        """Test tạo user với email không hợp lệ"""
        user_data = {
            "user_id": 0,
            "created_at": "2024-01-01T00:00:00",
            "username": "testuser",
            "full_name": "Test User",
            "email": "invalid-email",  # Email không hợp lệ
            "password_hash": "hashed_password",
            "role": "user"
        }
        
        response = client.post("/users", json=user_data)
        assert response.status_code == 422  # Validation error
    
    def test_create_user_missing_required_fields(self):
        """Test tạo user thiếu các field bắt buộc"""
        user_data = {
            "username": "testuser"
            # Thiếu các field bắt buộc khác
        }
        
        response = client.post("/users", json=user_data)
        assert response.status_code == 422  # Validation error


class TestCreateInvoiceLog:
    """Test cho endpoint POST /invoices/log"""
    
    def test_create_invoice_log_success(self):
        """Test tạo log hóa đơn thành công"""
        log_data = {
            "log_id": 0,  # Sẽ được ghi đè trong API
            "invoice_id": 1,
            "log_time": "2024-01-01T00:00:00",  # Sẽ được ghi đè trong API
            "message": "Test log message",
            "step": "processing",
            "status": "in_progress"
        }
        
        response = client.post("/invoices/log", json=log_data)
        assert response.status_code == 200
        
        data = response.json()
        assert data["log_id"] == 1001  # Được set trong API
        assert data["invoice_id"] == 1
        assert data["message"] == "Test log message"
        assert data["step"] == "processing"
        assert data["status"] == "in_progress"
        assert "log_time" in data
    
    def test_create_invoice_log_missing_invoice_id(self):
        """Test tạo log hóa đơn thiếu invoice_id"""
        log_data = {
            "log_id": 0,
            "log_time": "2024-01-01T00:00:00",
            "message": "Test log message",
            "step": "processing",
            "status": "in_progress"
            # Thiếu invoice_id
        }
        
        response = client.post("/invoices/log", json=log_data)
        assert response.status_code == 422  # Validation error


class TestAPIIntegration:
    """Test tích hợp các API"""
    
    def test_full_invoice_workflow(self):
        """Test quy trình đầy đủ: upload -> extract -> log -> status"""
        
        # 1. Upload hóa đơn
        file_content = b"fake image content"
        files = {"file": ("test_invoice.jpg", io.BytesIO(file_content), "image/jpeg")}
        
        upload_response = client.post("/invoices/upload", files=files)
        assert upload_response.status_code == 200
        upload_data = upload_response.json()
        invoice_id = upload_data["invoice_id"]
        
        # 2. Trích xuất thông tin
        extract_response = client.post(f"/invoices/extract?invoice_id={invoice_id}")
        assert extract_response.status_code == 200
        extract_data = extract_response.json()
        assert extract_data["status"] == "processed"
        
        # 3. Tạo log
        log_data = {
            "log_id": 0,
            "invoice_id": invoice_id,
            "log_time": "2024-01-01T00:00:00",
            "message": "Processing completed",
            "step": "extract",
            "status": "done"
        }
        
        log_response = client.post("/invoices/log", json=log_data)
        assert log_response.status_code == 200
        
        # 4. Kiểm tra trạng thái
        status_response = client.get(f"/invoices/status?invoice_id={invoice_id}")
        assert status_response.status_code == 200
        status_data = status_response.json()
        assert len(status_data) == 1


# Fixtures cho test
@pytest.fixture
def sample_invoice():
    """Fixture tạo invoice mẫu"""
    return Invoice(
        invoice_id=1,
        invoice_date=date.today(),
        upload_time=datetime.now(),
        uploaded_by=1,
        status="pending"
    )

@pytest.fixture
def sample_user():
    """Fixture tạo user mẫu"""
    return User(
        user_id=1,
        created_at=datetime.now(),
        username="testuser",
        full_name="Test User",
        email="test@example.com",
        password_hash="hashed_password",
        role="user"
    )

@pytest.fixture
def sample_invoice_log():
    """Fixture tạo invoice log mẫu"""
    return InvoiceLog(
        log_id=1,
        invoice_id=1,
        log_time=datetime.now(),
        message="Test message",
        step="upload",
        status="done"
    )