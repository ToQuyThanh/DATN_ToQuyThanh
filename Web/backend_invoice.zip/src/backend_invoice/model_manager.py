"""
Model Manager Module
Quản lý việc preload các model AI để tối ưu hiệu suất predict
"""

import logging
import time
from pathlib import Path
from typing import Optional, Dict, Any
import asyncio

from backend_invoice.docunet_deployment.predict import DocUnetPredictor
from backend_invoice.paddle_deployment.paddle_pl import InvoiceOCR

logger = logging.getLogger(__name__)

class ModelManager:
    """
    Singleton class để quản lý việc preload và cache các model AI
    """
    _instance = None
    _initialized = False
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(ModelManager, cls).__new__(cls)
        return cls._instance
    
    def __init__(self):
        if not self._initialized:
            self.docunet_predictor: Optional[DocUnetPredictor] = None
            self.paddle_ocr: Optional[InvoiceOCR] = None
            self._docunet_loaded = False
            self._paddle_loaded = False
            self._loading_stats = {}
            ModelManager._initialized = True
    
    async def initialize_models(self, device: str = 'cpu') -> Dict[str, Any]:
        """
        Khởi tạo và preload tất cả các model
        
        Args:
            device: Device để chạy model ('cpu' hoặc 'cuda')
            
        Returns:
            Dict chứa thông tin về việc load model
        """
        logger.info("🤖 Starting model preloading...")
        start_time = time.time()
        
        results = {
            "docunet": {"status": "pending", "load_time": 0, "error": None},
            "paddle": {"status": "pending", "load_time": 0, "error": None},
            "total_time": 0
        }
        
        # Load DocUnet model
        try:
            await self._load_docunet_model(device)
            results["docunet"]["status"] = "success"
            results["docunet"]["load_time"] = self._loading_stats.get("docunet_time", 0)
            logger.info(f"✅ DocUnet model loaded successfully in {results['docunet']['load_time']:.2f}s")
        except Exception as e:
            results["docunet"]["status"] = "failed"
            results["docunet"]["error"] = str(e)
            logger.error(f"❌ Failed to load DocUnet model: {e}")
        
        # Load Paddle OCR model
        try:
            await self._load_paddle_model(device)
            results["paddle"]["status"] = "success"
            results["paddle"]["load_time"] = self._loading_stats.get("paddle_time", 0)
            logger.info(f"✅ Paddle OCR model loaded successfully in {results['paddle']['load_time']:.2f}s")
        except Exception as e:
            results["paddle"]["status"] = "failed"
            results["paddle"]["error"] = str(e)
            logger.error(f"❌ Failed to load Paddle OCR model: {e}")
        
        total_time = time.time() - start_time
        results["total_time"] = total_time
        
        logger.info(f"🎯 Model preloading completed in {total_time:.2f}s")
        return results
    
    async def _load_docunet_model(self, device: str = 'cpu'):
        """Load DocUnet model"""
        if self._docunet_loaded:
            logger.info("DocUnet model already loaded, skipping...")
            return
        
        logger.info("📥 Loading DocUnet model...")
        start_time = time.time()
        
        # Tìm đường dẫn checkpoint từ project root
        project_root = Path(__file__).parent.parent.parent
        checkpoint_path = project_root / "checkpoint_epoch_080.pth"
        
        if not checkpoint_path.exists():
            raise FileNotFoundError(f"DocUnet checkpoint not found: {checkpoint_path}")
        
        # Load model trong thread pool để không block event loop
        loop = asyncio.get_event_loop()
        self.docunet_predictor = await loop.run_in_executor(
            None, 
            lambda: DocUnetPredictor(checkpoint_path=str(checkpoint_path), device=device)
        )
        
        load_time = time.time() - start_time
        self._loading_stats["docunet_time"] = load_time
        self._docunet_loaded = True
        
        logger.info(f"✅ DocUnet model loaded in {load_time:.2f}s")
    
    async def _load_paddle_model(self, device: str = 'cpu'):
        """Load Paddle OCR model"""
        if self._paddle_loaded:
            logger.info("Paddle OCR model already loaded, skipping...")
            return
        
        logger.info("📥 Loading Paddle OCR model...")
        start_time = time.time()
        
        # Load model trong thread pool để không block event loop
        loop = asyncio.get_event_loop()
        self.paddle_ocr = await loop.run_in_executor(
            None,
            lambda: InvoiceOCR(
                use_doc_orientation_classify=True,
                use_doc_unwarping=True,
                use_textline_orientation=True,
                device=device,
                lang="vi"
            )
        )
        
        load_time = time.time() - start_time
        self._loading_stats["paddle_time"] = load_time
        self._paddle_loaded = True
        
        logger.info(f"✅ Paddle OCR model loaded in {load_time:.2f}s")
    
    def get_docunet_predictor(self) -> Optional[DocUnetPredictor]:
        """
        Lấy DocUnet predictor đã được preload
        
        Returns:
            DocUnetPredictor instance hoặc None nếu chưa load
        """
        if not self._docunet_loaded:
            logger.warning("DocUnet model not loaded yet!")
            return None
        return self.docunet_predictor
    
    def get_paddle_ocr(self) -> Optional[InvoiceOCR]:
        """
        Lấy Paddle OCR đã được preload
        
        Returns:
            InvoiceOCR instance hoặc None nếu chưa load
        """
        if not self._paddle_loaded:
            logger.warning("Paddle OCR model not loaded yet!")
            return None
        return self.paddle_ocr
    
    def is_docunet_ready(self) -> bool:
        """Kiểm tra DocUnet model đã sẵn sàng chưa"""
        return self._docunet_loaded and self.docunet_predictor is not None
    
    def is_paddle_ready(self) -> bool:
        """Kiểm tra Paddle OCR model đã sẵn sàng chưa"""
        return self._paddle_loaded and self.paddle_ocr is not None
    
    def is_all_ready(self) -> bool:
        """Kiểm tra tất cả model đã sẵn sàng chưa"""
        return self.is_docunet_ready() and self.is_paddle_ready()
    
    def get_loading_stats(self) -> Dict[str, Any]:
        """Lấy thống kê về thời gian load model"""
        return {
            "docunet_loaded": self._docunet_loaded,
            "paddle_loaded": self._paddle_loaded,
            "docunet_load_time": self._loading_stats.get("docunet_time", 0),
            "paddle_load_time": self._loading_stats.get("paddle_time", 0),
            "total_load_time": self._loading_stats.get("docunet_time", 0) + self._loading_stats.get("paddle_time", 0)
        }

# Global instance
model_manager = ModelManager()