"""
Database configuration and connection management
Cấu hình database và quản lý kết nối SQLite
"""

import os
import logging
from pathlib import Path
from sqlalchemy import create_engine, MetaData
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import declarative_base, sessionmaker
from sqlalchemy.pool import StaticPool

logger = logging.getLogger(__name__)

# Base class cho SQLAlchemy models
Base = declarative_base()

# Database configuration
class DatabaseConfig:
    """Cấu hình database"""
    
    def __init__(self):
        self.database_url = os.getenv("DATABASE_URL", "sqlite:///./invoices.db")
        self.async_database_url = os.getenv("ASYNC_DATABASE_URL", "sqlite+aiosqlite:///./invoices.db")
        self.echo = os.getenv("DATABASE_ECHO", "false").lower() == "true"
        
        # Tạo thư mục database nếu chưa có
        db_path = Path("./invoices.db")
        db_path.parent.mkdir(parents=True, exist_ok=True)

# Khởi tạo config
config = DatabaseConfig()

# Sync engine cho migration và setup
sync_engine = create_engine(
    config.database_url,
    echo=config.echo,
    poolclass=StaticPool,
    connect_args={
        "check_same_thread": False,  # Cho phép multi-threading với SQLite
    }
)

# Async engine cho FastAPI
async_engine = create_async_engine(
    config.async_database_url,
    echo=config.echo,
    poolclass=StaticPool,
    connect_args={
        "check_same_thread": False,
    }
)

# Session makers
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=sync_engine)
AsyncSessionLocal = async_sessionmaker(
    async_engine, 
    class_=AsyncSession, 
    expire_on_commit=False
)

# Metadata cho schema operations
metadata = MetaData()

def get_sync_db():
    """Dependency để lấy sync database session"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

async def get_async_db():
    """Dependency để lấy async database session"""
    async with AsyncSessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()

async def init_database():
    """Khởi tạo database và tạo tables"""
    logger.info("🗄️  Initializing database...")
    
    try:
        # Import models để đăng ký với Base
        from backend_invoice.db_models import User, Invoice, InvoiceItem, InvoiceLog
        
        # Tạo tables
        async with async_engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        
        logger.info("✅ Database initialized successfully!")
        
    except Exception as e:
        logger.error(f"❌ Failed to initialize database: {e}")
        raise

async def close_database():
    """Đóng database connections"""
    logger.info("🔒 Closing database connections...")
    await async_engine.dispose()
    sync_engine.dispose()
    logger.info("✅ Database connections closed!")

# Health check function
async def check_database_health():
    """Kiểm tra tình trạng database"""
    try:
        from sqlalchemy import text
        async with AsyncSessionLocal() as session:
            # Thực hiện query đơn giản để test connection
            result = await session.execute(text("SELECT 1"))
            result.fetchone()
            return {"status": "healthy", "database": "connected"}
    except Exception as e:
        logger.error(f"Database health check failed: {e}")
        return {"status": "unhealthy", "database": "disconnected", "error": str(e)}