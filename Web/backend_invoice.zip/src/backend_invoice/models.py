from pydantic import BaseModel, EmailStr
from typing import List, Optional
from datetime import datetime, date
from decimal import Decimal

# -----------------------------
# Users
# -----------------------------
class User(BaseModel):
    user_id: int
    created_at: datetime
    username: str
    full_name: Optional[str] = None
    email: Optional[EmailStr] = None
    password_hash: str
    role: Optional[str] = None

# -----------------------------
# Invoice Items
# -----------------------------
class InvoiceItem(BaseModel):
    item_id: int
    invoice_id: int
    product_name: str
    quantity: int
    unit_price: Decimal
    total_price: Decimal

# -----------------------------
# Invoice Logs
# -----------------------------
class InvoiceLog(BaseModel):
    log_id: int
    invoice_id: int
    log_time: datetime
    message: Optional[str] = None
    step: Optional[str] = None
    status: Optional[str] = None

# -----------------------------
# Invoices
# -----------------------------
class Invoice(BaseModel):
    invoice_id: int
    invoice_date: date
    upload_time: datetime
    processed_time: Optional[datetime] = None
    uploaded_by: int
    invoice_number: Optional[str] = None
    store_name: Optional[str] = None
    store_address: Optional[str] = None
    total_amount: Optional[Decimal] = None
    status: Optional[str] = None
    original_file_name: Optional[str] = None
    file_type: Optional[str] = None
    file_path: Optional[str] = None
    items: Optional[List[InvoiceItem]] = []
    logs: Optional[List[InvoiceLog]] = []

# -----------------------------
# Ví dụ tạo object
# # -----------------------------
# example_invoice = Invoice(
#     invoice_id=1,
#     invoice_date=date.today(),
#     upload_time=datetime.now(),
#     processed_time=None,
#     uploaded_by=1,
#     invoice_number="HD001",
#     store_name="VinMart",
#     store_address="123 Đường A",
#     total_amount=Decimal("100000.00"),
#     items=[
#         InvoiceItem(item_id=1, invoice_id=1, product_name="Sữa Vinamilk", quantity=2, unit_price=Decimal("30000.00"), total_price=Decimal("60000.00"))
#     ],
#     logs=[
#         InvoiceLog(log_id=1, invoice_id=1, log_time=datetime.now(), message="Uploaded", step="upload", status="done")
#     ]
# )
