"""
DocUnet Processing Module
Xử lý ảnh hóa đơn bằng DocUnet model và lưu kết quả vào data/staging/docunet_result
"""

import os
import json
import uuid
import shutil
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any

from backend_invoice.docunet_deployment.predict import DocUnetPredictor
from backend_invoice.docunet_deployment.data_processing import resize_image_to_512
from backend_invoice.model_manager import model_manager

class DocUnetProcessor:
    """
    Processor chính cho DocUnet processing
    """
    
    def __init__(self, device: str = 'cpu', staging_dir: str = "data/staging/model_result"):
        """
        Khởi tạo DocUnet Processor
        
        Args:
            device: Device để chạy model ('cpu' hoặc 'cuda')
            staging_dir: Thư mục lưu kết quả
        """
        self.device = device
        self.staging_dir = Path(staging_dir)
        self.staging_dir.mkdir(parents=True, exist_ok=True)
        
        # Sử dụng preloaded model từ ModelManager thay vì tạo mới
        self.predictor = None  # Sẽ được lấy từ model_manager khi cần
        self.resize_func = resize_image_to_512

        
        print(f"✅ DocUnet Processor initialized (staging: {self.staging_dir})")
    
    def _create_job_directory(self, vendor: str, invoice_date: Optional[str] = None) -> tuple:
        """Tạo thư mục job với timestamp và job_id"""
        
        # Tạo job_id unique
        job_id = str(uuid.uuid4())
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Tạo tên thư mục job
        job_name = f"{timestamp}_{job_id[:8]}"
        if vendor:
            safe_vendor = "".join(c for c in vendor if c.isalnum() or c in (' ', '-', '_')).strip()
            safe_vendor = safe_vendor.replace(' ', '_')
            job_name = f"{timestamp}_{safe_vendor}_{job_id[:8]}"
        
        job_dir = self.staging_dir / job_name
        job_dir.mkdir(parents=True, exist_ok=True)
        
        return job_dir, job_id
    
    def _save_metadata(self, job_dir: Path, metadata: Dict[str, Any]) -> str:
        """Lưu metadata của job"""
        metadata_path = job_dir / "metadata.json"
        
        with open(metadata_path, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, indent=2, ensure_ascii=False, default=str)
        
        return str(metadata_path)
    
    def process_single_image(self, 
                           image_path: str, 
                           vendor: str,
                           invoice_date: Optional[str] = None,
                           metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Xử lý một ảnh hóa đơn
        
        Args:
            image_path: Đường dẫn đến ảnh input
            vendor: Tên vendor/nhà cung cấp
            invoice_date: Ngày hóa đơn (optional)
            metadata: Metadata bổ sung (optional)
        
        Returns:
            Dict chứa thông tin kết quả processing
        """
        
        print(f"🚀 Processing invoice image: {image_path}")
        print(f"📊 Vendor: {vendor}")
        if invoice_date:
            print(f"📅 Invoice Date: {invoice_date}")
        
        # Kiểm tra file input
        if not os.path.exists(image_path):
            raise FileNotFoundError(f"Input image not found: {image_path}")
        
        # Tạo job directory
        job_dir, job_id = self._create_job_directory(vendor, invoice_date)
        
        # Chuẩn bị metadata
        job_metadata = {
            "job_id": job_id,
            "vendor": vendor,
            "invoice_date": invoice_date,
            "input_image": str(Path(image_path).absolute()),
            "processing_timestamp": datetime.now().isoformat(),
            "device": self.device,
            "status": "processing",
            "steps": [],
            "custom_metadata": metadata or {}
        }
        
        try:
            # Step 1: Resize image to 512x512
            print("📐 Step 1: Resizing image to 512x512...")
            resized_path = job_dir / "resized_512.png"
            self.resize_func(image_path, str(resized_path))
            
            job_metadata["steps"].append({
                "step": 1,
                "name": "resize_to_512",
                "status": "completed",
                "output": str(resized_path),
                "timestamp": datetime.now().isoformat()
            })
            
            # Step 2: DocUnet prediction
            print("🤖 Step 2: Running DocUnet prediction...")
            rectified_path = job_dir / "rectified.png"
            
            # Lấy preloaded model từ ModelManager
            predictor = model_manager.get_docunet_predictor()
            if predictor is None:
                raise RuntimeError("DocUnet model not loaded. Please ensure models are preloaded during server startup.")
            
            predictor.predict_single_image(str(resized_path), str(rectified_path))
            
            job_metadata["steps"].append({
                "step": 2,
                "name": "docunet_prediction",
                "status": "completed",
                "output": str(rectified_path),
                "timestamp": datetime.now().isoformat()
            })
            
            # Step 3: Copy original image
            print("📋 Step 3: Saving original image...")
            original_copy_path = job_dir / f"original{Path(image_path).suffix}"
            shutil.copy2(image_path, original_copy_path)
            
            job_metadata["steps"].append({
                "step": 3,
                "name": "save_original",
                "status": "completed",
                "output": str(original_copy_path),
                "timestamp": datetime.now().isoformat()
            })
            
            # Cập nhật status
            job_metadata["status"] = "completed"
            job_metadata["completion_timestamp"] = datetime.now().isoformat()
            
            # Lưu metadata
            metadata_path = self._save_metadata(job_dir, job_metadata)
            
            # Chuẩn bị kết quả
            result = {
                "job_id": job_id,
                "job_directory": str(job_dir),
                "status": "completed",
                "vendor": vendor,
                "invoice_date": invoice_date,
                "steps": job_metadata["steps"],
                "outputs": {
                    "original": str(original_copy_path),
                    "resized": str(resized_path),
                    "rectified": str(rectified_path),
                    "metadata": metadata_path
                },
                "metadata": job_metadata
            }
            
            print(f"✅ Processing completed successfully!")
            print(f"📁 Job directory: {job_dir}")
            print(f"🆔 Job ID: {job_id}")
            
            return result
            
        except Exception as e:
            # Cập nhật metadata với lỗi
            job_metadata["status"] = "failed"
            job_metadata["error"] = str(e)
            job_metadata["error_timestamp"] = datetime.now().isoformat()
            
            self._save_metadata(job_dir, job_metadata)
            
            print(f"❌ Processing failed: {e}")
            raise
    
    def list_all_jobs(self) -> List[Dict[str, Any]]:
        """Liệt kê tất cả jobs trong staging directory"""
        
        jobs = []
        
        for job_dir in self.staging_dir.iterdir():
            if job_dir.is_dir():
                metadata_path = job_dir / "metadata.json"
                
                if metadata_path.exists():
                    try:
                        with open(metadata_path, 'r', encoding='utf-8') as f:
                            metadata = json.load(f)
                        
                        jobs.append({
                            "job_id": metadata.get("job_id"),
                            "vendor": metadata.get("vendor"),
                            "invoice_date": metadata.get("invoice_date"),
                            "status": metadata.get("status"),
                            "processing_timestamp": metadata.get("processing_timestamp"),
                            "job_directory": str(job_dir)
                        })
                    except Exception as e:
                        print(f"⚠️  Error reading metadata for {job_dir}: {e}")
        
        # Sắp xếp theo thời gian processing (mới nhất trước)
        jobs.sort(key=lambda x: x.get("processing_timestamp", ""), reverse=True)
        
        return jobs

def process_invoice_image(image_path: str, 
                         vendor: str,
                         invoice_date: Optional[str] = None,
                         metadata: Optional[Dict[str, Any]] = None,
                         device: str = 'cpu') -> Dict[str, Any]:
    """
    Convenience function để xử lý ảnh hóa đơn
    
    Args:
        image_path: Đường dẫn đến ảnh input
        vendor: Tên vendor/nhà cung cấp
        invoice_date: Ngày hóa đơn (optional)
        metadata: Metadata bổ sung (optional)
        device: Device để chạy model ('cpu' hoặc 'cuda')
    
    Returns:
        Dict chứa thông tin kết quả processing
    """
    
    processor = DocUnetProcessor(device=device)
    return processor.process_single_image(image_path, vendor, invoice_date, metadata)

# Example usage
if __name__ == "__main__":
    # Test processing
    processor = DocUnetProcessor(device='cpu')
    
    # Giả sử có file test image
    test_image = "image.png"
    if os.path.exists(test_image):
        result = processor.process_single_image(
            image_path=test_image,
            vendor="Test Company",
            invoice_date="2024-01-15",
            metadata={"source": "test_script", "notes": "Testing DocUnet processing"}
        )
        
        print("\n📊 Processing Result:")
        print(f"Job ID: {result['job_id']}")
        print(f"Status: {result['status']}")
        print(f"Job Directory: {result['job_directory']}")
    else:
        print(f"❌ Test image not found: {test_image}")
        print("💡 Please place a test image named 'image.png' in the current directory")