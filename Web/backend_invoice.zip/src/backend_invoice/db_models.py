"""
SQLAlchemy Database Models
Các model database tương ứng với Pydantic models
"""

from sqlalchemy import Column, Integer, String, DateTime, Date, Numeric, Text, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from backend_invoice.database import Base

class User(Base):
    """Bảng Users - Quản lý người dùng"""
    __tablename__ = "users"
    
    user_id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    username = Column(String(50), unique=True, index=True, nullable=False)
    full_name = Column(String(100), nullable=True)
    email = Column(String(100), unique=True, index=True, nullable=True)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(20), default="user", nullable=True)
    is_active = Column(String(10), default="true", nullable=False)
    
    # Relationships
    invoices = relationship("Invoice", back_populates="user")
    
    def __repr__(self):
        return f"<User(user_id={self.user_id}, username='{self.username}')>"

class Invoice(Base):
    """Bảng Invoices - Hóa đơn chính"""
    __tablename__ = "invoices"
    
    invoice_id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    invoice_date = Column(Date, nullable=False)
    upload_time = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    processed_time = Column(DateTime(timezone=True), nullable=True)
    uploaded_by = Column(Integer, ForeignKey("users.user_id"), nullable=False)
    invoice_number = Column(String(50), index=True, nullable=True)
    store_name = Column(String(200), nullable=True)
    store_address = Column(Text, nullable=True)
    total_amount = Column(Numeric(15, 2), nullable=True)  # Precision 15, Scale 2 cho tiền tệ
    status = Column(String(20), default="uploaded", nullable=True)
    original_file_name = Column(String(255), nullable=True)
    file_type = Column(String(10), nullable=True)
    file_path = Column(String(500), nullable=True)  # Đường dẫn đến file đã lưu
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # Relationships
    user = relationship("User", back_populates="invoices")
    items = relationship("InvoiceItem", back_populates="invoice", cascade="all, delete-orphan")
    logs = relationship("InvoiceLog", back_populates="invoice", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<Invoice(invoice_id={self.invoice_id}, invoice_number='{self.invoice_number}')>"

class InvoiceItem(Base):
    """Bảng Invoice Items - Chi tiết sản phẩm trong hóa đơn"""
    __tablename__ = "invoice_items"
    
    item_id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    invoice_id = Column(Integer, ForeignKey("invoices.invoice_id"), nullable=False)
    product_name = Column(String(200), nullable=False)
    quantity = Column(Integer, nullable=False)
    unit_price = Column(Numeric(15, 2), nullable=False)
    total_price = Column(Numeric(15, 2), nullable=False)
    
    # Relationships
    invoice = relationship("Invoice", back_populates="items")
    
    def __repr__(self):
        return f"<InvoiceItem(item_id={self.item_id}, product_name='{self.product_name}')>"

class InvoiceLog(Base):
    """Bảng Invoice Logs - Log xử lý hóa đơn"""
    __tablename__ = "invoice_logs"
    
    log_id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    invoice_id = Column(Integer, ForeignKey("invoices.invoice_id"), nullable=False)
    log_time = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    message = Column(Text, nullable=True)
    step = Column(String(50), nullable=True)  # upload, processing, completed, error
    status = Column(String(20), nullable=True)  # pending, in_progress, done, failed
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    
    # Relationships
    invoice = relationship("Invoice", back_populates="logs")
    
    def __repr__(self):
        return f"<InvoiceLog(log_id={self.log_id}, step='{self.step}', status='{self.status}')>"

# Indexes để tối ưu performance
from sqlalchemy import Index

# Composite indexes
Index('idx_invoice_user_date', Invoice.uploaded_by, Invoice.invoice_date)
Index('idx_invoice_status_date', Invoice.status, Invoice.upload_time)
Index('idx_log_invoice_time', InvoiceLog.invoice_id, InvoiceLog.log_time)
Index('idx_item_invoice', InvoiceItem.invoice_id)