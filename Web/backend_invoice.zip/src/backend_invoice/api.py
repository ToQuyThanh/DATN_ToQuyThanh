from fastapi import FastAPI, UploadFile, File, HTTPException, Depends, Form
from typing import List, Optional
from datetime import datetime, date
from decimal import Decimal
from pydantic import BaseModel, EmailStr
import logging
import os

# Setup logging first
from backend_invoice.logging_config import setup_logging
setup_logging(log_level="INFO", log_dir="logs")

from backend_invoice.models import *
from backend_invoice.database import init_database, close_database, get_async_db, check_database_health

from backend_invoice.services import InvoiceService, UserService
from backend_invoice.invoice_processor import InvoiceProcessor
from sqlalchemy.ext.asyncio import AsyncSession
import tempfile
import shutil

# Khởi tạo logger
logger = logging.getLogger(__name__)

# Khởi tạo FastAPI app với metadata
app = FastAPI(
    title="Invoice Processing API",
    description="API để xử lý và quản lý hóa đơn sử dụng AI",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Startup event
@app.on_event("startup")
async def startup_event():
    """Khởi tạo ứng dụng khi startup"""
    logger.info("🚀 Invoice Processing API is starting up...")
    logger.info("📁 Checking required directories...")
    
    # Tạo các thư mục cần thiết
    required_dirs = ["backend_invoices", "data/staging", "logs"]
    for dir_path in required_dirs:
        os.makedirs(dir_path, exist_ok=True)
        logger.info(f"✅ Directory ensured: {dir_path}")
    
    # Khởi tạo database
    logger.info("🗄️ Initializing database...")
    await init_database()
    
    # Preload AI models
    logger.info("🤖 Preloading AI models...")
    from backend_invoice.model_manager import model_manager
    
    # Determine device (use GPU if available)
    import torch
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    logger.info(f"🔧 Using device: {device}")
    
    # Initialize models
    model_stats = await model_manager.initialize_models(device=device)
    
    # Log model loading results
    for model_name, stats in model_stats.items():
        if model_name == "total_time":
            continue
        if stats["status"] == "success":
            logger.info(f"✅ {model_name.capitalize()} model loaded successfully in {stats['load_time']:.2f}s")
        else:
            logger.error(f"❌ Failed to load {model_name} model: {stats['error']}")
    
    logger.info(f"🎯 All models preloaded in {model_stats['total_time']:.2f}s")
    
    logger.info("✨ Invoice Processing API started successfully!")

# Shutdown event
@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup khi shutdown"""
    logger.info("🛑 Invoice Processing API is shutting down...")
    
    # Đóng database connections
    await close_database()
    
    logger.info("👋 Goodbye!")

# Health check endpoint
@app.get("/health", tags=["Health"])
async def health_check():
    """Kiểm tra tình trạng sức khỏe của API"""
    # Kiểm tra database health
    db_health = await check_database_health()
    
    overall_status = "healthy" if db_health["status"] == "healthy" else "unhealthy"
    
    return {
        "status": overall_status,
        "database": db_health,
        "timestamp": datetime.now().isoformat(),
        "version": "1.0.0",
        "service": "Invoice Processing API"
    }

# Model status endpoint
@app.get("/models/status", tags=["Health"])
async def model_status():
    """Kiểm tra trạng thái các AI models"""
    from backend_invoice.model_manager import model_manager
    
    stats = model_manager.get_loading_stats()
    
    return {
        "status": "ready" if model_manager.is_all_ready() else "not_ready",
        "models": {
            "docunet": {
                "loaded": stats["docunet_loaded"],
                "ready": model_manager.is_docunet_ready(),
                "load_time": stats["docunet_load_time"]
            },
            "paddle_ocr": {
                "loaded": stats["paddle_loaded"],
                "ready": model_manager.is_paddle_ready(),
                "load_time": stats["paddle_load_time"]
            }
        },
        "total_load_time": stats["total_load_time"],
        "timestamp": datetime.now().isoformat()
    }

# 1. Hiển thị báo cáo tổng quan
@app.get("/dashboard/summary", response_model=dict)
async def get_dashboard_summary(
    limit: int = 10, 
    offset: int = 0,
    db: AsyncSession = Depends(get_async_db)
):
    """Lấy tổng quan dashboard với dữ liệu thật từ database."""
    try:
        logger.info(f"📊 API: Getting dashboard summary (limit={limit}, offset={offset})")
        
        # Lấy danh sách invoice từ database
        invoices = await InvoiceService.get_invoices_with_filter(db, limit=limit, offset=offset)
        
        # Tính toán thống kê
        total_invoices = await InvoiceService.get_total_invoices(db)
        processed_count = await InvoiceService.get_invoices_by_status(db, "completed")
        pending_count = await InvoiceService.get_invoices_by_status(db, "pending")
        failed_count = await InvoiceService.get_invoices_by_status(db, "failed")
        
        # Tính tổng tiền
        total_amount = await InvoiceService.get_total_amount(db)
        
        logger.info(f"✅ API: Dashboard summary retrieved - {total_invoices} total invoices")
        
        return {
            "success": True,
            "data": {
                "statistics": {
                    "total_invoices": total_invoices,
                    "processed_count": processed_count,
                    "pending_count": pending_count,
                    "failed_count": failed_count,
                    "total_amount": float(total_amount) if total_amount else 0.0
                },
                "recent_invoices": [
                    {
                        "invoice_id": inv.invoice_id,
                        "invoice_number": inv.invoice_number,
                        "store_name": inv.store_name,
                        "total_amount": float(inv.total_amount) if inv.total_amount is not None else 0.0,
                        "status": inv.status,
                        "upload_time": inv.upload_time.isoformat() if inv.upload_time else None,
                        "processed_time": inv.processed_time.isoformat() if inv.processed_time else None
                    } for inv in invoices
                ],
                "pagination": {
                    "limit": limit,
                    "offset": offset,
                    "total": total_invoices
                }
            }
        }
        
    except Exception as e:
        logger.error(f"❌ API: Failed to get dashboard summary: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get dashboard summary: {str(e)}")

# 2. Upload hóa đơn
@app.post("/invoices/upload", response_model=dict)
async def upload_invoice(
    file: UploadFile = File(...),
    uploaded_by: int = 1,  # TODO: Get from authentication
    vendor: Optional[str] = None,
    invoice_date: Optional[str] = None,
    db: AsyncSession = Depends(get_async_db)
):
    """
    Upload invoice file and save to database.
    
    Args:
        file: Uploaded file
        uploaded_by: User ID (default: 1 for testing)
        vendor: Vendor/store name
        invoice_date: Invoice date in YYYY-MM-DD format
        db: Database session
    
    Returns:
        Upload result with invoice details
    """
    logger.info(f"📤 API: Received upload request for file: {file.filename}")
    
    # Validate file
    if not file.filename:
        raise HTTPException(status_code=400, detail="No file provided")
    
    # Check file size (limit to 10MB)
    if file.size and file.size > 10 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="File too large (max 10MB)")
    
    # Create temporary file
    temp_file = None
    try:
        # Save uploaded file to temporary location
        with tempfile.NamedTemporaryFile(delete=False, suffix=f"_{file.filename}") as temp_file:
            shutil.copyfileobj(file.file, temp_file)
            temp_file_path = temp_file.name
        
        logger.info(f"💾 Temporary file saved: {temp_file_path}")
        
        # Use service to upload invoice
        result = await InvoiceService.upload_invoice_file(
            db=db,
            file_path=temp_file_path,
            uploaded_by=uploaded_by,
            vendor=vendor,
            invoice_date=invoice_date,
            metadata={
                "original_filename": file.filename,
                "content_type": file.content_type,
                "file_size": file.size
            }
        )
        
        logger.info(f"✅ API: Upload completed successfully. Invoice ID: {result['invoice_id']}")
        
        return {
            "success": True,
            "message": "Invoice uploaded successfully",
            "data": result
        }
        
    except ValueError as e:
        logger.error(f"❌ API: Validation error: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except FileNotFoundError as e:
        logger.error(f"❌ API: File error: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"❌ API: Upload failed: {e}")
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")
    finally:
        # Clean up temporary file
        if temp_file and hasattr(temp_file, 'name') and os.path.exists(temp_file.name):
            try:
                os.unlink(temp_file.name)
                logger.info(f"🗑️ Temporary file cleaned up: {temp_file.name}")
            except Exception as e:
                logger.warning(f"⚠️ Failed to clean up temporary file: {e}")

# 3. Lấy thông tin invoice theo ID
@app.get("/invoices/{invoice_id}", response_model=dict)
async def get_invoice(invoice_id: int, db: AsyncSession = Depends(get_async_db)):
    """Get invoice details by ID."""
    logger.info(f"🔍 API: Getting invoice {invoice_id}")
    
    invoice = await InvoiceService.get_invoice_by_id(db, invoice_id)
    if not invoice:
        raise HTTPException(status_code=404, detail="Invoice not found")
    
    # Get logs for this invoice
    logs = await InvoiceService.get_invoice_logs(db, invoice_id)
    
    return {
        "success": True,
        "data": {
            "invoice": invoice.dict(),
            "logs": [log.dict() for log in logs]
        }
    }

# 4. Lấy danh sách invoices của user
@app.get("/users/{user_id}/invoices", response_model=dict)
async def get_user_invoices(
    user_id: int, 
    limit: int = 50, 
    offset: int = 0,
    db: AsyncSession = Depends(get_async_db)
):
    """Get invoices for a specific user."""
    logger.info(f"📋 API: Getting invoices for user {user_id}")
    
    invoices = await InvoiceService.get_invoices_by_user(db, user_id, limit, offset)
    
    return {
        "success": True,
        "data": {
            "invoices": [invoice.dict() for invoice in invoices],
            "total": len(invoices),
            "limit": limit,
            "offset": offset
        }
    }

# 4. Quản lý hóa đơn (search/filter)
@app.get("/invoices", response_model=dict)
async def list_invoices(
    query: Optional[str] = None, 
    status: Optional[str] = None, 
    limit: int = 10, 
    offset: int = 0,
    db: AsyncSession = Depends(get_async_db)
):
    """Lấy danh sách hóa đơn với filter và pagination."""
    try:
        logger.info(f"📋 API: Getting invoices list (query={query}, status={status}, limit={limit}, offset={offset})")
        
        # Lấy danh sách invoice với filter
        invoices = await InvoiceService.get_invoices_with_filter(
            db=db, 
            query=query, 
            status=status, 
            limit=limit, 
            offset=offset
        )
        
        # Lấy tổng số invoice (cho pagination)
        total = await InvoiceService.get_total_invoices_with_filter(
            db=db, 
            query=query, 
            status=status
        )
        
        logger.info(f"✅ API: Retrieved {len(invoices)} invoices (total: {total})")
        
        return {
            "success": True,
            "data": {
                "invoices": [
                    {
                        "invoice_id": inv.invoice_id,
                        "invoice_number": inv.invoice_number,
                        "invoice_date": inv.invoice_date.isoformat() if inv.invoice_date else None,
                        "store_name": inv.store_name,
                        "store_address": inv.store_address,
                        "total_amount": float(inv.total_amount) if inv.total_amount is not None else 0.0,
                        "status": inv.status,
                        "upload_time": inv.upload_time.isoformat() if inv.upload_time else None,
                        "processed_time": inv.processed_time.isoformat() if inv.processed_time else None,
                        "uploaded_by": inv.uploaded_by
                    } for inv in invoices
                ],
                "pagination": {
                    "limit": limit,
                    "offset": offset,
                    "total": total,
                    "has_next": offset + limit < total,
                    "has_prev": offset > 0
                },
                "filters": {
                    "query": query,
                    "status": status
                }
            }
        }
        
    except Exception as e:
        logger.error(f"❌ API: Failed to get invoices list: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get invoices: {str(e)}")

# 5. Trích xuất thông tin hóa đơn
@app.post("/invoices/extract", response_model=dict)
async def extract_invoice(
    file: UploadFile = File(...),
    uploaded_by: int = Form(1),
    db: AsyncSession = Depends(get_async_db)
):
    """Upload ảnh hóa đơn và trích xuất thông tin ngay lập tức."""
    try:
        logger.info(f"🔍 API: Starting invoice extraction for file {file.filename}")
        
        # Validate file type
        allowed_types = {"image/jpeg", "image/png", "image/jpg", "application/pdf"}
        if file.content_type not in allowed_types:
            raise HTTPException(
                status_code=400, 
                detail=f"Unsupported file type: {file.content_type}. Allowed: {allowed_types}"
            )
        
        # Save uploaded file temporarily
        import tempfile
        import os
        from pathlib import Path
        
        # Create temp file
        temp_dir = Path("temp_uploads")
        temp_dir.mkdir(exist_ok=True)
        
        file_extension = Path(file.filename).suffix
        temp_file_path = temp_dir / f"temp_{datetime.now().strftime('%Y%m%d_%H%M%S')}{file_extension}"
        
        # Save file
        with open(temp_file_path, "wb") as buffer:
            content = await file.read()
            buffer.write(content)
        
        logger.info(f"📁 API: Saved temp file to {temp_file_path}")
        
        # Process with DocUNet and PaddleOCR
        extraction_result = await InvoiceService.extract_invoice_data(
            db=db,
            file_path=str(temp_file_path),
            uploaded_by=uploaded_by,
            original_filename=file.filename
        )
        
        # Clean up temp file
        try:
            os.remove(temp_file_path)
            logger.info(f"🗑️ API: Cleaned up temp file {temp_file_path}")
        except Exception as e:
            logger.warning(f"⚠️ API: Failed to clean up temp file: {e}")
        
        logger.info(f"✅ API: Successfully extracted invoice data")
        
        return {
            "success": True,
            "data": extraction_result,
            "message": "Invoice extracted successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ API: Failed to extract invoice: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to extract invoice: {str(e)}")

# 6. Lưu trữ dữ liệu người dùng
@app.post("/users", response_model=dict)
async def create_user(
    username: str = Form(...),
    email: str = Form(...),
    password: str = Form(...),
    role: str = Form(default="user"),
    db: AsyncSession = Depends(get_async_db)
):
    """Tạo user mới."""
    try:
        logger.info(f"👤 API: Creating new user {username}")
        
        # Kiểm tra user đã tồn tại chưa
        existing_user = await UserService.get_user_by_username(db, username)
        if existing_user:
            raise HTTPException(status_code=400, detail="Username already exists")
        
        existing_email = await UserService.get_user_by_email(db, email)
        if existing_email:
            raise HTTPException(status_code=400, detail="Email already exists")
        
        # Tạo user mới
        new_user = await UserService.create_user(
            db=db,
            username=username,
            email=email,
            password=password,
            role=role
        )
        
        logger.info(f"✅ API: Created user {new_user.user_id}")
        
        return {
            "success": True,
            "data": {
                "user_id": new_user.user_id,
                "username": new_user.username,
                "email": new_user.email,
                "role": new_user.role,
                "created_at": new_user.created_at.isoformat() if new_user.created_at else None
            },
            "message": "User created successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ API: Failed to create user: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to create user: {str(e)}")

# 7. Ghi lại log xử lý hóa đơn
@app.post("/invoices/{invoice_id}/logs", response_model=dict)
async def create_invoice_log(
    invoice_id: int,
    message: str,
    step: str,
    status: str = "info",
    db: AsyncSession = Depends(get_async_db)
):
    """Add a log entry for an invoice."""
    logger.info(f"📝 API: Adding log for invoice {invoice_id}")
    
    try:
        # Verify invoice exists
        invoice = await InvoiceService.get_invoice_by_id(db, invoice_id)
        if not invoice:
            raise HTTPException(status_code=404, detail="Invoice not found")
        
        # Create log entry
        log = await InvoiceService.add_invoice_log(
            db=db,
            invoice_id=invoice_id,
            message=message,
            step=step,
            status=status
        )
        
        return {
            "success": True,
            "message": "Log entry created successfully",
            "data": log.dict()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ API: Failed to create log: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to create log: {str(e)}")

# 8. Lấy thông tin user
@app.get("/users/{user_id}", response_model=dict)
async def get_user(user_id: int, db: AsyncSession = Depends(get_async_db)):
    """Get user details by ID."""
    logger.info(f"👤 API: Getting user {user_id}")
    
    user = await UserService.get_user_by_id(db, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    return {
        "success": True,
        "data": user.dict()
    }

# 9. Xử lý trích xuất thông tin hóa đơn
@app.post("/invoices/{invoice_id}/process", response_model=dict)
async def process_invoice(invoice_id: int, db: AsyncSession = Depends(get_async_db)):
    """
    Xử lý trích xuất thông tin hóa đơn theo ID.
    
    Quy trình:
    1. Lấy thông tin hóa đơn từ database
    2. Resize ảnh về 512x512 và gọi DocUnet predict
    3. Cập nhật trạng thái database
    4. Gọi Paddle OCR để xử lý ảnh đã tiền xử lý
    5. Cập nhật trạng thái database
    6. Gọi schema parser để trích xuất thông tin
    7. Lưu thông tin trích xuất vào database
    """
    logger.info(f"🔄 API: Processing invoice {invoice_id}")
    
    try:
        # Import các module cần thiết
        from backend_invoice.invoice_processor import InvoiceProcessor
        
        # Khởi tạo processor
        processor = InvoiceProcessor()
        
        # Xử lý hóa đơn
        result = await processor.process_invoice(db, invoice_id)
        
        return {
            "success": True,
            "message": "Invoice processed successfully",
            "data": result
        }
        
    except ValueError as e:
        logger.error(f"Invoice not found: {e}")
        raise HTTPException(
            status_code=404,
            detail=str(e)
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ API: Failed to process invoice {invoice_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to process invoice: {str(e)}")
