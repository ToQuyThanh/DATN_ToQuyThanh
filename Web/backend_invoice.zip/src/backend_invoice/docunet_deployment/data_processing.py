import cv2

def resize_image_to_512(img_path: str, save_path: str) -> None:
    """
    Resize an image to 512x512 and save it.
    """
    img = cv2.imread(img_path)
    if img is None:
        raise FileNotFoundError(f"Cannot read image at {img_path}")
    resized = cv2.resize(img, (512, 512), interpolation=cv2.INTER_AREA)
    cv2.imwrite(save_path, resized)
    print("Ảnh đã được resize và lưu tại:", save_path)

# Example usage
if __name__ == "__main__":
    img_path = r"X:\3_Projects\DATN\Project\paddle_invoice\dataset\image.jpg"
    save_path = r"image_512.jpg"
    resize_image_to_512(img_path, save_path)
