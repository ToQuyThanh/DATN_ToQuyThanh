
import torch
import cv2
import numpy as np
import os
from PIL import Image
from torchvision import transforms
from backend_invoice.docunet_deployment.docunet_model import TinyDocUnet
import argparse
from pathlib import Path
import logging
from typing import Tuple, Optional
import time

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def fix_compiled_state_dict(state_dict):
    """
    Fix state_dict từ torch.compile() model
    Remove các prefix như '_orig_mod.' hoặc 'module.'
    """
    new_state_dict = {}
    
    for key, value in state_dict.items():
        # Remove torch.compile prefix
        new_key = key.replace('_orig_mod.', '')
        # Remove DataParallel prefix
        new_key = new_key.replace('module.', '')
        # Remove model. prefix nếu có
        new_key = new_key.replace('model.', '')
        
        new_state_dict[new_key] = value
    
    return new_state_dict


class DocUnetPredictor:
    """DocUnet predictor cho document rectification"""
    
    def __init__(self, checkpoint_path: str, device: str = 'cuda'):
        """
        Args:
            checkpoint_path: Path đến model checkpoint (.pth file)
            device: 'cuda' hoặc 'cpu'
        """
        self.device = torch.device(device if torch.cuda.is_available() else 'cpu')
        logger.info(f"Using device: {self.device}")
        
        # Load model
        self.model = TinyDocUnet(input_channels=3, n_classes=2)
        self.model = self.model.to(self.device)
        
        # Load checkpoint
        self._load_checkpoint(checkpoint_path)
        
        # Transform cho input image
        self.transform = transforms.Compose([
            transforms.ToTensor(),
        ])
        
        logger.info("Model loaded successfully")
    
    def _load_checkpoint(self, checkpoint_path: str):
        """Load model weights từ checkpoint với error handling"""
        if not os.path.exists(checkpoint_path):
            raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")
        
        logger.info(f"Loading checkpoint from {checkpoint_path}")
        
        # Load checkpoint với weights_only=False cho PyTorch 2.6+
        try:
            checkpoint = torch.load(checkpoint_path, map_location=self.device, weights_only=True)
            logger.info("✓ Loaded with weights_only=True")
        except Exception as e:
            logger.warning(f"weights_only=True failed: {str(e)[:100]}...")
            logger.info("Trying with weights_only=False...")
            checkpoint = torch.load(checkpoint_path, map_location=self.device, weights_only=False)
            logger.info("✓ Loaded with weights_only=False")
        
        # Extract state dict
        if isinstance(checkpoint, dict):
            if 'state_dict' in checkpoint:
                state_dict = checkpoint['state_dict']
                logger.info(f"✓ Found 'state_dict' key")
                if 'epoch' in checkpoint:
                    logger.info(f"  Checkpoint from epoch: {checkpoint['epoch']}")
                if 'metrics' in checkpoint:
                    logger.info(f"  Metrics: {checkpoint['metrics']}")
            elif 'model_state_dict' in checkpoint:
                state_dict = checkpoint['model_state_dict']
                logger.info("✓ Found 'model_state_dict' key")
            else:
                # Checkpoint là state_dict trực tiếp
                state_dict = checkpoint
                logger.info("✓ Checkpoint is state_dict directly")
        else:
            state_dict = checkpoint
            logger.info("✓ Checkpoint is state_dict directly")
        
        # Fix keys từ compiled model
        original_keys = list(state_dict.keys())
        
        # Check nếu có prefix cần remove
        has_orig_mod = any(key.startswith('_orig_mod.') for key in original_keys)
        has_module = any(key.startswith('module.') for key in original_keys)
        
        if has_orig_mod or has_module:
            logger.info(f"⚠ Found prefix in keys: _orig_mod={has_orig_mod}, module={has_module}")
            logger.info("  Fixing keys...")
            state_dict = fix_compiled_state_dict(state_dict)
            logger.info("  ✓ Keys fixed")
        
        # Debug: Print sample keys
        logger.info("\nSample checkpoint keys (first 3):")
        for i, key in enumerate(list(state_dict.keys())[:3]):
            logger.info(f"  {key}")
        
        logger.info("\nSample model keys (first 3):")
        for i, key in enumerate(list(self.model.state_dict().keys())[:3]):
            logger.info(f"  {key}")
        
        # Load state dict
        try:
            missing_keys, unexpected_keys = self.model.load_state_dict(state_dict, strict=False)
            
            if missing_keys:
                logger.warning(f"⚠ Missing keys in checkpoint ({len(missing_keys)}):")
                for key in missing_keys[:5]:
                    logger.warning(f"  - {key}")
                if len(missing_keys) > 5:
                    logger.warning(f"  ... and {len(missing_keys) - 5} more")
            
            if unexpected_keys:
                logger.warning(f"⚠ Unexpected keys in checkpoint ({len(unexpected_keys)}):")
                for key in unexpected_keys[:5]:
                    logger.warning(f"  - {key}")
                if len(unexpected_keys) > 5:
                    logger.warning(f"  ... and {len(unexpected_keys) - 5} more")
            
            if not missing_keys and not unexpected_keys:
                logger.info("✓ All keys matched perfectly!")
            elif len(missing_keys) == 0:
                logger.info("✓ Model loaded successfully (with some unexpected keys)")
            else:
                logger.warning("⚠ Model loaded with missing keys - results may be incorrect!")
                
        except Exception as e:
            logger.error(f"✗ Error loading state_dict: {e}")
            raise
        
        self.model.eval()
    
    def preprocess_image(self, image: np.ndarray) -> Tuple[torch.Tensor, Tuple[int, int]]:
        """
        Preprocess image cho model
        
        Args:
            image: Input image (BGR format từ cv2.imread)
        
        Returns:
            tensor: Preprocessed image tensor
            original_size: (height, width) của ảnh gốc
        """
        original_size = (image.shape[0], image.shape[1])
        
        # Convert BGR to RGB
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        # Transform to tensor
        image_tensor = self.transform(image_rgb)
        
        # Add batch dimension
        image_tensor = image_tensor.unsqueeze(0)
        
        return image_tensor, original_size
    
    def predict(self, image: np.ndarray) -> np.ndarray:
        """
        Predict displacement map cho image
        
        Args:
            image: Input image (BGR format)
        
        Returns:
            displacement_map: (H, W, 2) displacement map
        """
        # Preprocess
        image_tensor, original_size = self.preprocess_image(image)
        image_tensor = image_tensor.to(self.device)
        
        # Inference
        with torch.no_grad():
            _, output = self.model(image_tensor)
        
        # Post-process
        displacement_map = output.squeeze(0).cpu().numpy()  # (2, H, W)
        displacement_map = displacement_map.transpose(1, 2, 0)  # (H, W, 2)
        
        # Resize displacement map về kích thước ảnh gốc nếu cần
        if displacement_map.shape[:2] != original_size:
            # Scale displacement values theo tỉ lệ resize
            scale_y = original_size[0] / displacement_map.shape[0]
            scale_x = original_size[1] / displacement_map.shape[1]
            
            displacement_map[:, :, 0] = cv2.resize(
                displacement_map[:, :, 0], 
                (original_size[1], original_size[0])
            ) * scale_x
            
            displacement_map[:, :, 1] = cv2.resize(
                displacement_map[:, :, 1], 
                (original_size[1], original_size[0])
            ) * scale_y
        
        return displacement_map
    
    def rectify_image(self, image: np.ndarray, displacement_map: Optional[np.ndarray] = None) -> np.ndarray:
        """
        Rectify (unwrap) document image using displacement map

        Args:
            image: Input distorted image (BGR format)
            displacement_map: Pre-computed displacement map. If None, will predict.

        Returns:
            rectified_image: Rectified image (BGR format)
        """
        if displacement_map is None:
            displacement_map = self.predict(image)

        # Tách tọa độ từ displacement map
        map_x = displacement_map[:, :, 0].astype(np.float32)
        map_y = displacement_map[:, :, 1].astype(np.float32)

        # Áp dụng remap để rectify/unwarp image
        rectified_image = cv2.remap(
            image,
            map_x,
            map_y,
            interpolation=cv2.INTER_LINEAR,
            borderMode=cv2.BORDER_CONSTANT,    # pixel ngoài ảnh sẽ là màu trắng
            borderValue=(255, 255, 255)
        )

        return rectified_image

    
    def predict_single_image(self, image_path: str, output_path: Optional[str] = None, 
                           save_displacement: bool = False) -> np.ndarray:
        """
        Predict và rectify một ảnh
        
        Args:
            image_path: Path đến input image
            output_path: Path để save rectified image. Nếu None, không save.
            save_displacement: Có save displacement map không
        
        Returns:
            rectified_image: Rectified image
        """
        logger.info(f"Processing: {image_path}")
        
        # Load image
        image = cv2.imread(image_path)
        if image is None:
            raise ValueError(f"Cannot read image: {image_path}")
        
        # Predict và rectify
        start_time = time.time()
        displacement_map = self.predict(image)
        rectified_image = self.rectify_image(image, displacement_map)
        inference_time = time.time() - start_time
        
        logger.info(f"Inference time: {inference_time:.3f}s")
        
        # Save nếu có output_path
        if output_path:
            cv2.imwrite(output_path, rectified_image)
            logger.info(f"Saved to: {output_path}")
            
            # Save displacement map nếu cần
            if save_displacement:
                disp_path = output_path.replace('.jpg', '_displacement.npy').replace('.png', '_displacement.npy')
                np.save(disp_path, displacement_map)
                logger.info(f"Saved displacement map to: {disp_path}")
        
        return rectified_image
    
    def predict_batch(self, input_dir: str, output_dir: str, 
                     extensions: list = ['.jpg', '.png', '.jpeg'],
                     save_displacement: bool = False):
        """
        Predict batch images từ folder
        
        Args:
            input_dir: Thư mục chứa input images
            output_dir: Thư mục để save kết quả
            extensions: List các extension được accept
            save_displacement: Có save displacement maps không
        """
        os.makedirs(output_dir, exist_ok=True)
        
        # Get all image files
        image_files = []
        for ext in extensions:
            image_files.extend(Path(input_dir).rglob(f'*{ext}'))
        
        logger.info(f"Found {len(image_files)} images")
        
        # Process từng ảnh
        for i, image_path in enumerate(image_files, 1):
            try:
                # Tạo output path
                relative_path = image_path.relative_to(input_dir)
                output_path = Path(output_dir) / relative_path
                output_path.parent.mkdir(parents=True, exist_ok=True)
                
                logger.info(f"[{i}/{len(image_files)}] Processing {image_path.name}")
                
                # Predict
                self.predict_single_image(
                    str(image_path), 
                    str(output_path),
                    save_displacement=save_displacement
                )
                
            except Exception as e:
                logger.error(f"Error processing {image_path}: {str(e)}")
                continue
        
        logger.info("Batch prediction completed!")


def main():
    parser = argparse.ArgumentParser(description='DocUnet Inference')
    parser.add_argument('--checkpoint', type=str, required=True,
                       help='Path to model checkpoint')
    parser.add_argument('--input', type=str, required=True,
                       help='Input image or directory')
    parser.add_argument('--output', type=str, required=True,
                       help='Output path or directory')
    parser.add_argument('--device', type=str, default='cuda',
                       choices=['cuda', 'cpu'],
                       help='Device to use')
    parser.add_argument('--save-displacement', action='store_true',
                       help='Save displacement maps')
    parser.add_argument('--batch', action='store_true',
                       help='Batch mode for directory processing')
    
    args = parser.parse_args()
    
    # Initialize predictor
    predictor = DocUnetPredictor(args.checkpoint, device=args.device)
    
    # Single image or batch
    if args.batch or os.path.isdir(args.input):
        predictor.predict_batch(
            args.input, 
            args.output,
            save_displacement=args.save_displacement
        )
    else:
        predictor.predict_single_image(
            args.input, 
            args.output,
            save_displacement=args.save_displacement
        )


if __name__ == '__main__':
    # Test mode
    predictor = DocUnetPredictor(
        checkpoint_path=r'checkpoint_epoch_050.pth',
        device='cpu'  # Dùng CPU để test
    )
    
    # Predict single image
    predictor.predict_single_image(
        image_path=r"X:\3_Projects\DATN\Project\invoice_inference\image_512.jpg",
        output_path='winmart.jpg',
        save_displacement=True
    )