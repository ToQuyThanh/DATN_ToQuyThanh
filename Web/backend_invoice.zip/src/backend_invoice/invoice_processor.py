"""
Invoice Processor - Xử lý trích xuất thông tin hóa đơn
"""

import os
import io
import logging
from pathlib import Path
from PIL import Image
import asyncio
from typing import Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
# from pdf2image import convert_from_path

from backend_invoice.services import InvoiceService
from backend_invoice.docunet_processing import DocUnetPredictor
from backend_invoice.paddle_deployment.paddle_pl import InvoiceOCR
from backend_invoice.parse_schema_processor.schema_parser import SchemaParser

logger = logging.getLogger(__name__)

class InvoiceProcessor:
    """Class xử lý trích xuất thông tin hóa đơn"""
    
    # DocUnet toggle configuration - Thay đổi thành False để tắt DocUnet
    USE_DOCUNET = False
    
    def __init__(self):
        # Tìm đường dẫn checkpoint từ project root
        project_root = Path(__file__).parent.parent.parent
        self.docunet_checkpoint = str(project_root / "checkpoint_epoch_080.pth")
        self.temp_dir = Path("data/staging")
        self.docunet_result_dir = self.temp_dir / "model_result"
        self.paddle_result_dir = self.temp_dir / "model_result"
        self.schema_result_dir = self.temp_dir / "parse_schema_result"
        
        # Tạo các thư mục cần thiết
        for dir_path in [self.docunet_result_dir, self.paddle_result_dir, self.schema_result_dir]:
            dir_path.mkdir(parents=True, exist_ok=True)
    
    async def process_invoice(self, db: AsyncSession, invoice_id: int) -> Dict[str, Any]:
        """
        Xử lý trích xuất thông tin hóa đơn theo ID với transaction management
        
        Args:
            db: Database session
            invoice_id: ID của hóa đơn cần xử lý
            
        Returns:
            Dict chứa kết quả xử lý
        """
        logger.info(f"🔄 Starting invoice processing for ID: {invoice_id}")
        
        try:
            # 1. Lấy thông tin hóa đơn từ database
            invoice = await InvoiceService.get_invoice_by_id(db, invoice_id)
            if not invoice:
                raise ValueError(f"Invoice with ID {invoice_id} not found")
            
            # Log bắt đầu xử lý (sử dụng version có commit)
            await InvoiceService.add_invoice_log(
                db=db,
                invoice_id=invoice_id,
                message="Bắt đầu xử lý trích xuất thông tin",
                step="start_processing",
                status="processing"
            )
            
            # Cập nhật trạng thái hóa đơn (sử dụng version có commit)
            await InvoiceService.update_invoice_status(db, invoice_id, "processing")
            
            # 2. Xử lý với DocUnet (hoặc chỉ resize nếu DocUnet bị tắt)
            docunet_result = await self._process_with_docunet(db, invoice_id, invoice.file_path)
            
            # 3. Xử lý với Paddle OCR
            paddle_result = await self._process_with_paddle(db, invoice_id, docunet_result["output_path"])
            
            # 4. Xử lý với Schema Parser
            schema_result = await self._process_with_schema_parser(db, invoice_id, paddle_result["result_path"])
            
            # 5. Lưu thông tin trích xuất vào database (sử dụng single transaction)
            final_result = await self._save_extracted_info_with_transaction(db, invoice_id, schema_result)
            
            # Cập nhật trạng thái hoàn thành (sử dụng version có commit)
            await InvoiceService.update_invoice_status(db, invoice_id, "completed")
            
            await InvoiceService.add_invoice_log(
                db=db,
                invoice_id=invoice_id,
                message="Hoàn thành xử lý trích xuất thông tin",
                step="completed",
                status="completed"
            )
            
            logger.info(f"✅ Invoice processing completed for ID: {invoice_id}")
            
            return {
                "invoice_id": invoice_id,
                "status": "completed",
                "docunet_result": {
                    "status": docunet_result.get("status"),
                    "output_path": docunet_result.get("output_path"),
                    "message": docunet_result.get("message")
                },
                "paddle_result": {
                    "status": paddle_result.get("status"),
                    "output_path": paddle_result.get("output_path"),
                    "message": paddle_result.get("message")
                },
                "schema_result": {
                    "status": schema_result.get("status"),
                    "message": schema_result.get("message")
                },
                "extracted_info": final_result
            }
            
        except Exception as e:
            logger.error(f"❌ Invoice processing failed for ID {invoice_id}: {e}")
            
            try:
                # Rollback any pending transaction
                await db.rollback()
                
                # Cập nhật trạng thái lỗi (sử dụng version có commit)
                await InvoiceService.update_invoice_status(db, invoice_id, "failed")
                
                await InvoiceService.add_invoice_log(
                    db=db,
                    invoice_id=invoice_id,
                    message=f"Lỗi xử lý: {str(e)}",
                    step="error",
                    status="failed"
                )
            except Exception as rollback_error:
                logger.error(f"❌ Failed to rollback and log error: {rollback_error}")
            
            raise
    
    async def _process_with_docunet(self, db: AsyncSession, invoice_id: int, file_path: str) -> Dict[str, Any]:
        """Xử lý với DocUnet hoặc chỉ resize ảnh"""
        
        try:
            # 1. Resize ảnh về 512x512 (luôn thực hiện)
            resized_image_path = self.docunet_result_dir / f"invoice_{invoice_id}_512.jpg"
            await self._resize_image(file_path, resized_image_path, (512, 512))
            
            if InvoiceProcessor.USE_DOCUNET:
                logger.info(f"🔧 Processing with DocUnet for invoice {invoice_id}")
                
                # Log bắt đầu DocUnet (sử dụng version có commit)
                await InvoiceService.add_invoice_log(
                    db=db,
                    invoice_id=invoice_id,
                    message="Bắt đầu xử lý với DocUnet",
                    step="docunet_start",
                    status="processing"
                )
                
                # 2. Khởi tạo DocUnet predictor
                predictor = DocUnetPredictor(
                    checkpoint_path=self.docunet_checkpoint,
                    device='cpu'
                )
                
                # 3. Predict
                output_path = self.docunet_result_dir / f"invoice_{invoice_id}_processed.jpg"
                predictor.predict_single_image(
                    image_path=str(resized_image_path),
                    output_path=str(output_path),
                    save_displacement=True
                )
                
                # Log hoàn thành DocUnet (sử dụng version có commit)
                await InvoiceService.add_invoice_log(
                    db=db,
                    invoice_id=invoice_id,
                    message="Hoàn thành xử lý với DocUnet",
                    step="docunet_completed",
                    status="processing"
                )
                
                return {
                    "status": "success",
                    "input_path": str(resized_image_path),
                    "output_path": str(output_path),
                    "message": "DocUnet processing completed"
                }
            else:
                logger.info(f"🔧 DocUnet processing invoice {invoice_id}")
                
                # Log bỏ qua DocUnet (sử dụng version có commit)
                await InvoiceService.add_invoice_log(
                    db=db,
                    invoice_id=invoice_id,
                    message="Bỏ qua DocUnet - sử dụng ảnh đã resize",
                    step="docunet_skipped",
                    status="processing"
                )
                
                # Trả về ảnh đã resize làm kết quả "DocUnet"
                return {
                    "status": "skipped",
                    "input_path": str(resized_image_path),
                    "output_path": str(resized_image_path),  # Sử dụng ảnh resize làm output
                    "message": "DocUnet processed"
                }
            
        except Exception as e:
            logger.error(f"❌ Image processing failed: {e}")
            await InvoiceService.add_invoice_log(
                db=db,
                invoice_id=invoice_id,
                message=f"Lỗi xử lý ảnh: {str(e)}",
                step="image_processing_error",
                status="failed"
            )
            raise
    
    async def _process_with_paddle(self, db: AsyncSession, invoice_id: int, image_path: str) -> Dict[str, Any]:
        """Xử lý với Paddle OCR"""
        logger.info(f"🔧 Processing with Paddle OCR for invoice {invoice_id}")
        
        try:
            # Log bắt đầu Paddle (sử dụng version có commit)
            await InvoiceService.add_invoice_log(
                db=db,
                invoice_id=invoice_id,
                message="Bắt đầu xử lý với Paddle OCR",
                step="paddle_start",
                status="processing"
            )
            
            # Lấy preloaded OCR engine từ ModelManager
            from backend_invoice.model_manager import model_manager
            ocr_engine = model_manager.get_paddle_ocr()
            if ocr_engine is None:
                raise RuntimeError("Paddle OCR model not loaded. Please ensure models are preloaded during server startup.")
            
            # Predict
            result = ocr_engine.predict(image_path)
            
            # In kết quả
            ocr_engine.print_results(result)
            
            # Lưu kết quả
            ocr_engine.save_results(result, str(self.paddle_result_dir))
            
            # Log hoàn thành Paddle (sử dụng version có commit)
            await InvoiceService.add_invoice_log(
                db=db,
                invoice_id=invoice_id,
                message="Hoàn thành xử lý với Paddle OCR",
                step="paddle_completed",
                status="processing"
            )
            
            return {
                "status": "success",
                "result": result,
                "result_path": str(self.paddle_result_dir),
                "message": "Paddle OCR processing completed"
            }
            
        except Exception as e:
            logger.error(f"❌ Paddle OCR processing failed: {e}")
            await InvoiceService.add_invoice_log(
                db=db,
                invoice_id=invoice_id,
                message=f"Lỗi Paddle OCR: {str(e)}",
                step="paddle_error",
                status="failed"
            )
            raise
    
    async def _process_with_schema_parser(self, db: AsyncSession, invoice_id: int, result_path: str) -> Dict[str, Any]:
        """Xử lý với Schema Parser"""
        logger.info(f"🔧 Processing with Schema Parser for invoice {invoice_id}")
        
        try:
            # Log bắt đầu Schema Parser (sử dụng version có commit)
            await InvoiceService.add_invoice_log(
                db=db,
                invoice_id=invoice_id,
                message="Bắt đầu xử lý với Schema Parser",
                step="schema_start",
                status="processing"
            )
            
            # Xây dựng đường dẫn file JSON cụ thể từ đường dẫn thư mục
            # result_path là đường dẫn thư mục, cần tạo đường dẫn file cụ thể
            result_dir = Path(result_path)
            if not result_dir.is_absolute():
                # Nếu là đường dẫn tương đối, tạo đường dẫn tuyệt đối từ project root
                project_root = Path(__file__).parent.parent.parent
                result_dir = project_root / result_dir
            
            paddle_json_file = result_dir / f"invoice_{invoice_id}_512_res.json"
            
            # Kiểm tra file có tồn tại không
            if not paddle_json_file.exists():
                # Thử tìm file JSON bất kỳ trong thư mục nếu file cụ thể không tồn tại
                json_files = list(result_dir.glob("*.json"))
                if json_files:
                    paddle_json_file = json_files[0]
                    logger.warning(f"⚠️ Expected file not found, using: {paddle_json_file}")
                else:
                    raise FileNotFoundError(f"No JSON files found in directory: {result_dir}")
            
            logger.info(f"📄 Using Paddle OCR result file: {paddle_json_file}")
            
            # Khởi tạo schema parser
            parser = SchemaParser(fuzzy_threshold=65)
            
            # Parse thông tin với đường dẫn file cụ thể
            parsed_result = await parser.parse_invoice_data(str(paddle_json_file))
            
            # Lưu kết quả
            output_file = self.schema_result_dir / f"invoice_{invoice_id}_parsed.json"
            await parser.save_parsed_result(parsed_result, str(output_file))
            
            logger.info(f"✅ Schema parsing result saved to: {output_file}")
            
            # Log hoàn thành Schema Parser (sử dụng version có commit)
            await InvoiceService.add_invoice_log(
                db=db,
                invoice_id=invoice_id,
                message="Hoàn thành xử lý với Schema Parser",
                step="schema_completed",
                status="processing"
            )
            
            return {
                "status": "success",
                "parsed_data": parsed_result,
                "output_file": str(output_file),
                "message": "Schema parsing completed"
            }
            
        except Exception as e:
            logger.error(f"❌ Schema parsing failed: {e}")
            await InvoiceService.add_invoice_log(
                db=db,
                invoice_id=invoice_id,
                message=f"Lỗi Schema Parser: {str(e)}",
                step="schema_error",
                status="failed"
            )
            raise

    async def _save_extracted_info_with_transaction(self, db: AsyncSession, invoice_id: int, schema_result: Dict[str, Any]) -> Dict[str, Any]:
        """Lưu thông tin trích xuất vào database với single transaction"""
        logger.info(f"💾 Saving extracted info for invoice {invoice_id} with transaction management")
        
        try:
            from datetime import datetime
            
            # Log bắt đầu lưu (không commit)
            await InvoiceService.add_invoice_log(
                db=db,
                invoice_id=invoice_id,
                message="Bắt đầu lưu thông tin trích xuất",
                step="save_start",
                status="processing"
            )
            logger.info("✓ Initial log added successfully (no commit)")
            
            parsed_data = schema_result.get("parsed_data", {})
            
            # Chuẩn bị thông tin hóa đơn để cập nhật
            update_data = {}
            
            # Chỉ cập nhật các field có giá trị
            if parsed_data.get("invoice_number"):
                update_data["invoice_number"] = parsed_data["invoice_number"]
                
            if parsed_data.get("store_name"):
                update_data["store_name"] = parsed_data["store_name"]
                
            if parsed_data.get("store_address"):
                update_data["store_address"] = parsed_data["store_address"]
                
            if parsed_data.get("total_amount"):
                try:
                    update_data["total_amount"] = float(parsed_data["total_amount"])
                except (ValueError, TypeError):
                    logger.warning(f"Invalid total_amount: {parsed_data.get('total_amount')}")
                    
            if parsed_data.get("invoice_date"):
                try:
                    if isinstance(parsed_data["invoice_date"], str):
                        update_data["invoice_date"] = datetime.fromisoformat(parsed_data["invoice_date"])
                    else:
                        update_data["invoice_date"] = parsed_data["invoice_date"]
                except (ValueError, TypeError):
                    logger.warning(f"Invalid invoice_date: {parsed_data.get('invoice_date')}")
            
            # Cập nhật thông tin hóa đơn (không commit)
            if update_data:
                await InvoiceService.update_invoice_info(db, invoice_id, update_data)
                logger.info(f"✓ Invoice info updated: {list(update_data.keys())}")
            
            # Lưu các items (không commit)
            items_count = 0
            if parsed_data.get("items"):
                logger.info(f"🔄 Processing {len(parsed_data['items'])} items")
                try:
                    for item_data in parsed_data["items"]:
                        # Đảm bảo item có đủ thông tin cần thiết
                        logger.info(f"🔄 Adding item: {item_data}")
                        try:
                            db_item = await InvoiceService.add_invoice_item(
                                db=db,
                                invoice_id=invoice_id,
                                product_name=item_data.get("product_name", ""),
                                quantity=item_data.get("quantity", 1),
                                unit_price=item_data.get("unit_price", 0.0),
                                total_price=item_data.get("total_price", 0.0)
                            )
                            logger.info(f"✓ Item added successfully (no commit): item_id={db_item.item_id} invoice_id={invoice_id} product_name='{db_item.product_name}' quantity={db_item.quantity} unit_price={db_item.unit_price} total_price={db_item.total_price}")
                            items_count += 1
                        except Exception as e:
                            logger.error(f"❌ Failed to add item {item_data}: {e}")
                            raise
                except Exception as e:
                    logger.error(f"❌ Failed to save items: {e}")
                    raise
            
            # Log hoàn thành lưu (không commit)
            await InvoiceService.add_invoice_log(
                db=db,
                invoice_id=invoice_id,
                message=f"Đã lưu thành công {items_count} items",
                step="save_complete",
                status="success"
            )
            logger.info("✓ Completion log added successfully (no commit)")
            
            # COMMIT tất cả thay đổi cùng một lúc
            await db.commit()
            logger.info("✅ All changes committed successfully")
            
            logger.info(f"Saved extracted info for invoice {invoice_id}: {items_count} items")
            
            return {
                "status": "success",
                "updated_fields": list(update_data.keys()),
                "items_count": items_count,
                "message": "Extracted info saved successfully"
            }
            
        except Exception as e:
            logger.error(f"❌ Failed to save extracted info: {e}")
            # Rollback sẽ được xử lý ở level cao hơn
            raise

    async def _save_extracted_info(self, db: AsyncSession, invoice_id: int, schema_result: Dict[str, Any]) -> Dict[str, Any]:
        """Lưu thông tin trích xuất vào database"""
        logger.info(f"💾 Saving extracted info for invoice {invoice_id}")
        
        try:
            from datetime import datetime
            
            # Log bắt đầu lưu
            try:
                await InvoiceService.add_invoice_log(
                    db=db,
                    invoice_id=invoice_id,
                    message="Bắt đầu lưu thông tin trích xuất",
                    step="save_start",
                    status="processing"
                )
                logger.info("✓ Initial log added successfully")
            except Exception as e:
                logger.error(f"❌ Failed to add initial log: {e}")
                raise
            
            parsed_data = schema_result.get("parsed_data", {})
            
            # Chuẩn bị thông tin hóa đơn để cập nhật
            update_data = {}
            
            # Chỉ cập nhật các field có giá trị
            if parsed_data.get("invoice_number"):
                update_data["invoice_number"] = parsed_data["invoice_number"]
                
            if parsed_data.get("store_name"):
                update_data["store_name"] = parsed_data["store_name"]
                
            if parsed_data.get("store_address"):
                update_data["store_address"] = parsed_data["store_address"]
                
            if parsed_data.get("total_amount") is not None:
                update_data["total_amount"] = parsed_data["total_amount"]
                
            if parsed_data.get("invoice_date"):
                # Chuyển đổi string ISO date thành datetime nếu cần
                if isinstance(parsed_data["invoice_date"], str):
                    try:
                        update_data["invoice_date"] = datetime.fromisoformat(parsed_data["invoice_date"])
                    except ValueError:
                        logger.warning(f"Invalid date format: {parsed_data['invoice_date']}")
                else:
                    update_data["invoice_date"] = parsed_data["invoice_date"]
            
            # Cập nhật processed_time
            update_data["processed_time"] = datetime.now()
            
            # Cập nhật invoice nếu có thông tin
            if update_data:
                try:
                    await InvoiceService.update_invoice_info(db, invoice_id, update_data)
                    logger.info("✓ Invoice info updated successfully")
                except Exception as e:
                    logger.error(f"❌ Failed to update invoice info: {e}")
                    raise
            
            # Lưu items nếu có
            items_count = 0
            if "items" in parsed_data and parsed_data["items"]:
                try:
                    for item_data in parsed_data["items"]:
                        # Đảm bảo item có đủ thông tin cần thiết
                        logger.info(f"🔄 Adding item: {item_data}")
                        try:
                            item_result = await InvoiceService.add_invoice_item(
                                db=db,
                                invoice_id=invoice_id,
                                product_name=item_data.get("product_name", ""),
                                quantity=item_data.get("quantity", 1),
                                unit_price=item_data.get("unit_price", 0.0),
                                total_price=item_data.get("total_price", 0.0)
                            )
                            logger.info(f"✓ Item added successfully: {item_result}")
                            items_count += 1
                        except Exception as e:
                            logger.error(f"❌ Failed to add item {item_data}: {e}")
                            raise
                except Exception as e:
                    logger.error(f"❌ Failed to save items: {e}")
                    raise
            
            # Log hoàn thành lưu
            try:
                await InvoiceService.add_invoice_log(
                    db=db,
                    invoice_id=invoice_id,
                    message=f"Đã lưu thành công {items_count} items",
                    step="save_complete",
                    status="success"
                )
                logger.info("✓ Completion log added successfully")
            except Exception as e:
                logger.error(f"❌ Failed to add completion log: {e}")
                raise
            
            logger.info(f"Saved extracted info for invoice {invoice_id}: {items_count} items")
            
            return {
                "status": "success",
                "updated_fields": list(update_data.keys()),
                "items_count": items_count,
                "message": "Extracted info saved successfully"
            }
            
        except Exception as e:
            logger.error(f"❌ Failed to save extracted info: {e}")
            await InvoiceService.add_invoice_log(
                db=db,
                invoice_id=invoice_id,
                message=f"Lỗi lưu thông tin: {str(e)}",
                step="save_error",
                status="failed"
            )
            raise
    
    async def _resize_image(self, input_path: str, output_path: Path, size: tuple):
        """Resize ảnh về kích thước chỉ định"""
        try:
            # Kiểm tra nếu là file PDF
            if input_path.lower().endswith('.pdf'):
                # Chuyển đổi PDF thành ảnh
                img = await self._convert_pdf_to_image(input_path)
            else:
                # Mở file ảnh thông thường
                img = Image.open(input_path)
            
            # Convert to RGB if necessary
            if img.mode != 'RGB':
                img = img.convert('RGB')
            
            # Resize
            resized_img = img.resize(size, Image.Resampling.LANCZOS)
            
            # Save
            resized_img.save(output_path, 'JPEG', quality=95)
            
            # Close image if it was opened from file
            if not input_path.lower().endswith('.pdf'):
                img.close()
                
            logger.info(f"✅ Image resized: {input_path} -> {output_path}")
            
        except Exception as e:
            logger.error(f"❌ Failed to resize image: {e}")
            raise
    
    async def _convert_pdf_to_image(self, pdf_path: str) -> Image.Image:
        """Chuyển đổi PDF thành ảnh"""
        try:
            # TODO: Implement PDF to image conversion
            # For now, raise an error to indicate PDF processing is not available
            logger.error(f"❌ PDF processing not available yet: {pdf_path}")
            raise NotImplementedError("PDF processing is not implemented yet. Please use image files (JPG, PNG) instead.")
            
        except Exception as e:
            logger.error(f"❌ Failed to convert PDF to image: {e}")
            raise
