import os
import uuid
import shutil
import logging
from datetime import datetime, date
from pathlib import Path
from typing import Optional, Dict, Any
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from .db_models import Invoice as DBInvoice, InvoiceLog as DBInvoiceLog, User as DBUser
from .models import Invoice, InvoiceLog
from backend_invoice.logging_config import get_logger, log_function_call

# Configure your backend folder path
BACKEND_INVOICE_DIR = os.getenv("BACKEND_INVOICE_DIR", "./backend_invoices")
ALLOWED_EXTENSIONS = {".pdf", ".jpg", ".jpeg", ".png", ".tiff", ".tif"}

logger = get_logger(__name__)


@log_function_call
async def upload_raw_invoice(
    db: AsyncSession,
    file_path: str,
    uploaded_by: int,
    vendor: Optional[str] = None,
    invoice_date: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Upload a raw invoice file, store it in backend folder and save to database.

    Parameters
    ----------
    db : AsyncSession
        Database session for async operations.
    file_path : str
        Local path to the invoice file.
    uploaded_by : int
        User ID who uploaded the invoice.
    vendor : str, optional
        Vendor/store name. If not provided, will be extracted from file processing.
    invoice_date : str, optional
        Invoice date in ISO format (YYYY-MM-DD). Defaults to today.
    metadata : dict, optional
        Additional metadata for the invoice.

    Returns
    -------
    Dict[str, Any]
        Dictionary containing invoice_id, file_path, and upload status.

    Raises
    ------
    ValueError
        If the file extension is not allowed or user not found.
    FileNotFoundError
        If the local file does not exist.
    OSError
        If the copy operation fails.
    """
    logger.info(f"🔄 Starting upload process for file: {file_path}")
    
    # 1. Validate user exists
    result = await db.execute(select(DBUser).where(DBUser.user_id == uploaded_by))
    user = result.scalar_one_or_none()
    if not user:
        raise ValueError(f"User with ID {uploaded_by} not found")
    
    # 2. Validate file
    src = Path(file_path)
    if not src.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    ext = src.suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise ValueError(f"Unsupported file extension: {ext}. Allowed: {ALLOWED_EXTENSIONS}")

    # 3. Set default values
    if invoice_date is None:
        invoice_date = datetime.utcnow().strftime("%Y-%m-%d")
    
    if vendor is None:
        vendor = "Unknown Vendor"

    # 4. Generate unique file name and destination path
    file_uuid = uuid.uuid4().hex
    file_name = f"{file_uuid}{ext}"
    
    # Build destination path: backend/<vendor>/YYYY/<uuid>.ext
    dest_dir = Path(BACKEND_INVOICE_DIR) / vendor / invoice_date[:4]
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest_file = dest_dir / file_name

    try:
        # 5. Copy file to backend folder
        shutil.copy2(src, dest_file)
        logger.info(f"✅ File copied to: {dest_file}")
        
        # 6. Create invoice record in database
        db_invoice = DBInvoice(
            invoice_date=datetime.strptime(invoice_date, "%Y-%m-%d").date(),
            uploaded_by=uploaded_by,
            store_name=vendor,
            status="uploaded",
            original_file_name=src.name,
            file_type=ext.lstrip('.').upper(),
            file_path=str(dest_file.absolute())
        )
        
        db.add(db_invoice)
        await db.flush()  # Get the invoice_id
        
        # 7. Create initial log entry
        db_log = DBInvoiceLog(
            invoice_id=db_invoice.invoice_id,
            message=f"Invoice uploaded successfully. File: {src.name}",
            step="upload",
            status="completed"
        )
        
        db.add(db_log)
        await db.commit()
        
        # 8. Save optional metadata
        if metadata:
            meta_file = dest_dir / f"{file_name}.meta"
            import json
            meta_file.write_text(json.dumps(metadata, indent=2))
            logger.info(f"📝 Metadata saved to: {meta_file}")
        
        logger.info(f"🎉 Invoice upload completed. Invoice ID: {db_invoice.invoice_id}")
        
        return {
            "invoice_id": db_invoice.invoice_id,
            "file_path": str(dest_file.absolute()),
            "original_filename": src.name,
            "file_type": ext.lstrip('.').upper(),
            "vendor": vendor,
            "invoice_date": invoice_date,
            "status": "uploaded",
            "message": "Invoice uploaded successfully"
        }
        
    except OSError as e:
        logger.error(f"❌ Failed to copy file: {e}")
        await db.rollback()
        raise OSError(f"Failed to copy file to backend folder: {e}")
    except Exception as e:
        logger.error(f"❌ Database error during upload: {e}")
        await db.rollback()
        # Clean up copied file if database operation failed
        if dest_file.exists():
            dest_file.unlink()
        raise
