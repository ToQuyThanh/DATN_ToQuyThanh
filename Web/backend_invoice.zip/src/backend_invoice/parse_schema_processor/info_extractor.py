import json
import numpy as np
from sklearn.cluster import DBSCAN
from pathlib import Path

class InvoiceLineGrouper:
    def __init__(self, eps=10, min_samples=1):
        """
        Gom các text line theo tọa độ y bằng DBSCAN
        :param eps: khoảng cách y tối đa để ghép chung cụm
        :param min_samples: số điểm tối thiểu trong 1 cluster
        """
        self.eps = eps
        self.min_samples = min_samples

    def group_lines(self, texts, boxes):
        """
        Nhận danh sách texts và bounding boxes, trả về danh sách các dòng đã ghép
        """
        # Tính trung bình y của mỗi box
        y_coords = np.array([(b[1] + b[3]) / 2 for b in boxes]).reshape(-1, 1)

        # DBSCAN clustering
        clustering = DBSCAN(eps=self.eps, min_samples=self.min_samples)
        labels = clustering.fit_predict(y_coords)

        # Gom text theo cluster
        lines_dict = {}
        for lbl, txt, box in zip(labels, texts, boxes):
            if lbl not in lines_dict:
                lines_dict[lbl] = []
            lines_dict[lbl].append((box, txt))

        # Sắp xếp các dòng theo y, các text trong dòng theo x
        sorted_lines = []
        for lbl in sorted(lines_dict.keys()):
            line_items = sorted(lines_dict[lbl], key=lambda x: x[0][0])  # x_min
            line_text = " ".join([t for _, t in line_items])
            sorted_lines.append(line_text)

        return sorted_lines

    @staticmethod
    def load_json(file_path):
        """
        Đọc file JSON OCR từ PaddleOCR
        """
        file_path = Path(file_path)
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("rec_texts", []), data.get("rec_boxes", [])


# -----------------------------
# Ví dụ sử dụng
# -----------------------------
if __name__ == "__main__":
    json_path = r"X:\3_Projects\DATN\Project\backend_invoice\data\staging\paddle_result\image_512_res.json"

    rec_texts, rec_boxes = InvoiceLineGrouper.load_json(json_path)

    grouper = InvoiceLineGrouper(eps=7)
    lines = grouper.group_lines(rec_texts, rec_boxes)

    print(lines)
