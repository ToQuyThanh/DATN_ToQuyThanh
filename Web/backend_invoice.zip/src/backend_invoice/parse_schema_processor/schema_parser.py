from rapidfuzz import fuzz
from pydantic import BaseModel
from typing import List, Optional
from decimal import Decimal
from datetime import datetime, date
import re

from backend_invoice.models import *

# # -----------------------------
# # Models
# # -----------------------------
# class InvoiceItem(BaseModel):
#     item_id: int
#     invoice_id: int
#     product_name: str
#     quantity: int
#     unit_price: Decimal
#     total_price: Decimal

# class InvoiceLog(BaseModel):
#     log_id: int
#     invoice_id: int
#     log_time: datetime
#     message: Optional[str]
#     step: Optional[str]
#     status: Optional[str]

# class Invoice(BaseModel):
#     invoice_id: int
#     invoice_date: date
#     upload_time: datetime
#     processed_time: Optional[datetime]
#     uploaded_by: int
#     invoice_number: Optional[str]
#     store_name: Optional[str]
#     store_address: Optional[str]
#     total_amount: Optional[Decimal]
#     status: Optional[str]
#     original_file_name: Optional[str]
#     file_type: Optional[str]
#     items: Optional[List[InvoiceItem]] = []
#     logs: Optional[List[InvoiceLog]] = []

# -----------------------------
# RapidFuzz Parser
# -----------------------------
class RapidFuzzParser:
    def __init__(self, fuzzy_threshold: int = 65):
        self.threshold = fuzzy_threshold
        self.currency_symbols = ['RM', 'VND', 'USD', 'EUR', 'SGD', 'THB', '₫', '$', '€']

    # ---- Fuzzy matching ----
    def fuzzy_match_category(self, text: str, templates: dict) -> str:
        text_lower = text.lower()
        best_category = "unknown"
        best_score = 0
        for category, keywords in templates.items():
            for keyword in keywords:
                score = fuzz.partial_ratio(keyword, text_lower)
                if score > best_score and score >= self.threshold:
                    best_score = score
                    best_category = category
        return best_category

    # ---- Enhanced Utilities ----
    def extract_numbers_with_currency(self, text: str) -> List[dict]:
        """Extract numbers with their associated currency symbols"""
        results = []
        
        # Pattern to match currency + number or number + currency
        currency_patterns = [
            r'(RM|VND|USD|EUR|SGD|THB|₫|\$|€)\s*(\d+[.,]?\d*)',  # Currency before number
            r'(\d+[.,]?\d*)\s*(RM|VND|USD|EUR|SGD|THB|₫|\$|€)',  # Number before currency
            r'(\d+[.,]?\d*)',  # Just numbers without currency
        ]
        
        for pattern in currency_patterns:
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                if len(match.groups()) == 2:
                    if match.group(1) in self.currency_symbols:
                        # Currency first
                        currency = match.group(1)
                        number_str = match.group(2)
                    else:
                        # Number first
                        number_str = match.group(1)
                        currency = match.group(2) if len(match.groups()) > 1 else None
                else:
                    # Just number
                    number_str = match.group(1)
                    currency = None
                
                try:
                    # Handle different decimal separators
                    if ',' in number_str and '.' in number_str:
                        # Format like 1,234.56
                        number_str = number_str.replace(',', '')
                    elif ',' in number_str:
                        # Could be 1,23 (European) or 1,234 (thousands)
                        if len(number_str.split(',')[1]) <= 2:
                            number_str = number_str.replace(',', '.')
                        else:
                            number_str = number_str.replace(',', '')
                    
                    number = Decimal(number_str)
                    results.append({
                        'value': number,
                        'currency': currency,
                        'original_text': match.group(0)
                    })
                except:
                    continue
        
        return results

    @staticmethod
    def extract_numbers(text: str) -> List[Decimal]:
        """Legacy method for backward compatibility"""
        matches = re.findall(r'\d+[.,]?\d*', text)
        numbers = []
        for m in matches:
            try:
                # Handle different decimal separators
                if ',' in m and '.' in m:
                    # Format like 1,234.56
                    num_str = m.replace(',', '')
                elif ',' in m:
                    # Could be 1,23 (European) or 1,234 (thousands)
                    if len(m.split(',')[1]) <= 2:
                        num_str = m.replace(',', '.')
                    else:
                        num_str = m.replace(',', '')
                else:
                    num_str = m
                
                num = Decimal(num_str)
                numbers.append(num)
            except:
                continue
        return numbers

    @staticmethod
    def extract_date(text: str) -> Optional[date]:
        """Enhanced date extraction supporting multiple formats"""
        date_patterns = [
            r'(\d{1,2}/\d{1,2}/\d{4})',  # DD/MM/YYYY or MM/DD/YYYY
            r'(\d{1,2}-\d{1,2}-\d{4})',  # DD-MM-YYYY or MM-DD-YYYY
            r'(\d{4}/\d{1,2}/\d{1,2})',  # YYYY/MM/DD
            r'(\d{4}-\d{1,2}-\d{1,2})',  # YYYY-MM-DD
            r'(\d{1,2}\.\d{1,2}\.\d{4})', # DD.MM.YYYY
            r'(\d{1,2}\s+\d{1,2}\s+\d{4})', # DD MM YYYY
        ]
        
        for pattern in date_patterns:
            match = re.search(pattern, text)
            if match:
                date_str = match.group(1)
                
                # Try different date formats
                date_formats = [
                    "%d/%m/%Y", "%m/%d/%Y",  # DD/MM/YYYY, MM/DD/YYYY
                    "%d-%m-%Y", "%m-%d-%Y",  # DD-MM-YYYY, MM-DD-YYYY
                    "%Y/%m/%d", "%Y-%m-%d",  # YYYY/MM/DD, YYYY-MM-DD
                    "%d.%m.%Y",              # DD.MM.YYYY
                    "%d %m %Y",              # DD MM YYYY
                ]
                
                for fmt in date_formats:
                    try:
                        return datetime.strptime(date_str, fmt).date()
                    except ValueError:
                        continue
        
        return None

    @staticmethod
    def extract_invoice_number(text: str) -> Optional[str]:
        """Enhanced invoice number extraction"""
        patterns = [
            r'(?:H|HD|No|Bill\s*No|Invoice\s*No|Receipt\s*No):?\s*([A-Z0-9]+)',
            r'(?:Bi11|Bill)\s*(?:No|Number):?\s*([A-Z0-9]+)',  # Handle OCR errors
            r'#\s*([A-Z0-9]+)',  # Invoice numbers with #
            r'([A-Z]{2,}\d+)',   # Pattern like ABC123
            r'(\d{6,})',         # Long number sequences
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return match.group(1)
        
        return None

    def detect_store_info(self, lines: List[str]) -> dict:
        """Enhanced store information detection"""
        store_info = {
            'name': None,
            'address': [],
            'phone': None,
            'tax_number': None,
            'country': None
        }
        
        # Store name patterns
        store_patterns = [
            # Vietnamese stores
            r'(vinmart|vincommerce|coop\s*mart|circle\s*k|big\s*c|lotte|aeon)',
            # International stores
            r'(lightroom|7-eleven|walmart|target|tesco|carrefour)',
            # Malaysian patterns
            r'(sdn\s*bhd|bhd)',
            # General retail patterns
            r'(supermarket|mart|store|shop|retail)',
        ]
        
        # Address indicators
        address_patterns = [
            r'(jalan|street|st\.|road|rd\.|avenue|ave\.|boulevard)',
            r'(malaysia|vietnam|singapore|thailand|indonesia)',
            r'(\d{5}|\d{6})',  # Postal codes
        ]
        
        # Phone patterns
        phone_patterns = [
            r'(tel|phone|fax):?\s*([0-9\-\+\s\(\)]+)',
            r'(\+?[0-9]{2,3}[\-\s]?[0-9]{3,4}[\-\s]?[0-9]{3,4})',
        ]
        
        # Tax/GST patterns
        tax_patterns = [
            r'(gst\s*no|tax\s*no|vat\s*no):?\s*([A-Z0-9]+)',
            r'(roc\s*no):?\s*\(([A-Z0-9\-]+)\)',
        ]
        
        for i, line in enumerate(lines):
            line_lower = line.lower()
            
            # Store name detection
            if not store_info['name']:
                for pattern in store_patterns:
                    if re.search(pattern, line_lower):
                        store_info['name'] = line.strip()
                        break
            
            # Address detection
            for pattern in address_patterns:
                if re.search(pattern, line_lower):
                    store_info['address'].append(line.strip())
                    # Also check next few lines for continuation
                    for j in range(i+1, min(i+3, len(lines))):
                        next_line = lines[j].strip()
                        if len(next_line) > 5 and not re.search(r'(invoice|receipt|bill)', next_line.lower()):
                            store_info['address'].append(next_line)
                    break
            
            # Phone detection
            for pattern in phone_patterns:
                match = re.search(pattern, line, re.IGNORECASE)
                if match:
                    store_info['phone'] = match.group(2) if len(match.groups()) > 1 else match.group(1)
                    break
            
            # Tax number detection
            for pattern in tax_patterns:
                match = re.search(pattern, line, re.IGNORECASE)
                if match:
                    store_info['tax_number'] = match.group(2) if len(match.groups()) > 1 else match.group(1)
                    break
            
            # Country detection
            if 'malaysia' in line_lower:
                store_info['country'] = 'Malaysia'
            elif 'vietnam' in line_lower or 'việt nam' in line_lower:
                store_info['country'] = 'Vietnam'
            elif 'singapore' in line_lower:
                store_info['country'] = 'Singapore'
        
        return store_info

    # ---- Main parse ----
    def parse(self, ocr_lines: List[str], invoice_id: int, uploaded_by: int) -> Invoice:
        # Enhanced templates for international support
        TEMPLATES = {
            "store": [
                # Vietnamese stores - major chains
                "vinmart", "winmart", "win mart", "wincommerce", "vincommerce",
                "coop mart", "coopmart", "circle k", "big c", "bigc", 
                "lotte", "aeon", "mega market", "megamarket", "emart", "e-mart",
                "saigon coop", "saigoncoop", "co.op mart", "co.opmart",
                "bach hoa xanh", "bachhoa xanh", "bach hoa", "bachhoa",
                "gs25", "gs 25", "family mart", "familymart",
                "ministop", "mini stop", "shop&go", "shop & go",
                # Vietnamese store types
                "sieu thi", "sieuthi", "cua hang", "cuahang", "tap hoa", "taphoa",
                "cua hang tien loi", "tien loi", "tienloi", "mini mart", "minimart",
                "cua hang bach hoa", "bach hoa tong hop", "tonghop",
                # Vietnamese company indicators
                "cong ty", "congty", "tnhh", "co ltd", "company", "corporation",
                "thuong mai tong hop", "dich vu thuong mai", "vin group", "vingroup"
            ],
            "total": [
                # Chuẩn
                "TỔNG TIỀN THANH TOÁN", "tổng tiền thanh toán",
                # Không dấu
                "TONG TIEN THANH TOAN", "tong tien thanh toan", "tongtienthanhtoan",
                # Lỗi dấu
                "TỔNG TIEN THANH TOÁN", "TỔNG TIỀN THANH TOAN", "tổng tien thanh toán", "tong tien thanh toan"
            
            ],
            "subtotal": [
                "tong tien hang", "tongtienhang", "tien hang", "tienhang",
                "tong truoc thue", "tongtruocthue", "truoc thue", "truocthue",
                "tong chua thue", "tongchuathue", "chua thue", "chuathue",
                "tong phu", "tongphu", "tam tinh", "tamtinh"
            ],
            "tax": [
                "thue", "thue gtgt", "thuegtgt", "thue gia tri gia tang", "thuegiatrigiatang",
                "thue vat", "thuevat", "vat", "gtgt", "phi dich vu", "phidichvu",
                "dich vu", "dichvu", "phi phuc vu", "phiphucvu", "phuc vu", "phucvu",
                "thue suat", "thuesuat", "ti le thue", "tilethue",
                # Winmart specific
                "tien thue", "tien thue gtgt", "thue suat gtgt"
            ],
            "discount": [
                "giam gia", "giamgia", "chiet khau", "chietkhau", "khuyen mai", "khuyenmai",
                "giam tru", "giamtru", "uu dai", "uudai", "giam", "voucher",
                "ma giam gia", "magiamgia", "coupon", "giam gia khuyen mai", "giamgiakhuyenmai",
                "tru", "hoan tien", "hoantien", "hoan lai", "hoanlai"
            ],
            "payment": [
                "khach tra", "khachtra", "khach hang tra", "khachhangtra",
                "nhan duoc", "nhanduoc", "da nhan", "danhan", "thu duoc", "thuduoc",
                "tien mat", "tienmat", "tien the", "tienthe", "the", "card",
                "chuyen khoan", "chuyenkhoan", "ck", "atm", "visa", "master",
                "thanh toan", "thanhtoan", "tra tien", "tratien",
                # Winmart specific
                "khach thanh toan", "khach thanh toán"
            ],
            "change": [
                "tra lai", "tralai", "tien thoi", "tienthoi", "thoi lai", "thoilai",
                "du", "thua", "con lai", "conlai", "tien du", "tiendu",
                "hoan tra", "hoantra", "tra khach", "trakhach",
                # Winmart specific
                "tien thua", "tien tra lai", "tra tien thua"
            ],
            "date": [
                "ngay", "ngay ban", "ngayban", "ngay lap", "ngaylap",
                "ngay xuat", "ngayxuat", "ngay in", "ngayin", "ngay tao", "ngaytao",
                "thoi gian", "thoigian", "gio", "ngay gio", "ngaygio",
                "ngay thang", "ngaythang", "ngay hoa don", "ngayhoadon",
                "ngay mua", "ngaymua", "ngay giao dich", "ngaygiaodich",
                # Winmart specific
                "ngay in hd", "ngay lap hd", "ngay giao dich"
            ],
            "item_header": [
                "mat hang", "mathang", "hang hoa", "hanghoa", "san pham", "sanpham",
                "ten hang", "tenhang", "ten san pham", "tensanpham", "ten sp", "tensp",
                "danh sach", "danhsach", "chi tiet", "chitiet", "noi dung", "noidung",
                "mo ta", "mota", "ten", "hang", "sp", "product",
                # Winmart specific
                "ma sp", "ma hang", "ma hang hoa"
            ],
            "quantity": [
                "so luong", "soluong", "sl", "qty", "quantity", "so", "luong",
                "don vi", "donvi", "dv", "unit", "cai", "hop", "chai", "goi",
                "kg", "gram", "lit", "ml", "met", "cm"
            ],
            "price": [
                "gia", "gia ban", "giaban", "don gia", "dongia", "gia le", "giale",
                "gia tien", "giatien", "tien", "price", "cost", "gia ca", "giaca",
                "gia tri", "giatri", "tri gia", "trigia",
                # Winmart specific
                "thanh tien"
            ],
            "invoice_number": [
                "so hoa don", "sohoadon", "so hd", "sohd", "ma hoa don", "mahoadon",
                "ma hd", "mahd", "so phieu", "sophieu", "ma phieu", "maphieu",
                "so bill", "sobill", "bill no", "billno", "receipt no", "receiptno",
                "so ct", "soct", "so chung tu", "sochungtu",
                # Winmart specific
                "ma giao dich", "magiaodich", "so giao dich", "sogiaodich"
            ]
        }


        lines = [l.strip() for l in ocr_lines if l.strip()]
        
        # Use enhanced store detection
        store_info = self.detect_store_info(lines)
        
        # Initialize variables
        items: List[InvoiceItem] = []
        invoice_number = None
        total_amount = None
        invoice_date = None
        subtotal = None
        tax_amount = None
        discount_amount = None
        
        current_product_name = None
        item_counter = 1
        in_item_section = False
        
        # First pass: extract basic information
        for i, line in enumerate(lines):
            # Extract invoice number
            if not invoice_number:
                invoice_number = self.extract_invoice_number(line)
            
            # Extract date
            if not invoice_date:
                invoice_date = self.extract_date(line)
        
        # Second pass: categorize and extract detailed information
        for i, line in enumerate(lines):
            category = self.fuzzy_match_category(line, TEMPLATES)
            
            # Check if we're in item section
            if category == "item_header":
                in_item_section = True
                continue
            
            # Item detection with multiple patterns
            item_detected = False
            
            # Pattern 1: Barcode line (13+ digits)
            if re.search(r'\d{13,}', line):
                numbers_with_currency = self.extract_numbers_with_currency(line)
                if len(numbers_with_currency) >= 3:
                    item = InvoiceItem(
                        item_id=item_counter,
                        invoice_id=invoice_id,
                        product_name=current_product_name or "Unknown Product",
                        quantity=int(numbers_with_currency[1]['value']),
                        unit_price=numbers_with_currency[0]['value'],
                        total_price=numbers_with_currency[2]['value']
                    )
                    items.append(item)
                    item_counter += 1
                    current_product_name = None
                    item_detected = True
            
            # Pattern 2: Line with quantity, unit price, and total (like "2 * RM 33.02 UNI 3.96) =RM 66.04")
            elif re.search(r'\d+\s*\*.*?=.*?\d+', line):
                numbers_with_currency = self.extract_numbers_with_currency(line)
                if len(numbers_with_currency) >= 3:
                    item = InvoiceItem(
                        item_id=item_counter,
                        invoice_id=invoice_id,
                        product_name=current_product_name or "Unknown Product",
                        quantity=int(numbers_with_currency[0]['value']),
                        unit_price=numbers_with_currency[1]['value'],
                        total_price=numbers_with_currency[-1]['value']
                    )
                    items.append(item)
                    item_counter += 1
                    current_product_name = None
                    item_detected = True
            
            # Pattern 3: Simple price line with 2-3 numbers
            elif in_item_section and len(self.extract_numbers(line)) >= 2:
                numbers = self.extract_numbers(line)
                if len(numbers) == 2:
                    # Assume quantity 1, unit price, total price
                    item = InvoiceItem(
                        item_id=item_counter,
                        invoice_id=invoice_id,
                        product_name=current_product_name or "Unknown Product",
                        quantity=1,
                        unit_price=numbers[0],
                        total_price=numbers[1]
                    )
                elif len(numbers) >= 3:
                    item = InvoiceItem(
                        item_id=item_counter,
                        invoice_id=invoice_id,
                        product_name=current_product_name or "Unknown Product",
                        quantity=int(numbers[0]),
                        unit_price=numbers[1],
                        total_price=numbers[2]
                    )
                
                if 'item' in locals():
                    items.append(item)
                    item_counter += 1
                    current_product_name = None
                    item_detected = True
            
            # If no item detected, this might be a product name
            if not item_detected and not re.search(r'(total|tax|gst|discount|change|payment)', line.lower()):
                # Skip obvious non-product lines
                if not re.search(r'(invoice|receipt|bill|date|time|cashier|station)', line.lower()):
                    current_product_name = line
            
            # Extract totals and other amounts
            if category == "total" and not total_amount:
                numbers_with_currency = self.extract_numbers_with_currency(line)
                if numbers_with_currency:
                    total_amount = numbers_with_currency[-1]['value']
            
            elif category == "subtotal" and not subtotal:
                numbers_with_currency = self.extract_numbers_with_currency(line)
                if numbers_with_currency:
                    subtotal = numbers_with_currency[-1]['value']
            
            elif category == "tax" and not tax_amount:
                numbers_with_currency = self.extract_numbers_with_currency(line)
                if numbers_with_currency:
                    tax_amount = numbers_with_currency[-1]['value']
            
            elif category == "discount" and not discount_amount:
                numbers_with_currency = self.extract_numbers_with_currency(line)
                if numbers_with_currency:
                    discount_amount = numbers_with_currency[-1]['value']

        # Use store info from enhanced detection
        store_name = store_info['name']
        store_address = ' '.join(store_info['address']) if store_info['address'] else None

        return Invoice(
            invoice_id=invoice_id,
            invoice_date=invoice_date or date.today(),
            upload_time=datetime.now(),
            processed_time=None,
            uploaded_by=uploaded_by,
            invoice_number=invoice_number,
            store_name=store_name,
            store_address=store_address,
            total_amount=total_amount,
            status="parsed",
            original_file_name=None,
            file_type=None,
            items=items,
            logs=[]
        )

# -----------------------------
# Schema Parser Wrapper
# -----------------------------
class SchemaParser:
    """Wrapper class cho RapidFuzzParser để tích hợp với InvoiceProcessor"""
    
    def __init__(self, fuzzy_threshold: int = 65):
        self.parser = RapidFuzzParser(fuzzy_threshold)
    
    async def parse_invoice_data(self, result_path: str) -> dict:
        """
        Parse thông tin hóa đơn từ kết quả Paddle OCR
        
        Args:
            result_path: Đường dẫn đến thư mục chứa kết quả Paddle OCR
            
        Returns:
            Dict chứa thông tin đã parse
        """
        import json
        from pathlib import Path
        from backend_invoice.parse_schema_processor.info_extractor import InvoiceLineGrouper
        
        # Xử lý đường dẫn - có thể là file hoặc thư mục
        path = Path(result_path)
        
        if path.is_file() and path.suffix == '.json':
            # Nếu là file JSON cụ thể
            json_path = path
        elif path.is_dir():
            # Nếu là thư mục, tìm file JSON đầu tiên
            json_files = list(path.glob("*.json"))
            if not json_files:
                raise FileNotFoundError(f"No JSON files found in {result_path}")
            json_path = json_files[0]
        else:
            raise ValueError(f"Invalid path: {result_path}. Must be a JSON file or directory containing JSON files.")
        
        # Load và group lines
        rec_texts, rec_boxes = InvoiceLineGrouper.load_json(str(json_path))
        grouper = InvoiceLineGrouper(eps=7)
        lines = grouper.group_lines(rec_texts, rec_boxes)

        print(lines)
        
        # Parse với RapidFuzzParser
        # Sử dụng dummy values cho invoice_id và uploaded_by vì chúng sẽ được cập nhật sau
        invoice = self.parser.parse(lines, invoice_id=0, uploaded_by=0)
        
        # Chuyển đổi sang format dict
        result = {
            "invoice_number": invoice.invoice_number,
            "store_name": invoice.store_name,
            "store_address": invoice.store_address,
            "total_amount": float(invoice.total_amount) if invoice.total_amount else None,
            "invoice_date": invoice.invoice_date.isoformat() if invoice.invoice_date else None,
            "items": []
        }
        
        # Chuyển đổi items
        for item in invoice.items:
            result["items"].append({
                "product_name": item.product_name,
                "quantity": item.quantity,
                "unit_price": float(item.unit_price),
                "total_price": float(item.total_price)
            })
        
        return result
    
    async def save_parsed_result(self, parsed_data: dict, output_file: str):
        """Lưu kết quả parse vào file JSON"""
        import json
        from pathlib import Path
        
        output_path = Path(output_file)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(parsed_data, f, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    # Giả sử bạn đã import
    # from parser_module import RapidFuzzParser, Invoice

    # OCR lines ví dụ
    ocr_data = [
        'VM+ONH Duran KDC lan bién cocs',
        'DA khu DCLB coc B,P.Cam Son',
        'VinCommerce TP.Cam Pha,T.Quang Ninh',
        '024.71066866-44561',
        'HOA DN BAN HANG',
        'Ngaybán:14/08/2020 21:37 H:00073344',
        'Quay:001 NVBH:09021213',
        'Mat hang dn giá SL T.Tien',
        'Kem hudng sau riēng Vinamilk hop 450m',
        '8934673295208 43.800 1 43.800',
        'TONG TIEN PHAI T.TOAN 43.800'
    ]

    # Tạo parser
    parser = RapidFuzzParser(fuzzy_threshold=65)

    # Gọi parse trực tiếp, map sang schema mới
    invoice_id = 1
    uploaded_by = 123
    invoice: Invoice = parser.parse(ocr_data, invoice_id=invoice_id, uploaded_by=uploaded_by)

    # In kết quả
    print(invoice.model_dump_json(indent=2, by_alias=False))
