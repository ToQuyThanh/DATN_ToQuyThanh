from backend_invoice.parse_schema_processor.info_extractor import InvoiceLineGrouper
from backend_invoice.parse_schema_processor.schema_parser import RapidFuzzParser, Invoice


if __name__ == "__main__":
    json_path = r"X:\3_Projects\DATN\Project\backend_invoice\data\staging\paddle_result\image_512_res.json"

    rec_texts, rec_boxes = InvoiceLineGrouper.load_json(json_path)

    grouper = InvoiceLineGrouper(eps=7)
    lines = grouper.group_lines(rec_texts, rec_boxes)

    # Tạo parser
    parser = RapidFuzzParser(fuzzy_threshold=65)

    # Gọi parse trực tiếp, map sang schema mới
    invoice_id = 1
    uploaded_by = 123
    invoice: Invoice = parser.parse(lines, invoice_id=invoice_id, uploaded_by=uploaded_by)

    # In kết quả
    print(invoice.model_dump_json(indent=2, by_alias=False))


