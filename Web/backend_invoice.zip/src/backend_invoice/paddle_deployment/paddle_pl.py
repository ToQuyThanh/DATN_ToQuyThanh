from paddleocr import PaddleOCR
from pathlib import Path

class InvoiceOCR:
    def __init__(
        self,
        use_doc_orientation_classify=True,
        use_doc_unwarping=True,
        use_textline_orientation=True,
        device="cpu",  # hoặc "gpu"
        lang="vi",     # "en" nếu tiếng Anh
    ):
        """
        Khởi tạo OCR với các tùy chọn.
        """
        self.ocr = PaddleOCR(
            use_doc_orientation_classify=use_doc_orientation_classify,
            use_doc_unwarping=use_doc_unwarping,
            use_textline_orientation=use_textline_orientation,
            device=device,
            lang=lang
        )

    def predict(self, image_path: str):
        """
        Chạy OCR trên ảnh và trả về kết quả.
        """
        result = self.ocr.predict(str(image_path))
        return result

    def save_results(self, result, output_dir: str):
        """
        Lưu kết quả OCR ra ảnh và JSON.
        """
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        for i, res in enumerate(result):
            res.save_to_img(output_path)
            res.save_to_json(output_path)

    def print_results(self, result):
        """
        In kết quả OCR ra console.
        """
        for res in result:
            res.print()


# -----------------------------
# Ví dụ sử dụng
# -----------------------------
if __name__ == "__main__":
    ocr_engine = InvoiceOCR(
        use_doc_orientation_classify=True,
        use_doc_unwarping=True,
        use_textline_orientation=True,
        device="cpu"
    )

    image_path = r"X:\3_Projects\DATN\Project\paddle_invoice\image_512.jpg"
    output_dir = r"X:\3_Projects\DATN\Project\backend_invoice\data\staging\paddle_result"

    result = ocr_engine.predict(image_path)
    ocr_engine.print_results(result)
    ocr_engine.save_results(result, output_dir)
