"""
Service layer for invoice management business logic.

This module provides high-level business logic functions that coordinate
between the API layer and database operations.
"""

import logging
from typing import Dict, Any, List, Optional
from pathlib import Path
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_

from .db_models import Invoice as DBInvoice, InvoiceItem as DBInvoiceItem, InvoiceLog as DBInvoiceLog, User as DBUser
from .models import Invoice, InvoiceItem, InvoiceLog, User
from .upload_raw_invoice import upload_raw_invoice
from .logging_config import get_logger, log_function_call

logger = get_logger(__name__)


class InvoiceService:
    """Service class for invoice-related business operations."""
    
    @staticmethod
    async def upload_invoice_file(
        db: AsyncSession,
        file_path: str,
        uploaded_by: int,
        vendor: Optional[str] = None,
        invoice_date: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Upload an invoice file and create database records.
        
        Args:
            db: Database session
            file_path: Path to the invoice file
            uploaded_by: User ID who uploaded the file
            vendor: Vendor/store name
            invoice_date: Invoice date in YYYY-MM-DD format
            metadata: Additional metadata
            
        Returns:
            Dictionary with upload results
        """
        logger.info(f"📤 Service: Starting invoice upload for user {uploaded_by}")
        
        try:
            result = await upload_raw_invoice(
                db=db,
                file_path=file_path,
                uploaded_by=uploaded_by,
                vendor=vendor,
                invoice_date=invoice_date,
                metadata=metadata
            )
            
            logger.info(f"✅ Service: Invoice upload completed. ID: {result['invoice_id']}")
            return result
            
        except Exception as e:
            logger.error(f"❌ Service: Invoice upload failed: {e}")
            raise
    
    @staticmethod
    async def get_invoice_by_id(db: AsyncSession, invoice_id: int) -> Optional[Invoice]:
        """Get invoice by ID."""
        result = await db.execute(select(DBInvoice).where(DBInvoice.invoice_id == invoice_id))
        db_invoice = result.scalar_one_or_none()
        
        if not db_invoice:
            return None
            
        return Invoice(
            invoice_id=db_invoice.invoice_id,
            invoice_date=db_invoice.invoice_date,
            upload_time=db_invoice.upload_time,
            processed_time=db_invoice.processed_time,
            uploaded_by=db_invoice.uploaded_by,
            store_name=db_invoice.store_name,
            total_amount=db_invoice.total_amount,
            status=db_invoice.status,
            original_file_name=db_invoice.original_file_name,
            file_type=db_invoice.file_type,
            file_path=db_invoice.file_path
        )
    
    @staticmethod
    async def get_invoices_by_user(
        db: AsyncSession, 
        user_id: int, 
        limit: int = 50, 
        offset: int = 0
    ) -> List[Invoice]:
        """Get invoices for a specific user."""
        result = await db.execute(
            select(DBInvoice)
            .where(DBInvoice.uploaded_by == user_id)
            .order_by(DBInvoice.upload_time.desc())
            .limit(limit)
            .offset(offset)
        )
        
        db_invoices = result.scalars().all()
        
        return [
            Invoice(
                invoice_id=db_invoice.invoice_id,
                invoice_date=db_invoice.invoice_date,
                upload_time=db_invoice.upload_time,
                uploaded_by=db_invoice.uploaded_by,
                store_name=db_invoice.store_name,
                total_amount=db_invoice.total_amount,
                status=db_invoice.status,
                original_file_name=db_invoice.original_file_name,
                file_type=db_invoice.file_type
            )
            for db_invoice in db_invoices
        ]
    
    @staticmethod
    async def get_invoice_logs(db: AsyncSession, invoice_id: int) -> List[InvoiceLog]:
        """Get logs for a specific invoice."""
        result = await db.execute(
            select(DBInvoiceLog)
            .where(DBInvoiceLog.invoice_id == invoice_id)
            .order_by(DBInvoiceLog.log_time.desc())
        )
        
        db_logs = result.scalars().all()
        
        return [
            InvoiceLog(
                log_id=db_log.log_id,
                invoice_id=db_log.invoice_id,
                message=db_log.message,
                step=db_log.step,
                status=db_log.status,
                log_time=db_log.log_time
            )
            for db_log in db_logs
        ]
    
    @staticmethod
    async def add_invoice_log(
        db: AsyncSession,
        invoice_id: int,
        message: str,
        step: str,
        status: str = "info"
    ) -> InvoiceLog:
        """Add a log entry for an invoice."""
        from datetime import datetime
        
        db_log = DBInvoiceLog(
            invoice_id=invoice_id,
            message=message,
            step=step,
            status=status
        )
        
        db.add(db_log)
        await db.commit()
        # Không refresh để tránh lỗi SQLite
        
        return InvoiceLog(
            log_id=db_log.log_id or 0,  # Fallback nếu chưa có ID
            invoice_id=db_log.invoice_id,
            message=db_log.message,
            step=db_log.step,
            status=db_log.status,
            log_time=db_log.log_time or datetime.now()  # Fallback nếu chưa có time
        )
    
    @staticmethod
    async def update_invoice_status(db: AsyncSession, invoice_id: int, status: str) -> bool:
        """Update invoice status."""
        result = await db.execute(select(DBInvoice).where(DBInvoice.invoice_id == invoice_id))
        db_invoice = result.scalar_one_or_none()
        
        if not db_invoice:
            return False
            
        db_invoice.status = status
        await db.commit()
        return True
    
    @staticmethod
    async def update_invoice_info(db: AsyncSession, invoice_id: int, update_data: Dict[str, Any]) -> bool:
        """Update invoice information."""
        result = await db.execute(select(DBInvoice).where(DBInvoice.invoice_id == invoice_id))
        db_invoice = result.scalar_one_or_none()
        
        if not db_invoice:
            return False
        
        # Update fields
        for field, value in update_data.items():
            if hasattr(db_invoice, field):
                setattr(db_invoice, field, value)
        
        await db.commit()
        return True
    
    @staticmethod
    async def add_invoice_item(
        db: AsyncSession,
        invoice_id: int,
        product_name: str,
        quantity: int = 1,
        unit_price: float = 0.0,
        total_price: float = 0.0
    ) -> InvoiceItem:
        """Add an item to an invoice."""
        db_item = DBInvoiceItem(
            invoice_id=invoice_id,
            product_name=product_name,
            quantity=quantity,
            unit_price=unit_price,
            total_price=total_price
        )
        
        db.add(db_item)
        await db.commit()
        # Không refresh để tránh lỗi SQLite
        
        return InvoiceItem(
            item_id=db_item.item_id or 0,  # Fallback nếu chưa có ID
            invoice_id=db_item.invoice_id,
            product_name=db_item.product_name,
            quantity=db_item.quantity,
            unit_price=db_item.unit_price,
            total_price=db_item.total_price
        )
    
    @staticmethod
    async def get_total_invoices(db: AsyncSession) -> int:
        """Get total number of invoices."""
        from sqlalchemy import func
        result = await db.execute(select(func.count(DBInvoice.invoice_id)))
        return result.scalar() or 0
    
    @staticmethod
    async def get_invoices_by_status(db: AsyncSession, status: str) -> int:
        """Get count of invoices by status."""
        from sqlalchemy import func
        result = await db.execute(
            select(func.count(DBInvoice.invoice_id)).where(DBInvoice.status == status)
        )
        return result.scalar() or 0
    
    @staticmethod
    async def get_total_amount(db: AsyncSession) -> float:
        """Get total amount of all invoices."""
        from sqlalchemy import func
        result = await db.execute(
            select(func.sum(DBInvoice.total_amount)).where(DBInvoice.status == "completed")
        )
        total = result.scalar()
        return float(total) if total is not None else 0.0
    
    @staticmethod
    async def get_invoices_with_filter(
        db: AsyncSession,
        query: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 10,
        offset: int = 0
    ) -> List[Invoice]:
        """Get invoices with filter and pagination."""
        stmt = select(DBInvoice)
        
        # Apply filters
        if query:
            stmt = stmt.where(
                (DBInvoice.invoice_number.ilike(f"%{query}%")) |
                (DBInvoice.store_name.ilike(f"%{query}%")) |
                (DBInvoice.store_address.ilike(f"%{query}%"))
            )
        
        if status:
            stmt = stmt.where(DBInvoice.status == status)
        
        # Apply pagination
        stmt = stmt.order_by(DBInvoice.upload_time.desc()).limit(limit).offset(offset)
        
        result = await db.execute(stmt)
        db_invoices = result.scalars().all()
        
        return [
            Invoice(
                invoice_id=db_inv.invoice_id,
                invoice_date=db_inv.invoice_date,
                upload_time=db_inv.upload_time,
                processed_time=db_inv.processed_time,
                uploaded_by=db_inv.uploaded_by,
                invoice_number=db_inv.invoice_number,
                store_name=db_inv.store_name,
                store_address=db_inv.store_address,
                total_amount=db_inv.total_amount,
                status=db_inv.status,
                items=[]
            ) for db_inv in db_invoices
        ]
    
    @staticmethod
    async def get_total_invoices_with_filter(
        db: AsyncSession,
        query: Optional[str] = None,
        status: Optional[str] = None
    ) -> int:
        """Get total count of invoices with filter."""
        from sqlalchemy import func
        
        stmt = select(func.count(DBInvoice.invoice_id))
        
        # Apply filters
        if query:
            stmt = stmt.where(
                (DBInvoice.invoice_number.ilike(f"%{query}%")) |
                (DBInvoice.store_name.ilike(f"%{query}%")) |
                (DBInvoice.store_address.ilike(f"%{query}%"))
            )
        
        if status:
            stmt = stmt.where(DBInvoice.status == status)
        
        result = await db.execute(stmt)
        return result.scalar() or 0
    
    @staticmethod
    async def extract_invoice_data(
        db: AsyncSession,
        file_path: str,
        uploaded_by: int,
        original_filename: str
    ) -> Dict[str, Any]:
        """Extract invoice data using DocUNet and PaddleOCR."""
        from datetime import datetime
        import json
        import os
        from pathlib import Path
        
        logger.info(f"🔍 Service: Starting invoice extraction for {original_filename}")
        
        try:
            # Create invoice record first
            db_invoice = DBInvoice(
                upload_time=datetime.now(),
                uploaded_by=uploaded_by,
                status="processing",
                invoice_number=f"INV_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                store_name="Processing...",
                store_address="Processing...",
                total_amount=0.0
            )
            
            db.add(db_invoice)
            await db.commit()
            # Không refresh để tránh lỗi SQLite
            
            invoice_id = db_invoice.invoice_id
            logger.info(f"📝 Service: Created invoice record {invoice_id}")
            
            # Log processing start
            await InvoiceService.add_log(
                db=db,
                invoice_id=invoice_id,
                step="extraction_start",
                message=f"Started processing {original_filename}",
                status="info"
            )
            
            # Process with DocUNet (real implementation)
            await InvoiceService.add_log(
                db=db,
                invoice_id=invoice_id,
                step="docunet_processing",
                message="Starting DocUNet processing",
                status="info"
            )
            
            docunet_result = await InvoiceService._process_with_docunet(file_path)
            
            if docunet_result.get("status") == "error":
                logger.warning(f"⚠️ DocUNet processing failed: {docunet_result.get('error')}")
                await InvoiceService.add_log(
                    db=db,
                    invoice_id=invoice_id,
                    step="docunet_processing",
                    message=f"DocUNet failed: {docunet_result.get('message', 'Unknown error')}",
                    status="warning"
                )
            else:
                logger.info(f"🤖 Service: DocUNet processing completed successfully")
                await InvoiceService.add_log(
                    db=db,
                    invoice_id=invoice_id,
                    step="docunet_processing",
                    message=f"DocUNet completed: {docunet_result.get('total_regions', 0)} regions detected",
                    status="success"
                )
            
            # Process with PaddleOCR (real implementation)
            await InvoiceService.add_log(
                db=db,
                invoice_id=invoice_id,
                step="paddle_ocr_processing",
                message="Starting PaddleOCR processing",
                status="info"
            )
            
            paddle_result = await InvoiceService._process_with_paddle_ocr(file_path)
            
            if paddle_result.get("status") == "error":
                logger.warning(f"⚠️ PaddleOCR processing failed: {paddle_result.get('error')}")
                await InvoiceService.add_log(
                    db=db,
                    invoice_id=invoice_id,
                    step="paddle_ocr_processing",
                    message=f"PaddleOCR failed: {paddle_result.get('message', 'Unknown error')}",
                    status="warning"
                )
            else:
                logger.info(f"🔍 Service: PaddleOCR processing completed successfully")
                await InvoiceService.add_log(
                    db=db,
                    invoice_id=invoice_id,
                    step="paddle_ocr_processing",
                    message=f"PaddleOCR completed: {paddle_result.get('total_lines', 0)} text lines extracted",
                    status="success"
                )
            
            # Parse and extract structured data using schema parser
            await InvoiceService.add_log(
                db=db,
                invoice_id=invoice_id,
                step="schema_parsing",
                message="Starting schema-based parsing",
                status="info"
            )
            
            extracted_data = await InvoiceService._parse_extraction_results(
                docunet_result, paddle_result
            )
            
            if extracted_data.get("status") == "fallback":
                logger.warning(f"⚠️ Schema parsing used fallback: {extracted_data.get('error')}")
                await InvoiceService.add_log(
                    db=db,
                    invoice_id=invoice_id,
                    step="schema_parsing",
                    message=f"Fallback parsing used: {extracted_data.get('message', 'Unknown error')}",
                    status="warning"
                )
            else:
                logger.info(f"📊 Service: Schema parsing completed successfully")
                await InvoiceService.add_log(
                    db=db,
                    invoice_id=invoice_id,
                    step="schema_parsing",
                    message=f"Parsing completed: {extracted_data.get('total_items', 0)} items extracted with {extracted_data.get('parsing_confidence', 0):.2f} confidence",
                    status="success"
                )
            
            # Update invoice with extracted data
            db_invoice.invoice_date = extracted_data.get("invoice_date")
            db_invoice.processed_time = datetime.now()
            db_invoice.invoice_number = extracted_data.get("invoice_number", db_invoice.invoice_number)
            db_invoice.store_name = extracted_data.get("store_name", "Unknown Store")
            db_invoice.store_address = extracted_data.get("store_address", "Unknown Address")
            db_invoice.total_amount = extracted_data.get("total_amount", 0.0)
            
            # Set status based on processing results
            if extracted_data.get("status") == "fallback":
                db_invoice.status = "completed_with_warnings"
            elif docunet_result.get("status") == "error" and paddle_result.get("status") == "error":
                db_invoice.status = "completed_with_errors"
            else:
                db_invoice.status = "completed"
            
            # Add invoice items
            items_data = extracted_data.get("items", [])
            for item_data in items_data:
                db_item = DBInvoiceItem(
                    invoice_id=invoice_id,
                    product_name=item_data.get("product_name", "Unknown Product"),
                    quantity=item_data.get("quantity", 1),
                    unit_price=item_data.get("unit_price", 0.0),
                    total_price=item_data.get("total_price", 0.0)
                )
                db.add(db_item)
            
            await db.commit()
            # Không refresh để tránh lỗi SQLite
            
            # Log completion
            await InvoiceService.add_log(
                db=db,
                invoice_id=invoice_id,
                step="extraction_complete",
                message=f"Successfully extracted {len(items_data)} items",
                status="success"
            )
            
            logger.info(f"✅ Service: Invoice extraction completed for {invoice_id}")
            
            # Return structured result
            return {
                "invoice_id": invoice_id,
                "invoice_number": db_invoice.invoice_number,
                "invoice_date": db_invoice.invoice_date.isoformat() if db_invoice.invoice_date else None,
                "store_name": db_invoice.store_name,
                "store_address": db_invoice.store_address,
                "tax_id": extracted_data.get("tax_id", ""),
                "total_amount": float(db_invoice.total_amount),
                "subtotal": float(extracted_data.get("subtotal", 0.0)),
                "tax_amount": float(extracted_data.get("tax_amount", 0.0)),
                "discount": float(extracted_data.get("discount", 0.0)),
                "status": db_invoice.status,
                "upload_time": db_invoice.upload_time.isoformat(),
                "processed_time": db_invoice.processed_time.isoformat() if db_invoice.processed_time else None,
                "items": [
                    {
                        "product_name": item.get("product_name"),
                        "quantity": item.get("quantity"),
                        "unit_price": float(item.get("unit_price", 0)),
                        "total_price": float(item.get("total_price", 0))
                    } for item in items_data
                ],
                "processing_info": {
                    "docunet_status": docunet_result.get("status", "unknown"),
                    "docunet_processing_time": docunet_result.get("processing_time", 0.0),
                    "paddle_status": paddle_result.get("status", "unknown"),
                    "paddle_processing_time": paddle_result.get("processing_time", 0.0),
                    "parsing_status": extracted_data.get("status", "unknown"),
                    "parsing_confidence": extracted_data.get("parsing_confidence", 0.0),
                    "total_items_extracted": extracted_data.get("total_items", 0),
                    "original_filename": original_filename,
                    "model_versions": {
                        "docunet": docunet_result.get("model_version", "unknown"),
                        "paddle_ocr": paddle_result.get("model_version", "unknown")
                    }
                },
                "raw_results": {
                    "docunet_regions": docunet_result.get("total_regions", 0),
                    "paddle_text_lines": paddle_result.get("total_lines", 0),
                    "schema_parsed_data": extracted_data.get("raw_parsed_result", {})
                }
            }
            
        except Exception as e:
            logger.error(f"❌ Service: Invoice extraction failed: {e}")
            
            # Update status to failed if invoice was created
            if 'invoice_id' in locals():
                try:
                    db_invoice.status = "failed"
                    await db.commit()
                    
                    await InvoiceService.add_log(
                        db=db,
                        invoice_id=invoice_id,
                        step="extraction_error",
                        message=f"Extraction failed: {str(e)}",
                        status="error"
                    )
                except:
                    pass
            
            raise e
    
    @staticmethod
    async def _process_with_docunet(file_path: str) -> Dict[str, Any]:
        """Process image with DocUNet using model_manager."""
        import time
        from pathlib import Path
        from PIL import Image
        
        start_time = time.time()
        
        try:
            # Import model manager
            from .model_manager import model_manager
            
            # Get preloaded DocUNet predictor
            predictor = model_manager.get_docunet_predictor()
            if predictor is None:
                logger.warning("DocUNet model not loaded, using resized image only")
                # Fallback: just resize image to 512x512
                input_path = Path(file_path)
                output_path = input_path.parent / f"{input_path.stem}_512.jpg"
                
                # Resize image
                with Image.open(file_path) as img:
                    resized_img = img.resize((512, 512), Image.Resampling.LANCZOS)
                    resized_img.save(output_path, "JPEG", quality=95)
                
                processing_time = time.time() - start_time
                return {
                    "status": "fallback_resize",
                    "output_path": str(output_path),
                    "processing_time": processing_time,
                    "model_version": "resize_only",
                    "message": "DocUNet not available, used resize fallback"
                }
            
            # Process with DocUNet
            input_path = Path(file_path)
            resized_path = input_path.parent / f"{input_path.stem}_512.jpg"
            output_path = input_path.parent / f"{input_path.stem}_docunet.jpg"
            
            # Step 1: Resize to 512x512
            with Image.open(file_path) as img:
                resized_img = img.resize((512, 512), Image.Resampling.LANCZOS)
                resized_img.save(resized_path, "JPEG", quality=95)
            
            # Step 2: DocUNet prediction
            predictor.predict_single_image(str(resized_path), str(output_path))
            
            processing_time = time.time() - start_time
            
            return {
                "status": "success",
                "output_path": str(output_path),
                "resized_path": str(resized_path),
                "processing_time": processing_time,
                "model_version": "docunet_v1.0",
                "message": "DocUNet processing completed successfully"
            }
            
        except Exception as e:
            logger.error(f"DocUNet processing failed: {e}")
            # Fallback: just resize image
            try:
                input_path = Path(file_path)
                output_path = input_path.parent / f"{input_path.stem}_512.jpg"
                
                with Image.open(file_path) as img:
                    resized_img = img.resize((512, 512), Image.Resampling.LANCZOS)
                    resized_img.save(output_path, "JPEG", quality=95)
                
                processing_time = time.time() - start_time
                return {
                    "status": "error_fallback",
                    "output_path": str(output_path),
                    "processing_time": processing_time,
                    "model_version": "resize_fallback",
                    "error": str(e),
                    "message": "DocUNet failed, used resize fallback"
                }
            except Exception as fallback_error:
                raise RuntimeError(f"Both DocUNet and fallback failed: {e}, {fallback_error}")
    
    @staticmethod
    async def _process_with_paddle_ocr(file_path: str) -> Dict[str, Any]:
        """Process image with PaddleOCR using model_manager."""
        import time
        from pathlib import Path
        
        start_time = time.time()
        
        try:
            # Import model manager
            from .model_manager import model_manager
            
            # Get preloaded PaddleOCR engine
            ocr_engine = model_manager.get_paddle_ocr()
            if ocr_engine is None:
                raise RuntimeError("PaddleOCR model not loaded. Please ensure models are preloaded during server startup.")
            
            # Process with PaddleOCR
            result = ocr_engine.predict(file_path)
            
            # Convert result to standardized format
            text_lines = []
            if result and len(result) > 0:
                for line_result in result[0]:  # result[0] contains the OCR results for the image
                    if len(line_result) >= 2:
                        bbox = line_result[0]  # Bounding box coordinates
                        text_info = line_result[1]  # (text, confidence)
                        
                        if isinstance(text_info, tuple) and len(text_info) >= 2:
                            text = text_info[0]
                            confidence = text_info[1]
                        else:
                            text = str(text_info)
                            confidence = 0.0
                        
                        # Flatten bbox coordinates if needed
                        if isinstance(bbox, list) and len(bbox) == 4 and isinstance(bbox[0], list):
                            # Convert [[x1,y1], [x2,y2], [x3,y3], [x4,y4]] to [x1,y1,x2,y2]
                            flat_bbox = [bbox[0][0], bbox[0][1], bbox[2][0], bbox[2][1]]
                        else:
                            flat_bbox = bbox
                        
                        text_lines.append({
                            "text": text,
                            "bbox": flat_bbox,
                            "confidence": float(confidence)
                        })
            
            processing_time = time.time() - start_time
            
            # Save results to staging directory
            output_dir = Path("data/staging/model_result")
            output_dir.mkdir(parents=True, exist_ok=True)
            
            # Save results using OCR engine's save method
            try:
                ocr_engine.save_results(result, str(output_dir))
            except Exception as save_error:
                logger.warning(f"Failed to save OCR results: {save_error}")
            
            return {
                "status": "success",
                "text_lines": text_lines,
                "raw_result": result,
                "result_path": str(output_dir),
                "processing_time": processing_time,
                "model_version": "paddleocr_v2.6",
                "total_lines": len(text_lines),
                "message": "PaddleOCR processing completed successfully"
            }
            
        except Exception as e:
            logger.error(f"PaddleOCR processing failed: {e}")
            processing_time = time.time() - start_time
            
            return {
                "status": "error",
                "text_lines": [],
                "raw_result": None,
                "result_path": None,
                "processing_time": processing_time,
                "model_version": "paddleocr_v2.6",
                "total_lines": 0,
                "error": str(e),
                "message": f"PaddleOCR processing failed: {e}"
            }
    
    @staticmethod
    async def _parse_extraction_results(
        docunet_result: Dict[str, Any],
        paddle_result: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Parse and combine results from DocUNet and PaddleOCR using schema parser."""
        from datetime import date
        import re
        from .schema_parser import RapidFuzzParser
        from .info_extractor import InvoiceLineGrouper
        
        try:
            # Initialize schema parser
            parser = RapidFuzzParser()
            
            # Combine text from both sources for comprehensive parsing
            all_text_lines = []
            
            # Add DocUNet detected regions as text lines
            for region in docunet_result.get("detected_regions", []):
                all_text_lines.append({
                    "text": region.get("text", ""),
                    "bbox": region.get("bbox", [0, 0, 0, 0]),
                    "confidence": region.get("confidence", 0.0),
                    "source": "docunet",
                    "type": region.get("type", "unknown")
                })
            
            # Add PaddleOCR text lines
            for line in paddle_result.get("text_lines", []):
                all_text_lines.append({
                    "text": line.get("text", ""),
                    "bbox": line.get("bbox", [0, 0, 0, 0]),
                    "confidence": line.get("confidence", 0.0),
                    "source": "paddle_ocr",
                    "type": "text"
                })
            
            # Parse with schema parser
            parsed_result = parser.parse(all_text_lines)
            
            # Extract store information using schema parser
            store_info = {}
            if hasattr(parser, 'detect_store_info'):
                store_info = parser.detect_store_info(all_text_lines)
            
            # Use InvoiceLineGrouper for item extraction
            grouper = InvoiceLineGrouper()
            grouped_items = grouper.group_invoice_lines(all_text_lines)
            
            # Process grouped items into structured format
            items = []
            for item_group in grouped_items:
                try:
                    # Extract product information from grouped lines
                    product_name = item_group.get("product_name", "Unknown Product")
                    quantity = item_group.get("quantity", 1)
                    unit_price = item_group.get("unit_price", 0.0)
                    total_price = item_group.get("total_price", quantity * unit_price)
                    
                    # Validate and clean data
                    if isinstance(quantity, str):
                        quantity = int(re.sub(r'[^\d]', '', quantity) or '1')
                    if isinstance(unit_price, str):
                        unit_price = float(re.sub(r'[^\d.,]', '', unit_price.replace(',', '.')) or '0')
                    if isinstance(total_price, str):
                        total_price = float(re.sub(r'[^\d.,]', '', total_price.replace(',', '.')) or '0')
                    
                    items.append({
                        "product_name": product_name.strip(),
                        "quantity": max(1, int(quantity)),
                        "unit_price": max(0.0, float(unit_price)),
                        "total_price": max(0.0, float(total_price))
                    })
                except (ValueError, TypeError) as e:
                    logger.warning(f"Failed to process item group: {e}")
                    continue
            
            # Extract key information from parsed result
            invoice_date = parsed_result.get("date")
            if not invoice_date:
                # Try to extract date from text
                date_text = parser.extract_date(all_text_lines)
                if date_text:
                    try:
                        # Parse Vietnamese date formats
                        import datetime
                        for fmt in ["%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d", "%d.%m.%Y"]:
                            try:
                                invoice_date = datetime.datetime.strptime(date_text, fmt).date()
                                break
                            except ValueError:
                                continue
                    except Exception:
                        invoice_date = date.today()
                else:
                    invoice_date = date.today()
            
            # Extract invoice number
            invoice_number = parsed_result.get("invoice_number")
            if not invoice_number:
                invoice_number = parser.extract_invoice_number(all_text_lines)
            if not invoice_number:
                invoice_number = f"HD{date.today().strftime('%Y%m%d')}"
            
            # Extract store information
            store_name = store_info.get("store_name") or parsed_result.get("store_name", "Unknown Store")
            store_address = store_info.get("store_address") or parsed_result.get("store_address", "Unknown Address")
            tax_id = store_info.get("tax_id") or parsed_result.get("tax_id", "")
            
            # Extract financial information
            total_amount = parsed_result.get("total", 0.0)
            subtotal = parsed_result.get("subtotal", 0.0)
            tax_amount = parsed_result.get("tax", 0.0)
            discount = parsed_result.get("discount", 0.0)
            
            # If total not found, calculate from items
            if total_amount == 0.0 and items:
                total_amount = sum(item["total_price"] for item in items)
            
            # If subtotal not found, use total minus tax
            if subtotal == 0.0:
                subtotal = total_amount - tax_amount
            
            return {
                "status": "success",
                "invoice_date": invoice_date,
                "invoice_number": invoice_number,
                "store_name": store_name,
                "store_address": store_address,
                "tax_id": tax_id,
                "total_amount": float(total_amount),
                "subtotal": float(subtotal),
                "tax_amount": float(tax_amount),
                "discount": float(discount),
                "items": items,
                "raw_parsed_result": parsed_result,
                "total_items": len(items),
                "parsing_confidence": sum(line.get("confidence", 0) for line in all_text_lines) / len(all_text_lines) if all_text_lines else 0.0,
                "message": "Invoice parsing completed successfully"
            }
            
        except Exception as e:
            logger.error(f"Schema parsing failed: {e}")
            
            # Fallback to basic parsing
            items = []
            text_lines = paddle_result.get("text_lines", [])
            
            for line in text_lines:
                text = line["text"].strip()
                if re.search(r'\d+', text) and len(text) > 3:
                    numbers = re.findall(r'[\d,]+', text)
                    if len(numbers) >= 2:
                        try:
                            quantity = int(numbers[0].replace(',', ''))
                            unit_price = float(numbers[1].replace(',', ''))
                            total_price = quantity * unit_price if len(numbers) == 2 else float(numbers[2].replace(',', ''))
                            
                            product_name = re.sub(r'[\d,\s]+$', '', text).strip()
                            if product_name:
                                items.append({
                                    "product_name": product_name,
                                    "quantity": quantity,
                                    "unit_price": unit_price,
                                    "total_price": total_price
                                })
                        except (ValueError, IndexError):
                            continue
            
            total_amount = sum(item["total_price"] for item in items)
            
            return {
                "status": "fallback",
                "invoice_date": date.today(),
                "invoice_number": f"HD{date.today().strftime('%Y%m%d')}",
                "store_name": "Unknown Store",
                "store_address": "Unknown Address",
                "tax_id": "",
                "total_amount": float(total_amount),
                "subtotal": float(total_amount),
                "tax_amount": 0.0,
                "discount": 0.0,
                "items": items,
                "raw_parsed_result": {},
                "total_items": len(items),
                "parsing_confidence": 0.0,
                "error": str(e),
                "message": f"Fallback parsing used due to error: {e}"
            }


class UserService:
    """Service class for user-related business operations."""
    
    @staticmethod
    async def get_user_by_id(db: AsyncSession, user_id: int) -> Optional[User]:
        """Get user by ID."""
        result = await db.execute(select(DBUser).where(DBUser.user_id == user_id))
        db_user = result.scalar_one_or_none()
        
        if not db_user:
            return None
            
        return User(
            user_id=db_user.user_id,
            username=db_user.username,
            email=db_user.email,
            full_name=db_user.full_name,
            password_hash=db_user.password_hash,
            role=db_user.role,
            created_at=db_user.created_at
        )

    # ========== TRANSACTION-SAFE VERSIONS (No Auto-Commit) ==========
    
    @staticmethod
    async def add_invoice_log_no_commit(
        db: AsyncSession,
        invoice_id: int,
        message: str,
        step: str,
        status: str = "info"
    ) -> DBInvoiceLog:
        """Add a log entry for an invoice without committing."""
        db_log = DBInvoiceLog(
            invoice_id=invoice_id,
            message=message,
            step=step,
            status=status
        )
        
        db.add(db_log)
        # No commit here - caller will handle transaction
        return db_log
    
    @staticmethod
    async def update_invoice_status_no_commit(db: AsyncSession, invoice_id: int, status: str) -> bool:
        """Update invoice status without committing."""
        result = await db.execute(select(DBInvoice).where(DBInvoice.invoice_id == invoice_id))
        db_invoice = result.scalar_one_or_none()
        
        if not db_invoice:
            return False
            
        db_invoice.status = status
        # No commit here - caller will handle transaction
        return True
    
    @staticmethod
    async def update_invoice_info_no_commit(db: AsyncSession, invoice_id: int, update_data: Dict[str, Any]) -> bool:
        """Update invoice information without committing."""
        result = await db.execute(select(DBInvoice).where(DBInvoice.invoice_id == invoice_id))
        db_invoice = result.scalar_one_or_none()
        
        if not db_invoice:
            return False
        
        # Update fields
        for field, value in update_data.items():
            if hasattr(db_invoice, field):
                setattr(db_invoice, field, value)
        
        # No commit here - caller will handle transaction
        return True
    
    @staticmethod
    async def add_invoice_item_no_commit(
        db: AsyncSession,
        invoice_id: int,
        product_name: str,
        quantity: int = 1,
        unit_price: float = 0.0,
        total_price: float = 0.0
    ) -> DBInvoiceItem:
        """Add an item to an invoice without committing."""
        db_item = DBInvoiceItem(
            invoice_id=invoice_id,
            product_name=product_name,
            quantity=quantity,
            unit_price=unit_price,
            total_price=total_price
        )
        
        db.add(db_item)
        # No commit here - caller will handle transaction
        return db_item
    
    @staticmethod
    async def get_user_by_email(db: AsyncSession, email: str) -> Optional[User]:
        """Get user by email."""
        result = await db.execute(select(DBUser).where(DBUser.email == email))
        db_user = result.scalar_one_or_none()
        
        if not db_user:
            return None
            
        return User(
            user_id=db_user.user_id,
            username=db_user.username,
            email=db_user.email,
            full_name=db_user.full_name,
            password_hash=db_user.password_hash,
            role=db_user.role,
            created_at=db_user.created_at
        )
    
    @staticmethod
    async def create_user(
        db: AsyncSession,
        username: str,
        email: str,
        password: str,
        role: str = "user",
        full_name: Optional[str] = None
    ) -> User:
        """Create a new user."""
        import hashlib
        from datetime import datetime
        
        # Hash password
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        
        # Create new user
        db_user = DBUser(
            username=username,
            email=email,
            password_hash=password_hash,
            role=role,
            full_name=full_name,
            is_active=True,
            created_at=datetime.now(),
            updated_at=datetime.now()
        )
        
        db.add(db_user)
        await db.commit()
        # Không refresh để tránh lỗi SQLite
        
        return User(
            user_id=db_user.user_id or 0,  # Fallback nếu chưa có ID
            username=db_user.username,
            email=db_user.email,
            full_name=db_user.full_name,
            password_hash=db_user.password_hash,
            role=db_user.role,
            created_at=db_user.created_at or datetime.now()  # Fallback nếu chưa có time
        )
    
    @staticmethod
    async def get_user_by_username(db: AsyncSession, username: str) -> Optional[User]:
        """Get user by username."""
        result = await db.execute(select(DBUser).where(DBUser.username == username))
        db_user = result.scalar_one_or_none()
        
        if not db_user:
            return None
            
        return User(
            user_id=db_user.user_id,
            username=db_user.username,
            email=db_user.email,
            full_name=db_user.full_name,
            password_hash=db_user.password_hash,
            role=db_user.role,
            created_at=db_user.created_at
        )