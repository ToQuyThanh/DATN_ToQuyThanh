#!/usr/bin/env python3
"""
Script to initialize database and create a test user
"""
import sys
import os
import asyncio
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from backend_invoice.database import get_sync_db, init_database, SessionLocal
from backend_invoice.db_models import User
from sqlalchemy.orm import Session
import hashlib

async def create_test_user():
    """Create a test user in the database"""
    # Initialize database first
    await init_database()
    
    # Get database session
    db = SessionLocal()
    
    try:
        # Check if user already exists
        existing_user = db.query(User).filter(User.username == "testuser").first()
        if existing_user:
            print(f"User already exists: ID={existing_user.user_id}, Username={existing_user.username}")
            return existing_user
        
        # Create new user
        password_hash = hashlib.sha256("testpassword".encode()).hexdigest()
        test_user = User(
            username="testuser",
            email="test@example.com", 
            full_name="Test User",
            password_hash=password_hash
        )
        
        db.add(test_user)
        db.commit()
        db.refresh(test_user)
        
        print(f"Test user created successfully!")
        print(f"User ID: {test_user.user_id}")
        print(f"Username: {test_user.username}")
        print(f"Email: {test_user.email}")
        print(f"Full Name: {test_user.full_name}")
        
        return test_user
        
    except Exception as e:
        print(f"Error creating test user: {e}")
        db.rollback()
        return None
    finally:
        db.close()

if __name__ == "__main__":
    asyncio.run(create_test_user())