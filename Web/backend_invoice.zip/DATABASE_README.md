# 🗄️ Database Setup Guide

## Tổng quan

Dự án sử dụng **SQLite** làm database với **SQLAlchemy** ORM và hỗ trợ async operations.

## 📋 Database Schema

### 🔹 Bảng `users`
- `user_id` (INTEGER, PRIMARY KEY) - ID người dùng
- `created_at` (DATETIME) - Thời gian tạo
- `username` (VARCHAR(50), UNIQUE) - Tên đăng nhập
- `full_name` (VARCHAR(100)) - Họ tên đầy đủ
- `email` (VARCHAR(100), UNIQUE) - Email
- `password_hash` (VARCHAR(255)) - Mật khẩu đã hash
- `role` (VARCHAR(20)) - Vai trò (admin/user)

### 🔹 Bảng `invoices`
- `invoice_id` (INTEGER, PRIMARY KEY) - ID hóa đơn
- `invoice_date` (DATE) - Ngày hóa đơn
- `upload_time` (DATETIME) - Thời gian upload
- `processed_time` (DATETIME) - Thời gian xử lý
- `uploaded_by` (INTEGER, FK) - Người upload
- `invoice_number` (VARCHAR(50)) - Số hóa đơn
- `store_name` (VARCHAR(200)) - Tên cửa hàng
- `store_address` (TEXT) - Địa chỉ cửa hàng
- `total_amount` (DECIMAL(15,2)) - Tổng tiền
- `status` (VARCHAR(20)) - Trạng thái
- `original_file_name` (VARCHAR(255)) - Tên file gốc
- `file_type` (VARCHAR(10)) - Loại file

### 🔹 Bảng `invoice_items`
- `item_id` (INTEGER, PRIMARY KEY) - ID sản phẩm
- `invoice_id` (INTEGER, FK) - ID hóa đơn
- `product_name` (VARCHAR(200)) - Tên sản phẩm
- `quantity` (INTEGER) - Số lượng
- `unit_price` (DECIMAL(15,2)) - Đơn giá
- `total_price` (DECIMAL(15,2)) - Thành tiền

### 🔹 Bảng `invoice_logs`
- `log_id` (INTEGER, PRIMARY KEY) - ID log
- `invoice_id` (INTEGER, FK) - ID hóa đơn
- `log_time` (DATETIME) - Thời gian log
- `message` (TEXT) - Nội dung log
- `step` (VARCHAR(50)) - Bước xử lý
- `status` (VARCHAR(20)) - Trạng thái

## 🚀 Khởi tạo Database

### 1. Cài đặt dependencies
```bash
uv add sqlalchemy aiosqlite
```

### 2. Khởi tạo database và tạo tables
```bash
# Sử dụng SQLAlchemy (khuyến nghị)
uv run python scripts/init_database.py

# Hoặc sử dụng SQL script trực tiếp
uv run python scripts/init_database.py --sql-only
```

### 3. Khởi tạo không có sample data
```bash
uv run python scripts/init_database.py --no-sample-data
```

## 🔧 Cấu hình Database

### Environment Variables
Tạo file `.env` từ `.env.example`:

```env
# Database Configuration
DATABASE_URL=sqlite:///./invoices.db
ASYNC_DATABASE_URL=sqlite+aiosqlite:///./invoices.db
DATABASE_ECHO=false
```

### Database Files
- **Database file**: `invoices.db` (tự động tạo)
- **Configuration**: `src/backend_invoice/database.py`
- **Models**: `src/backend_invoice/db_models.py`
- **SQL Scripts**: `scripts/create_tables.sql`

## 📊 Quản lý Database

### Kiểm tra database
```bash
# Xem danh sách tables
sqlite3 invoices.db ".tables"

# Xem cấu trúc table
sqlite3 invoices.db ".schema users"

# Xem dữ liệu
sqlite3 invoices.db "SELECT * FROM users;"
```

### Backup database
```bash
# Backup
sqlite3 invoices.db ".backup backup_invoices.db"

# Restore
sqlite3 new_invoices.db ".restore backup_invoices.db"
```

## 🔍 Health Check

API cung cấp health check endpoint để kiểm tra database:

```bash
curl http://localhost:8000/health
```

Response:
```json
{
  "status": "healthy",
  "database": {
    "status": "healthy",
    "database": "connected"
  },
  "timestamp": "2025-10-01T11:47:20.123456",
  "version": "1.0.0"
}
```

## 🧪 Testing

### Chạy tests với database
```bash
# Chạy tất cả tests
uv run pytest tests/ -v

# Chạy tests với coverage
uv run pytest tests/ --cov=src/backend_invoice --cov-report=html
```

## 📁 File Structure

```
backend_invoice/
├── src/backend_invoice/
│   ├── database.py          # Database configuration
│   ├── db_models.py         # SQLAlchemy models
│   ├── models.py            # Pydantic models
│   └── api.py               # FastAPI endpoints
├── scripts/
│   ├── init_database.py     # Database initialization
│   └── create_tables.sql    # SQL schema
├── invoices.db              # SQLite database file
└── .env                     # Environment configuration
```

## 🔐 Sample Users

Database được khởi tạo với 2 users mẫu:

| Username | Password | Role  | Email |
|----------|----------|-------|-------|
| admin    | admin123 | admin | admin@invoiceapp.com |
| user1    | user123  | user  | user1@example.com |

> ⚠️ **Lưu ý**: Đổi mật khẩu mặc định trong production!

## 🚨 Troubleshooting

### Lỗi thường gặp

1. **Database locked**
   ```bash
   # Đóng tất cả connections
   sqlite3 invoices.db ".quit"
   ```

2. **Permission denied**
   ```bash
   # Kiểm tra quyền file
   ls -la invoices.db
   ```

3. **Table already exists**
   ```bash
   # Xóa database và tạo lại
   rm invoices.db
   uv run python scripts/init_database.py
   ```

## 📚 Tài liệu tham khảo

- [SQLAlchemy Documentation](https://docs.sqlalchemy.org/)
- [SQLite Documentation](https://www.sqlite.org/docs.html)
- [FastAPI Database Tutorial](https://fastapi.tiangolo.com/tutorial/sql-databases/)
- [Pydantic Documentation](https://docs.pydantic.dev/)