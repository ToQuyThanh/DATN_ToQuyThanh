#!/usr/bin/env python3
"""
Quick start script for development
Script khởi động nhanh cho development
"""

import subprocess
import sys
from pathlib import Path

def main():
    """Khởi động server development một cách nhanh chóng"""
    project_root = Path(__file__).parent
    dev_script = project_root / "scripts" / "dev.py"
    
    print("🚀 Starting development server...")
    print("📁 Project root:", project_root)
    
    try:
        # Chạy script dev
        subprocess.run([sys.executable, str(dev_script)], cwd=project_root)
    except KeyboardInterrupt:
        print("\n👋 Development server stopped")
    except Exception as e:
        print(f"❌ Error starting development server: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()