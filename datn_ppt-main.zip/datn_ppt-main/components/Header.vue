<template>
  <div class="absolute top-0 left-0 right-0 px-6 bg-blue pt-2 pb-0">
    <h1 class="text-xl font-bold  !text-white tracking-wide">
      {{ title }}
    </h1>
  </div>
</template>

<script setup>
defineProps({
  title: {
    type: String,
    required: true,
  },
})
</script>
