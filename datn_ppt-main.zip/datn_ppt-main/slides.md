---
theme: seriph
class: 'text-center'
info: |
  ## ML project Slidev
  Phát triển mô hình DocUNET tích hợp PaddleOCR trong việc xây dựng ứng dụng trích xuất thông tin hóa đơn.
transition: slide-left
title: ML project - OCR
mdc: true
fonts:
  sans: 'Inter'
  serif: 'Inter'
  mono: 'JetBrains Mono'
layout: cover
background: './statics/image.png'
---
<!-- Header -->
<div class="absolute top-6 left-6 right-6 flex flex-col items-start">
  <div class="flex items-center mb-1">
    <img src="./statics/logo_haui.png" alt="HAUI Logo" class="h-10 w-10 mr-3">
    <div class="text-left">
      <div class="text-gray-100 font-bold text-sm">TRƯỜNG ĐẠI HỌC CÔNG NGHIỆP HÀ NỘI</div>
      <div class="text-gray-200 text-xs">Khoa Công Nghệ Thông Tin</div>
    </div>
  </div>
</div>

<!-- Main Content -->
<div class="flex flex-col justify-center h-full px-8 py-20">
  <div class="flex flex-col justify-center items-center h-full">
    <!-- Main Title -->
    <div class="mb-8">
      <h2 class="text-2xl md:text-2xl font-bold text-gray-50 mb-4 text-center">
        ĐỒ ÁN TỐT NGHIỆP
      </h2>
    </div>
    <!-- Subtitle / Tên đề tài -->
    <div class="mb-10">
      <p class="text-2xl md:text-3xl font-semibold text-white-100 leading-normal max-w-6xl mx-auto text-center" style="line-height: 1.5;">
        Phát triển mô hình DocUNET tích hợp PaddleOCR trong việc xây dựng ứng dụng trích xuất thông tin hóa đơn
      </p>
    </div>
      <!-- Student Info: Centered two-column layout -->
      <div class="grid grid-cols-2 max-w-xl mx-auto justify-items-center">
        <!-- Column 1: Labels -->
        <div class="flex flex-col space-y-1">
          <div class="bg-haui-yellow px-6 py-3 flex items-center">
            <span class="text-gray-100 font-semibold text-base">Giảng viên hướng dẫn:</span>
          </div>
          <div class="bg-haui-yellow px-6 py-3 flex items-center">
            <span class="text-gray-100 font-semibold text-base">Sinh viên thực hiện:</span>
          </div>
          <div class="bg-haui-yellow px-6 py-3 flex items-center">
            <span class="text-gray-100 font-semibold text-base">Mã sinh viên:</span>
          </div>
        </div>
        <!-- Column 2: Values -->
        <div class="flex flex-col space-y-1">
          <div class="bg-haui-yellow px-6 py-3 flex items-center">
            <span class="text-gray-100 text-base">ThS. Phạm Việt Anh</span>
          </div>
          <div class="bg-haui-yellow px-6 py-3 flex items-center">
            <span class="text-gray-100 text-base">Tô Quý Thành</span>
          </div>
          <div class="bg-haui-yellow px-6 py-3 flex items-center">
            <span class="text-gray-100 text-base">2021604803</span>
          </div>
        </div>
    </div>
  </div>
</div>

---
src: ./pages/addition_content/table_of_content.md
---

---
src: ./pages/addition_content/introduction.md
---

---
src: ./pages/addition_content/ly_thuyet.md
---

---
src: ./pages/ml/overview_pipeline.md
---


---
src: ./pages/ml/docUnet.md
---
---
src: ./pages/ml/paddle.md
---

---
src: ./pages/ml/data_engineering.md
---


---
src: ./pages/ml/modeling.md
---

---
src: ./pages/ml/kq.md
---

---
src: ./pages/ml/compare.md
---


---
src: ./pages/ml/app.md
---

---
src: ./pages/ml/kl.md
---

---
src: ./pages/addition_content/resource.md
---
