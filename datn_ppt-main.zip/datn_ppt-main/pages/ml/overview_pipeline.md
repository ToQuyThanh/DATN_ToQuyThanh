---
layout: main_contents
---

<Header title="KIẾN TRÚC TỔNG THỂ HỆ THỐNG" />

<style>
.diagram-container {
  @apply flex justify-center items-center h-full p-16;
}

.diagram-image {
  @apply max-w-4xl max-h-xl object-contain rounded-lg shadow-sm;
}
</style>

<div class="diagram-container">
  <figure class="diagram-image">
    <img src="/statics/app_architecture.png" alt="Demo Input → Output"/>
    <figcaption class="text-center text-sm text-gray-600 mt-2">
      Hình 4: Kiến trúc tổng thể hệ thống
    </figcaption>
  </figure>
</div>

