---
layout: main_contents
---

<Header title="CÔNG NGHỆ DOCUNET" />

<style>
.docunet-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
}

.content-grid-proportional {
  display: grid;
  grid-template-columns: 1fr 2fr;
  gap: 2rem;
  align-items: start;
  min-height: 500px;
}

.architecture-section-compact {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 1.5rem;
  border-radius: 15px;
  box-shadow: 0 10px 30px rgba(0,0,0,0.2);
  height: fit-content;
}

.section-title {
  font-size: 1.3rem;
  font-weight: bold;
  margin-bottom: 1rem;
  text-align: center;
}


.feature-item-compact {
  background: rgba(255,255,255,0.1);
  padding: 0.8rem;
  border-radius: 8px;
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255,255,255,0.2);
  transition: all 0.3s ease;
  font-size: 0.9rem;
  line-height: 1.4;
}

.feature-item-compact:hover {
  background: rgba(255,255,255,0.2);
  transform: translateY(-2px);
}

.image-section-large {
  display: flex;
  align-items: center;
  justify-content: center;
  background: white;
  border-radius: 15px;
}

.architecture-figure {
  width: 100%;
  margin: 0;
}

.architecture-image {
  width: 100%;
  height: auto;
  border-radius: 10px;
  box-shadow: 0 5px 20px rgba(0,0,0,0.15);
}

.image-caption {
  text-align: center;
  font-size: 0.9rem;
  color: #666;
  margin-top: 1rem;
  font-style: italic;
}

@media (max-width: 768px) {
  .docunet-container {
    padding: 1rem;
  }
  
  .content-grid-proportional {
    grid-template-columns: 1fr;
    gap: 1rem;
  }
  
  .architecture-section-compact {
    order: 2;
  }
  
  .image-section-large {
    order: 1;
  }
}
</style>

<div class="docunet-container">
  <!-- Content Grid with 1/3 - 2/3 proportion -->
  <div class="content-grid-proportional">
    <!-- Architecture Section (1/3) -->
    <div class="architecture">
      <h3 class="section-title">Kiến trúc DocUnet với backbone TinyUnet</h3>
      <div class="feature-list">
        <div class="feature-item-compact">
          <strong>TinyUnet:</strong> Giảm 40% tham số so với Unet gốc, tối ưu hóa cho tốc độ xử lý
        </div>
        <div class="feature-item-compact">
          <strong>CMRF Module:</strong> Xử lý đa tỷ lệ (coarse-to-fine) để cải thiện độ chính xác
        </div>
        <div class="feature-item-compact">
          <strong>Loss Function:</strong> Kết hợp L1 Loss và Perceptual Loss cho kết quả tối ưu
        </div>
      </div>
    </div>
    <!-- Image Section (2/3) -->
    <div class="image-section-large">
      <figure class="architecture-figure">
        <img src="/statics/tinyunet.png" alt="TinyUnet Architecture" class="architecture-image" />
        <figcaption class="image-caption">
          Hình 5: TinyUnet backbone và CMRF module cho xử lý hình ảnh hóa đơn [1]
        </figcaption>
      </figure>
    </div>
  </div>
</div>
---
layout: main_contents
---
<Header title="CÔNG NGHỆ DOCUNET" />  

<!-- Architecture Image Section -->
<div class="image-section">
    <div class="text-center">
    <figure class="mt-3 max-w-3xl mx-auto">
        <img src="/statics/docunet.png" alt="Demo Input → Output" class="rounded border" />
        <figcaption class="text-center text-sm text-gray-600 mt-2">
        Hình 6: Kiến trúc DocUnet cho xử lý hình ảnh hóa đơn
        </figcaption>
        </figure>
    </div>
</div>