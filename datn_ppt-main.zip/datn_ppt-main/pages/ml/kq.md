---
layout: main_contents
---

<Header title="KẾT QUẢ THỰC NGHIỆM - TỔNG HỢP" />

<style>
.results-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 1rem;
  font-family: 'Times New Roman', serif;
}

.section-title {
  font-size: 1.4rem;
  font-weight: bold;
  color: #2c3e50;
  margin: 3rem 0 2rem 0;
  text-align: center;
  border-bottom: 2px solid #34495e;
  padding-bottom: 0.5rem;
}

.results-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 2rem;
  margin-bottom: 3rem;
}

.chart-container {
  background: white;
  border: 1px solid #dee2e6;
  border-radius: 8px;
  padding: 1rem;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.chart-title {
  font-size: 1.1rem;
  font-weight: bold;
  color: #495057;
  margin-bottom: 1rem;
  text-align: center;
}

.chart-image {
  width: 100%;
  height: auto;
  border-radius: 4px;
}

.chart-description {
  font-size: 0.9rem;
  color: #6c757d;
  margin-top: 1rem;
  line-height: 1.5;
  text-align: justify;
}

.single-chart {
  grid-column: 1 / -1;
  max-width: 800px;
  margin: 0 auto;
}

.metrics-summary {
  background: #f8f9fa;
  border: 1px solid #dee2e6;
  border-radius: 8px;
  padding: 2rem;
  margin: 2rem 0;
}

.summary-title {
  font-size: 1.2rem;
  font-weight: bold;
  color: #2c3e50;
  margin-bottom: 1rem;
  text-align: center;
}

.metrics-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
}

.metric-item {
  text-align: center;
  padding: 1rem;
  background: white;
  border-radius: 6px;
  border: 1px solid #e9ecef;
}

.metric-label {
  font-size: 0.9rem;
  color: #6c757d;
  margin-bottom: 0.5rem;
}

.metric-value {
  font-size: 1.3rem;
  font-weight: bold;
  color: #2c3e50;
}

@media (max-width: 768px) {
  .results-grid {
    grid-template-columns: 1fr;
  }
  
  .results-container {
    padding: 1rem;
  }
}
</style>
<div class="results-container">
  <div class="text-center">
    <div class="chart-container inline-block">
      <img src="/statics/SSIM_AD.png" alt="Average Distance Score" class="chart-image max-w-xl mx-auto" />
      <p class="text-center">Hình 11: Chỉ số Average Distance (AD) và chỉ số tương đồng cấu trúc (MS-SSIM) trên tập validation </p>
      <div class="chart-description">
        Chỉ số AD (Average Distance) giảm từ 0.9 xuống gần 0 sau 25 epochs, 
        cho thấy khoảng cách trung bình giữa ảnh dự đoán và ảnh ground truth được tối thiểu hóa hiệu quả. Chỉ số MS-SSIM đạt giá trị cao nhất ở epoch 25, đạt 0.98 cho thấy mô hình có khả năng dự đoán ảnh với độ tương đồng cao.
      </div>
    </div>
  </div>
</div>