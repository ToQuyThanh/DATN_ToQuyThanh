---
layout: main_contents
---

<Header title="SO SÁNH VỚI CÁC GIẢI PHÁP KHÁC" />

<style>
.academic-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 1.5rem;
  font-family: 'Times New Roman', serif;
  line-height: 1.6;
  color: #2c3e50;
}

.section-title {
  font-size: 1.4rem;
  font-weight: bold;
  color: #2c3e50;
  margin: 3rem 0 2rem 0;
  text-align: center;
  border-bottom: 2px solid #34495e;
  padding-bottom: 0.5rem;
}

.comparison-section {
  margin-bottom: 3rem;
}

.comparison-table {
  width: 100%;
  border-collapse: collapse;
  margin: 1.5rem 0;
  font-size: 0.95rem;
  background: white;
  border: 1px solid #dee2e6;
}

.comparison-table th {
  background: #f8f9fa;
  color: #495057;
  padding: 1rem 0.75rem;
  text-align: center;
  font-weight: bold;
  border: 1px solid #dee2e6;
}

.comparison-table td {
  padding: 0.75rem;
  text-align: center;
  border: 1px solid #dee2e6;
  vertical-align: middle;
}

.comparison-table tr:nth-child(even) {
  background-color: #f8f9fa;
}

.proposed-system {
  background: #e9ecef !important;
  font-weight: bold;
}

.advantages-section {
  margin: 2rem 0;
}

.advantages-list {
  list-style: none;
  padding: 0;
  margin: 1rem 0;
}

.advantages-list li {
  background: #f8f9fa;
  margin: 1rem 0;
  padding: 1.5rem;
  border: 1px solid #dee2e6;
  border-left: 4px solid #6c757d;
  font-size: 1rem;
}

.advantages-list li strong {
  color: #495057;
}

.analysis-section {
  background: #f8f9fa;
  border: 1px solid #dee2e6;
  padding: 2rem;
  margin: 2rem 0;
}

.analysis-title {
  font-size: 1.2rem;
  font-weight: bold;
  color: #2c3e50;
  margin-bottom: 1rem;
}

.analysis-content {
  font-size: 1rem;
  color: #495057;
  text-align: justify;
}

.conclusion-section {
  margin: 3rem 0;
  padding: 2rem;
  background: #f8f9fa;
  border: 1px solid #dee2e6;
}

.conclusion-title {
  font-size: 1.3rem;
  font-weight: bold;
  color: #2c3e50;
  margin-bottom: 1.5rem;
  text-align: center;
}

.conclusion-content {
  font-size: 1rem;
  color: #495057;
  text-align: justify;
  margin-bottom: 2rem;
}

.future-work-section {
  margin: 2rem 0;
  padding: 2rem;
  background: white;
  border: 1px solid #dee2e6;
}

.future-work-title {
  font-size: 1.2rem;
  font-weight: bold;
  color: #2c3e50;
  margin-bottom: 1rem;
}

.future-work-content {
  font-size: 1rem;
  color: #495057;
  text-align: justify;
}

.checkmark {
  color: #28a745;
  margin-right: 0.5rem;
}

.cross {
  color: #dc3545;
  margin-right: 0.5rem;
}

@media (max-width: 768px) {
  .academic-container {
    padding: 1rem;
  }
  
  .comparison-table {
    font-size: 0.85rem;
  }
  
  .comparison-table th,
  .comparison-table td {
    padding: 0.5rem 0.25rem;
  }
}
</style>

<div class="academic-container">
  
  <div class="section-title">
    Bảng 3: So sánh với các Giải pháp Hiện có
  </div>
  
  <div class="comparison-section">
    <table class="comparison-table">
      <thead>
        <tr>
          <th>Giải pháp</th>
          <th>Độ chính xác (%)</th>
          <th>Tốc độ xử lý</th>
          <th>Chi phí triển khai</th>
          <th>Khả năng tùy chỉnh</th>
        </tr>
      </thead>
      <tbody>
        <tr class="proposed-system">
          <td>Hệ thống đề xuất</td>
          <td>95.2</td>
          <td>2-3 giây</td>
          <td>Miễn phí</td>
          <td><span class="checkmark">✓</span>Cao</td>
        </tr>
        <tr>
          <td>Google Vision API</td>
          <td>95.5</td>
          <td>1-2 giây</td>
          <td>$1.5/1000 ảnh</td>
          <td><span class="cross">✗</span>Thấp</td>
        </tr>
        <tr>
          <td>Tesseract OCR</td>
          <td>80.0</td>
          <td>3-4 giây</td>
          <td>Miễn phí</td>
          <td><span class="checkmark">✓</span>Trung bình</td>
        </tr>
        <tr>
          <td>ABBYY FineReader</td>
          <td>98.0</td>
          <td>2-3 giây</td>
          <td>$399/năm</td>
          <td><span class="cross">✗</span>Thấp</td>
        </tr>
      </tbody>
    </table>
  </div>
</div>