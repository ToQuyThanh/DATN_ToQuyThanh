---
layout: main_contents
---


<Header title="Kết luận & Hướng phát triển" />

<style>
  .academic-container {
    max-width: 900px;
    margin: 0 auto;
    padding: 16px;
    font-family: "Times New Roman", serif;
    color: #222;
  }
  .section-title {
    font-size: 1.4rem;
    font-weight: 700;
    margin-bottom: 0.5rem;
    border-bottom: 1px solid #dee2e6;
    padding-bottom: 0.25rem;
  }
  .section-desc {
    font-size: 1rem;
    line-height: 1.8;
    text-align: justify;
    margin-bottom: 0.75rem;
  }
  .bullet-list {
    margin-top: 0.5rem;
    padding-left: 1.25rem;
  }
  .bullet-item {
    font-size: 1rem;
    line-height: 1.8;
    margin-bottom: 0.4rem;
  }
</style>

<div class="academic-container">
  <div class="section-title">Kết luận</div>
  <ul class="bullet-list">
    <li class="bullet-item">Hệ thống trích xuất và quản lý hóa đơn đã xây dựng thành công; kiểm thử xác nhận tích hợp và khả dụng thực tế.</li>
    <li class="bullet-item">DocUnet cải tiến học ổn định; SSIM > 0,90 sau 50 vòng; mô hình tối ưu tham số/kích thước nhưng vẫn giữ chất lượng.</li>
    <li class="bullet-item">Kết hợp PaddleOCR giúp hệ thống hoạt động ổn định, giảm sai sót trên hóa đơn đa kích thước/chất lượng.</li>
    <li class="bullet-item">Tiền xử lý ảnh tăng độ chính xác phát hiện và nhận dạng văn bản, nâng độ tin cậy chung.</li>
  </ul>

  <div class="section-title" style="margin-top: 1rem;">Phương hướng phát triển</div>
  <ul class="bullet-list">
    <li class="bullet-item">Thử nghiệm trên nhiều loại hóa đơn, từ nhiều nhà cung cấp.</li>
    <li class="bullet-item">Đa dạng độ mờ, góc nghiêng, phông chữ để đánh giá ổn định và tổng quát hóa.</li>
    <li class="bullet-item">Tiếp tục cải thiện hiệu quả trích xuất và quản lý thông tin trong thực tế.</li>
  </ul>
</div>