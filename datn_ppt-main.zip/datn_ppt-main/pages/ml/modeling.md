---
layout: main_contents
---

<Header title="KẾT QUẢ HUẤN LUYỆN MÔ HÌNH DOCUNET" />

<style>
.modeling-container {
  max-width: 1200px;
  margin: 0 2rem;
  padding: 1rem;
  font-family: 'Times New Roman', serif;
}

.section-title {
  font-size: 1.4rem;
  font-weight: bold;
  color: #2c3e50;
  margin: 3rem 0 2rem 0;
  text-align: center;
  border-bottom: 2px solid #34495e;
}

.results-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
  margin-bottom: 3rem;
}

.chart-container {
  background: white;
  border: 1px solid #dee2e6;
  border-radius: 8px;
  padding: 1.5rem;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.chart-title {
  font-size: 1.1rem;
  font-weight: bold;
  color: #495057;
  margin-bottom: 1rem;
  text-align: center;
}

.chart-image {
  width: 110%;
  height: 250px;
  border-radius: 4px;
}

.chart-description {
  font-size: 0.9rem;
  color: #6c757d;
  margin-top: 1rem;
  line-height: 1.5;
  text-align: center;
}

.single-chart {
  grid-column: 1 / -1;
  max-width: 800px;
  margin: 0 auto;
}

.metrics-summary {
  background: #f8f9fa;
  border: 1px solid #dee2e6;
  border-radius: 8px;
  padding: 2rem;
  margin: 2rem 0;
}

.summary-title {
  font-size: 1.2rem;
  font-weight: bold;
  color: #2c3e50;
  margin-bottom: 1rem;
  text-align: center;
}

.metrics-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
}

.metric-item {
  text-align: center;
  padding: 1rem;
  background: white;
  border-radius: 6px;
  border: 1px solid #e9ecef;
}

.metric-label {
  font-size: 0.9rem;
  color: #6c757d;
  margin-bottom: 0.5rem;
}

.metric-value {
  font-size: 1.3rem;
  font-weight: bold;
  color: #2c3e50;
}

@media (max-width: 768px) {
  .results-grid {
    grid-template-columns: 1fr;
  }
  
  .modeling-container {
    padding: 1rem;
  }
}
</style>

<div class="modeling-container">
  <div class="results-grid">
    <div class="chart-container">
      <div class="chart-title">Training và Validation Loss</div>
      <img src="/statics/loss.png" alt="Training and Validation Loss" class="chart-image" />
      <div class="chart-description">Hình 8: Biến đổi của hàm mất mát trên tập Train và Validation</div>
    </div>
    <div class="chart-container">
      <div class="chart-title">Learning Rate Schedule</div>
      <img src="/statics/LR.png" alt="Learning Rate Schedule" class="chart-image" />
      <div class="chart-description">
        Hình 9: Lịch trình learning rate trong quá trình huấn luyện DocUnet.
      </div>
    </div>
  </div>
 </div> 
---
layout: main_contents
---

<Header title="KẾT QUẢ HUẤN LUYỆN MÔ HÌNH PADDLEOCR" />
<div>
  <div class="flex flex-col items-center text-center space-y-4 pt-4">
    <img src="/statics/DocUnetOrNo.png" alt="Detection vs Recognition Comparison" class="max-w-xl border border-gray-300" />
    <div class="max-w-4xl">
      <p class="text-sm italic text-gray-600 text-center">
        Hình 10: So sánh độ chính xác nhận dạng ký tự của PaddleOCR trước và sau khi tiền xử lý.
      </p>
    </div>
  </div>
</div>
