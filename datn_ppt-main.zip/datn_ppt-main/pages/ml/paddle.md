---
layout: main_contents
---

<Header title="CÔNG NGHỆ PADDLEOCR" />

<style>
.paddle-container {
  max-width: 1000px;
  font-family: 'Times New Roman', serif;
}

.pipeline-description {
  font-size: 1.1rem;
  line-height: 1.6;
  color: #34495e;
  text-align: justify;
}


.architecture-section {
  margin-top: 1.5rem;
}

.architecture-title {
  font-size: 1.3rem;
  font-weight: bold;
  color: #2c3e50;
  margin-bottom: 1.5rem;
  text-align: center;
}

.architecture-figure {
  background: white;
  border: 1px solid #dee2e6;
  border-radius: 8px;
  padding: 2rem;
  text-align: center;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.architecture-image {
  width: 100%;
  max-width: 800px;
  height: auto;
  border-radius: 4px;
}

.figure-caption {
  font-size: 0.9rem;
  color: #6c757d;
  margin-top: 0.5rem;
  margin-bottom: 1rem;
  font-style: italic;
  text-align: center;
}

@media (max-width: 768px) {
  .pipeline-steps {
    grid-template-columns: 1fr;
  }
  
  .paddle-container {
    padding: 1rem;
  }
}
</style>

<div class="paddle-container">
  <div class="pipeline-overview">
  </div>
  
  <div class="architecture-section">
    <div class="architecture-figure">
      <img src="/statics/paddle_ocr.png" alt="Kiến trúc hệ thống PP-OCRv5" class="architecture-image" />
      <div class="figure-caption">
        Hình 6: Sơ đồ tổng quan kiến trúc pipeline ba giai đoạn của hệ thống PP-OCRv5 [2]
      </div>
     <div class="pipeline-description">
      PaddleOCR là một thư viện OCR mã nguồn mở, cung cấp các mô hình nhận dạng văn bản mạnh mẽ và dễ tích hợp 
      cho nhiều loại ứng dụng khác nhau.
    </div>
    </div>
  </div>
</div>