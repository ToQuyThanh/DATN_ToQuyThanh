---
layout: main_contents
---

<Header title="CHUẨN BỊ DỮ LIỆU" />

<style>
.academic-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0.5rem;
  font-family: 'Times New Roman', serif;
  line-height: 1.2;
  color: #2c3e50;
}

.section-title {
  font-size: 1.4rem;
  font-weight: bold;
  color: #2c3e50;
  margin: 2rem 0 1.5rem 0;
  text-align: center;
  border-bottom: 2px solid #34495e;
  padding-bottom: 0.5rem;
}

.comparison-table {
  width: 100%;
  border-collapse: collapse;
  margin: 2rem 0;
  font-size: 0.95rem;
  background: white;
  border: 1px solid #dee2e6;
}

.comparison-table th {
  background: #f8f9fa;
  color: #495057;
  padding: 1rem 0.75rem;
  text-align: center;
  font-weight: bold;
  border: 1px solid #dee2e6;
  vertical-align: middle;
}

.comparison-table td {
  padding: 0.6rem;
  border: 1px solid #dee2e6;
  vertical-align: top;
  text-align: left;
}

.comparison-table tr:nth-child(even) {
  background-color: #f8f9fa;
}

.stt-column {
  width: 8%;
  text-align: center;
  font-weight: bold;
}

.attribute-column {
  width: 25%;
  font-weight: bold;
  color: #495057;
}

.dtd-column {
  width: 33.5%;
}

.sroie-column {
  width: 33.5%;
}

.table-description {
  font-size: 1rem;
  color: #495057;
  text-align: justify;
  margin: 1rem 0;
  background: #f8f9fa;
  padding: 1rem;
  border: 1px solid #dee2e6;
}

@media (max-width: 768px) {
  .academic-container {
    padding: 1rem;
  }
  
  .comparison-table {
    font-size: 0.85rem;
  }
  
  .comparison-table th,
  .comparison-table td {
    padding: 0.5rem 0.25rem;
  }
}
</style>

<div class="academic-container">
  <table class="comparison-table">
    <thead>
      <tr>
        <th class="stt-column">STT</th>
        <th class="attribute-column">Thuộc tính</th>
        <th class="dtd-column">Describable Textures Dataset (DTD)</th>
        <th class="sroie-column">SROIE2019v2</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td class="stt-column">1</td>
        <td class="attribute-column">Mục tiêu / Nhiệm vụ</td>
        <td class="dtd-column">Nhận dạng/ phân loại texture (thuộc tính cảm nhận của bề mặt).</td>
        <td class="sroie-column">OCR (nhận diện văn bản) và trích xuất thông tin chính từ hóa đơn/biên lai quét.</td>
      </tr>
      <tr>
        <td class="stt-column">2</td>
        <td class="attribute-column">Số lượng ảnh</td>
        <td class="dtd-column">5,640 ảnh (47 lớp, ~120 ảnh/lớp).</td>
        <td class="sroie-column">Khoảng 1,000 ảnh biên lai toàn trang.</td>
      </tr>
      <tr>
        <td class="stt-column">3</td>
        <td class="attribute-column">Kích thước / Độ phân giải ảnh</td>
        <td class="dtd-column">Kích thước khác nhau, khoảng 300×300 → 640×640; các ảnh chứa ≥90% bề mặt thuộc tính.</td>
        <td class="sroie-column">Ảnh quét toàn trang, nhiều kích thước khác nhau.</td>
      </tr>
      <tr>
        <td class="stt-column">4</td>
        <td class="attribute-column">Ngôn ngữ</td>
        <td class="dtd-column">(hình ảnh texture; không áp dụng ngôn ngữ).</td>
        <td class="sroie-column">Tiếng Anh (text trên hóa đơn chủ yếu là tiếng Anh).</td>
      </tr>
      <tr>
        <td class="stt-column">5</td>
        <td class="attribute-column">Nguồn / Truy cập</td>
        <td class="dtd-column">Bộ dữ liệu gốc từ VGG (University of Oxford).</td>
        <td class="sroie-column">Được tạo cho ICDAR 2019 SROIE challenge.</td>
      </tr>
    </tbody>
  </table>
  <!-- Caption cho bảng -->
  <p class="text-center">
    Bảng 1: Các bộ dữ liệu sử dụng
  </p>

</div>

 
---
layout: main_contents
---

<Header title="Data Engineering (2/3)" />

<style>
  .section-title {
    font-family: "Times New Roman", serif;
    font-size: 1.4rem;
    font-weight: 700;
    color: #222;
    margin-bottom: 0.75rem;
    border-bottom: 1px solid #dee2e6;
    padding-bottom: 0.25rem;
  }
  .section-text {
    font-family: "Times New Roman", serif;
    font-size: 1rem;
    line-height: 1.7;
    color: #333;
    text-align: justify;
    margin-bottom: 0.75rem;
  }
  .bullet-list {
    margin-left: 1rem;
    font-family: "Times New Roman", serif;
    font-size: 1rem;
    line-height: 1.7;
    color: #333;
  }
  .image-grid {
    /* Replaced by single image layout */
  }
  .image-single {
    display: flex;
    justify-content: center;
    margin-top: 0.75rem;
  }
  .image-item {
    max-width: 720px;
    margin: 0 auto;
  }
  .image-item img {
    width: 100%;
    height: auto;
    border: 1px solid #dee2e6;
    background: #fff;
  }
  .image-caption {
    font-family: "Times New Roman", serif;
    font-size: 0.95rem;
    color: #495057;
    text-align: center;
    margin-top: 0.5rem;
  }
  @media (max-width: 768px) {
    .image-item {
      max-width: 100%;
    }
  }
</style>

<div class="academic-container">
  <div class="section-title">2. Gán nhãn dữ liệu</div>
  <p class="section-text">
    Để mô phỏng các vấn đề thường gặp khi quét (scan) hóa đơn, dữ liệu ảnh được gán nhãn dưới dạng
    displacement map nhằm phản ánh biến dạng không gian và các lệch hình học thường gặp.
  </p>

  <div class="image-single">
    <figure class="image-item">
      <img src="/statics/demo_data.png" alt="Minh họa ảnh được tạo bởi thuật toán, ảnh áp dụng bản đồ dịch chuyển và khác biệt">
      <figcaption class="image-caption">Hình 7: Minh họa ảnh được tạo bởi thuật toán, ảnh áp dụng bản đồ dịch chuyển và khác biệt.</figcaption>
    </figure>
  </div>
</div>

---
layout: main_contents
---
<style>
.result-table {
  width: 100%;
  border-collapse: collapse;
  margin: 2rem auto;
  font-size: 0.95rem;
  background: white;
  border: 1px solid #dee2e6;
}

.result-table th {
  background: #f8f9fa;
  color: #495057;
  padding: 1rem 0.75rem;
  text-align: center;
  font-weight: bold;
  border: 1px solid #dee2e6;
  vertical-align: middle;
}

.result-table td {
  padding: 0.6rem;
  border: 1px solid #dee2e6;
  vertical-align: top;
  text-align: left;
}

.result-table tr:nth-child(even) {
  background-color: #f8f9fa;
}

.result-table .highlight-row {
  background-color: #fff3cd !important;
  font-weight: bold;
}

@media (max-width: 768px) {
  .result-table {
    font-size: 0.85rem;
  }
  
  .result-table th,
  .result-table td {
    padding: 0.5rem 0.25rem;
  }
}

.table-caption-2 {
  text-align: center;
  font-size: 0.95rem;
  color: #495057;
  margin-top: 0.5rem;
  margin-bottom: 1.5rem;
}
</style>

<Header title="Kết quả thực nghiệm - Dữ liệu" />
<div class="academic-container">
    <table class="result-table">
      <thead>
        <tr>
          <th>Loại dữ liệu</th>
          <th>Số lượng ảnh</th>
          <th>Tỷ lệ (%)</th>
          <th>Mô tả</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>Dữ liệu gốc</td>
          <td>3,000</td>
          <td>20%</td>
          <td>Thu thập từ 15 cửa hàng bán lẻ</td>
        </tr>
        <tr>
          <td>Sau tăng cường</td>
          <td>15,000</td>
          <td>100%</td>
          <td>Áp dụng các kỹ thuật augmentation</td>
        </tr>
        <tr class="highlight-row">
          <td>Tập huấn luyện</td>
          <td>10,500</td>
          <td>70%</td>
          <td>Dữ liệu để huấn luyện mô hình</td>
        </tr>
        <tr>
          <td>Tập kiểm tra</td>
          <td>2,250</td>
          <td>15%</td>
          <td>Dữ liệu để đánh giá trong quá trình huấn luyện</td>
        </tr>
        <tr>
          <td>Tập thử nghiệm</td>
          <td>2,250</td>
          <td>15%</td>
          <td>Dữ liệu để đánh giá cuối cùng</td>
        </tr>
      </tbody>
    </table>
  <p class="table-caption-2 ">
    Bảng 2: Kết quả thực nghiệm tạo bộ dữ liệu huấn luyện
  </p>
</div>
