---
layout: main_contents
---

<Header title="Ứng dụng Web - Demo Tính năng" />

<style>
  .academic-container {
    max-width: 900px;
    margin: 0 auto;
    padding: 16px;
    font-family: "Times New Roman", serif;
    color: #222;
  }
  .section-title {
    font-size: 1.4rem;
    font-weight: 700;
    margin-bottom: 0.5rem;
    border-bottom: 1px solid #dee2e6;
    padding-bottom: 0.25rem;
  }
  .section-desc {
    font-size: 1rem;
    line-height: 1.7;
    text-align: justify;
    margin-bottom: 0.75rem;
  }
  .feature-list {
    margin-top: 0.25rem;
  }
  .feature-item {
    margin-bottom: 0.5rem;
    font-size: 1rem;
    line-height: 1.7;
  }
  .feature-name {
    font-weight: 600;
  }
</style>

<div class="academic-container">
  <div class="section-title">Phạm vi demo</div>
  <div class="section-desc">
    Trong buổi trình bày, tôi chỉ demo các chức năng cốt lõi của hệ thống nhằm thể hiện luồng xử lý end-to-end từ ảnh hóa đơn đến dữ liệu có cấu trúc.
  </div>
  <ul class="feature-list">
    <li class="feature-item"><span class="feature-name">Upload hóa đơn:</span> Chọn hoặc kéo-thả ảnh hóa đơn vào hệ thống.</li>
    <li class="feature-item"><span class="feature-name">Trích xuất thông tin:</span> Hệ thống nhận diện văn bản và trích xuất các trường chính (tên cửa hàng, ngày, tổng tiền, danh sách sản phẩm...).</li>
    <li class="feature-item"><span class="feature-name">Xem thông tin hóa đơn:</span> Hiển thị chi tiết thông tin đã trích xuất theo cấu trúc bảng, cho phép đối chiếu nhanh với ảnh gốc.</li>
  </ul>

  <div class="section-title" style="margin-top: 1rem;">Liên kết giao diện ứng dụng</div>
  <div class="section-desc">
    Truy cập giao diện ứng dụng tại: 
    <a href="http://localhost:3000/" target="_blank" rel="noopener">http://localhost:3000/</a>
  </div>
</div>