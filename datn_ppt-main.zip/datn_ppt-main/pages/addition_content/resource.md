---
layout: default
class: 'text-left'
---

# Tài liệu tham khảo
1.  Junren Chen, Rui Chen, Wei Wang, Junlong Cheng, Lei Zhang và Liangyin Chen. “TinyU-Net: Lighter yet better U-Net with cascaded multi-receptive fields”. MICCAI 2024 - Medical Image Computing and Computer-Assisted Intervention, 2024. https://doi.org/10.1007/978-3-031-72114-4_60

2.  C. Cui, T. Sun, M. Lin, T. Gao, Y. Zhang, J. Liu, X. Wang, Z. Zhang, C. Zhou, H. Liu, Y. Zhang, W. Lv, K. Huang, Y. Zhang, J. Zhang, J. Liu, Y. Yu và Y. Ma, “PaddleOCR 3.0 Technical Report“, arXiv, 2025. https://doi.org/10.48550/ARXIV.2507.05595.
