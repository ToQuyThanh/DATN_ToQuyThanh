---
layout: main_contents_2cols
---

<Header title="MỤC TIÊU VÀ PHẠM VI" />

<style>
.objective-section {
  @apply mb-2;
}

.objective-list {
  @apply list-disc list-inside space-y-3 text-gray-800;
}

.scope-section {
  @apply border-t pt-6;
}

.input-output-box {
  @apply border rounded p-4 bg-gray-50 mt-6;
}
</style>

<div class="pr-8 pt-4">
  <div class="objective-section">
    <h2 class="text-xl font-bold mb-4 text-gray-800">
      Mục tiêu
    </h2>
    <ul class="objective-list">
      <li>Xây dựng hệ thống trích xuất tự động từ ảnh hóa đơn</li>
      <li>Áp dụng DocUnet + PaddleOCR</li>
      <li>Phát triển ứng dụng web thực tế</li>
    </ul>
  </div>
  <div class="scope-section">
    <h3 class="text-xl font-bold mb-4 text-gray-800">
      Phạm vi
    </h3>
    <ul class="objective-list">
      <li>Hóa đơn bán lẻ tại Việt Nam</li>
      <li>Xử lý ảnh chụp/scan (méo, nghiêng, mờ)</li>
      <li>Hỗ trợ tiếng Việt có dấu</li>
    </ul>
  </div>
</div>
<div class="">
  <figure class="mt-3">
    <img src="/statics/invoice_10_512_preprocessed_img.jpg" alt="Demo Input → Output" class="rounded border" />
    <figcaption class="text-center text-sm text-gray-600 mt-2">
      Hình 2: Xử lí cong, gập, méo trên hóa đơn
    </figcaption>
  </figure>
  <figure class="mt-3">
    <img src="/statics/invoice_10_512_ocr_res_img.jpg" alt="Demo Input → Output" class="rounded border" />
    <figcaption class="text-center text-sm text-gray-600 mt-2">
      Hình 3: Nhận diện văn bản trên hóa đơn
    </figcaption>
  </figure>
</div>