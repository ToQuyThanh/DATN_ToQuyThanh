---
transition: fade-out
layout: main_contents
---

<Header title="Nội dung" />

<!-- CSS animation nằm ngay trong slide để chắc chắn được load -->
<style>
@keyframes fadeInUp {
  from { opacity: 0; transform: translateY(16px); }
  to   { opacity: 1; transform: translateY(0); }
}

/* item khởi tạo ở trạng thái invisibile và sẽ chạy animation */
.fade-item {
  opacity: 0;
  transform: translateY(16px);
  animation-name: fadeInUp;
  animation-duration: 0.64s;
  animation-fill-mode: forwards;
  animation-timing-function: cubic-bezier(.2,.9,.2,1);
  will-change: opacity, transform;
}

/* delays tuần tự (tăng dần) */
.delay-1 { animation-delay: 0.08s; }
.delay-2 { animation-delay: 0.26s; }
.delay-3 { animation-delay: 0.44s; }
.delay-4 { animation-delay: 0.62s; }
.delay-5 { animation-delay: 0.80s; }

/* tôn trọng reduced-motion */
@media (prefers-reduced-motion: reduce) {
  .fade-item { animation: none !important; opacity: 1 !important; transform: none !important; }
}
</style>

<div class="flex flex-col space-y-4 mt-8 px-8">
  <!-- Item 2 -->
  <div class="flex items-center space-x-4 fade-item delay-2">
    <div class="w-8 h-8 flex items-center justify-center rounded-full bg-blue-600 text-white font-bold">
      1
    </div>
    <span class="text-lg text-gray-700">TỔNG QUAN VỀ BÀI TOÁN</span>
  </div>

  <!-- Item 3 -->
  <div class="flex items-center space-x-4 fade-item delay-3">
    <div class="w-8 h-8 flex items-center justify-center rounded-full bg-blue-600 text-white font-bold">
      2
    </div>
    <span class="text-lg text-gray-700">GIẢI PHÁP VÀ KẾT QUẢ THỰC NGHIỆM</span>
  </div>

  <!-- Item 4 -->
  <div class="flex items-center space-x-4 fade-item delay-4">
    <div class="w-8 h-8 flex items-center justify-center rounded-full bg-blue-600 text-white font-bold">
      3
    </div>
    <span class="text-lg text-gray-700">ỨNG DỤNG MINH HỌA</span>
  </div>

  <!-- Item 5 -->
  <div class="flex items-center space-x-4 fade-item delay-5">
    <div class="w-8 h-8 flex items-center justify-center rounded-full bg-blue-600 text-white font-bold">
      4
    </div>
    <span class="text-lg text-gray-700">PHẦN KẾT LUẬN VÀ PHƯƠNG HƯỚNG PHÁT TRIỂN</span>
  </div>
</div>
