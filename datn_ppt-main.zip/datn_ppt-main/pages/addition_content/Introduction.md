---
layout: main_contents_2cols
---

<Header title="GIỚI THIỆU BÀI TOÁN" />

<style>
.academic-section {
  @apply mb-8;
}

.academic-list {
  @apply list-disc list-inside space-y-3 text-gray-800;
}

.academic-list li {
  @apply leading-relaxed;
}

.solution-section {
  @apply border-t pt-6 mt-8;
}

.image-container {
  @apply border rounded p-4 bg-gray-50;
}

/* Fast, subtle fade-in for click-to-reveal */
.fade-fast-enter-active,
.fade-fast-leave-active {
  transition: opacity 180ms ease-out, transform 180ms ease-out;
}
.fade-fast-enter-from,
.fade-fast-leave-to {
  opacity: 0;
  transform: translateY(4px);
}
.fade-fast-enter-to,
.fade-fast-leave-from {
  opacity: 1;
  transform: translateY(0);
}
</style>
<div class="pr-8 mt-8">
  <Transition name="fade-fast">
    <div v-click>
      <h2 class="text-xl font-bold mb-6 text-gray-800">
        Vấn đề thực tế
      </h2>
      <ul class="academic-list text-lg">
        <li>Xử lý hóa đơn thủ công tốn thời gian</li>
        <li>Tỷ lệ sai sót cao (30-40%)</li>
        <li>Chi phí nhân công lớn</li>
        <li>Khó tra cứu, thống kê</li>
      </ul>
    </div>
  </Transition>
  <Transition name="fade-fast">
    <div class="solution-section" v-click>
      <h3 class="text-xl font-bold mb-4 text-gray-800">
        Giải pháp
      </h3>
      <p class="text-lg text-gray-700">
        Tự động hóa bằng AI/Machine Learning: Phát triển hệ thống trích xuất thông tin hóa đơn 
        sử dụng DocUNET + PaddleOCR
      </p>
    </div>
  </Transition>
</div>
<div class="mt-8">
  <Transition name="fade-fast">
    <div class="image-container" v-click>
      <img src="/statics/nvnl.png" alt="Xử lý hóa đơn thủ công" class="w-full rounded" />
      <p class="text-gray-700 text-md text-center">
        Hình 1: Văn phòng nhập liệu tại một công ty
      </p>
      <p class="text-gray-700 text-sm text-center">
        Hình ảnh chỉ mang tính chất minh họa
      </p>
    </div>
  </Transition>
</div>