---
layout: main_contents
---

<Header title="Kết quả và Đánh giá (2/3)" />

<div class="h-full flex flex-col items-center justify-center p-4"> <!-- Giảm padding tổng thể xuống p-4 -->
  <h2 class="text-3xl font-bold mb-6 text-center text-indigo-700">So sánh với các mô hình khác</h2> <!-- Giảm kích thước h2, mb -->

  <div class="w-[95%] mx-auto bg-white rounded-lg shadow-md overflow-hidden"> <!-- Tăng chiều rộng bảng, nền trắng -->
    <table class="w-full text-left table-auto">
      <thead>
        <tr class="bg-blue-100 text-blue-800 text-lg"> <!-- Giảm kích thước chữ header -->
          <th class="p-3 border-b-2 border-blue-200">Mô hình</th> <!-- Giảm padding -->
          <th class="p-3 border-b-2 border-blue-200">Đặc điểm chính</th>
          <th class="p-3 border-b-2 border-blue-200">Ưu điểm</th>
          <th class="p-3 border-b-2 border-blue-200">Nhược điểm</th>
        </tr>
      </thead>
      <tbody>
        <tr class="bg-white hover:bg-gray-50">
          <td class="p-3 border-b border-gray-200 text-base font-semibold">DocUnet Cải tiến</td> <!-- Giảm kích thước chữ -->
          <td class="p-3 border-b border-gray-200 text-base">Cấu trúc Unet tối ưu, ít tham số</td>
          <td class="p-3 border-b border-gray-200 text-base">Kích thước nhỏ (2MB), real-time, triển khai nhẹ</td>
          <td class="p-3 border-b border-gray-200 text-base">Có thể chưa đạt độ chính xác tuyệt đối với dữ liệu phức tạp</td>
        </tr>
        <tr class="bg-white hover:bg-gray-50">
          <td class="p-3 border-b border-gray-200 text-base font-semibold">PaddleOCR v5</td>
          <td class="p-3 border-b border-gray-200 text-base">Hỗ trợ đa ngôn ngữ, phát hiện layout mạnh mẽ</td>
          <td class="p-3 border-b border-gray-200 text-base">Nhận diện layout tốt, tốc độ xử lý nhanh</td>
          <td class="p-3 border-b border-gray-200 text-base">Độ chính xác tiếng Việt còn hạn chế, cần fine-tuning sâu</td>
        </tr>
        <tr class="bg-white hover:bg-gray-50">
          <td class="p-3 border-b border-gray-200 text-base font-semibold">Mô hình A (Tham khảo)</td>
          <td class="p-3 border-b border-gray-200 text-base">[Đặc điểm của mô hình tham khảo A]</td>
          <td class="p-3 border-b border-gray-200 text-base">[Ưu điểm của mô hình A]</td>
          <td class="p-3 border-b border-gray-200 text-base">[Nhược điểm của mô hình A]</td>
        </tr>
        <tr class="bg-white hover:bg-gray-50">
          <td class="p-3 border-b border-gray-200 text-base font-semibold">Mô hình B (Tham khảo)</td>
          <td class="p-3 border-b border-gray-200 text-base">[Đặc điểm của mô hình tham khảo B]</td>
          <td class="p-3 border-b border-gray-200 text-base">[Ưu điểm của mô hình B]</td>
          <td class="p-3 border-b border-gray-200 text-base">[Nhược điểm của mô hình B]</td>
        </tr>
      </tbody>
    </table>
  </div>
  <p class="mt-6 text-center text-sm text-gray-600 max-w-3xl mx-auto"> <!-- Giảm mt, kích thước chữ, giới hạn chiều rộng -->
    Bảng so sánh này giúp thấy rõ vị thế và lợi thế cạnh tranh của các giải pháp đề xuất.
  </p>
</div>

---
layout: main_contents
---

<Header title="Kết quả và Đánh giá (3/3)" />

<div class="h-full flex p-4"> <!-- Giảm padding tổng thể xuống p-4 -->
  <!-- Cột bên trái: Điểm mạnh -->
  <div class="w-1/2 p-3 flex flex-col justify-center bg-green-50 rounded-lg shadow-md mr-3"> <!-- Giảm padding cột và mr -->
    <h3 class="text-2xl font-bold mb-3 text-green-800">Điểm mạnh</h3> <!-- Giảm kích thước h3, mb -->
    <ul class="list-disc list-inside ml-3 text-base leading-relaxed"> <!-- Giảm thụt lề và kích thước chữ -->
      <li>Tối ưu hiệu suất: Mô hình DocUnet cải tiến nhỏ gọn, tốc độ xử lý cao, phù hợp real-time.</li>
      <li>Hỗ trợ tiếng Việt: PaddleOCR v5 được fine-tune, nhận diện layout hóa đơn tiếng Việt tốt.</li>
      <li>Quy trình rõ ràng: Các bước từ thu thập, gán nhãn đến tiền xử lý và mô hình hóa được định nghĩa rõ ràng.</li>
      <li>Tính mở rộng: Kiến trúc cho phép dễ dàng tích hợp các cải tiến trong tương lai.</li>
    </ul>
  </div>

  <!-- Cột bên phải: Điểm yếu -->
  <div class="w-1/2 p-3 flex flex-col justify-center bg-red-50 rounded-lg shadow-md ml-3"> <!-- Giảm padding cột và ml -->
    <h3 class="text-2xl font-bold mb-3 text-red-800">Điểm yếu</h3> <!-- Giảm kích thước h3, mb -->
    <ul class="list-disc list-inside ml-3 text-base leading-relaxed"> <!-- Giảm thụt lề và kích thước chữ -->
      <li>Độ chính xác tiếng Việt: Dù đã fine-tune, việc nhận diện ký tự tiếng Việt đặc biệt vẫn còn thách thức.</li>
      <li>Dữ liệu đa dạng hóa đơn: Cần bổ sung thêm dữ liệu hóa đơn đa dạng hơn để tăng cường robustness.</li>
      <li>Chi phí fine-tuning: Quá trình fine-tuning cho ngôn ngữ đặc thù đòi hỏi nguồn lực tính toán và thời gian.</li>
    </ul>
  </div>
</div>