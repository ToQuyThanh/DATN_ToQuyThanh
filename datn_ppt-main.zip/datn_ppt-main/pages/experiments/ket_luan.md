---
layout: main_contents
---

<Header title="Kết luận" />

<div class="h-full flex flex-col items-center justify-center p-4 text-center"> <!-- Giảm padding tổng thể xuống p-4 -->
  <h2 class="text-3xl font-bold text-blue-700 mb-4"> <!-- Giảm kích thước h2, mb -->
    Tổng kết những thành tựu chính của dự án
  </h2>

  <div class="max-w-3xl text-base leading-relaxed text-gray-800"> <!-- Giảm kích thước chữ xuống text-base -->
    <p class="mb-3"> <!-- Giảm mb -->
      Giải pháp MLOps Pipeline cho việc trích xuất thông tin hóa đơn đã đạt được những kết quả đáng kể.
      Chúng tôi đã cải thiện hiệu suất mô hình DocUnet, giảm kích thước mô hình,
      tăng cường khả năng xử lý theo thời gian thực và tối ưu hóa quy trình từ dữ liệu đến triển khai.
    </p>
    <p>
      Dự án đã mang lại một hệ thống mạnh mẽ và hiệu quả, giải quyết các thách thức trong việc xử lý hóa đơn,
      đặc biệt với dữ liệu tiếng Việt, tạo tiền đề cho các ứng dụng thực tế trong tự động hóa quy trình nghiệp vụ.
    </p>
  </div>
</div>

---
layout: main_contents
---

<Header title="Phương hướng phát triển" />

<div class="h-full flex flex-col items-center justify-center p-4"> <!-- Giảm padding tổng thể xuống p-4 -->
  <h2 class="text-3xl font-bold text-purple-700 mb-8 text-center"> <!-- Giảm kích thước h2, mb -->
    Định hướng mở rộng và cải tiến trong tương lai
  </h2>

  <div class="flex items-start  w-full max-w-4xl"> <!-- Giảm mb -->
    <p class="text-base leading-relaxed"> <!-- Giảm kích thước chữ xuống text-base -->
      Mở rộng phạm vi dữ liệu: Tích hợp thêm các loại hóa đơn đa dạng hơn, từ nhiều nguồn khác nhau để tăng cường khả năng tổng quát của mô hình.
    </p>
  </div>

  <div class="flex items-start  w-full max-w-4xl"> <!-- Giảm mb -->
    <p class="text-base leading-relaxed">
      Cải thiện độ chính xác tiếng Việt: Nghiên cứu sâu hơn về các kỹ thuật fine-tuning tiên tiến hoặc tích hợp mô hình OCR chuyên biệt cho tiếng Việt để đạt độ chính xác cao hơn.
    </p>
  </div>

  <div class="flex items-start  w-full max-w-4xl"> <!-- Giảm mb -->
    <p class="text-base leading-relaxed">
      Tích hợp học tăng cường (Reinforcement Learning): Khám phá việc áp dụng RL để tối ưu hóa các quyết định trong pipeline, ví dụ như lựa chọn mô hình động hoặc tự động điều chỉnh tham số.
    </p>
  </div>

  <div class="flex items-start w-full max-w-4xl">
    <p class="text-base leading-relaxed">
      Phát triển giao diện người dùng (UI/UX) thân thiện: Xây dựng một giao diện trực quan để người dùng cuối dễ dàng tương tác, theo dõi và quản lý quy trình.
    </p>
  </div>
</div>  