<template>
  <div class="slidev-layout default p-10 h-full flex items-center justify-center">
    <slot />
  </div>
</template>