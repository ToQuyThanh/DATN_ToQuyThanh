<template>
  <div class="slidev-layout default bg-gray-50 p-10 h-full flex flex-col items-center justify-center">
    <slot />
  </div>
</template>```
