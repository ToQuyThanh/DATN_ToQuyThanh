<template>
  <div class="slidev-layout default bg-white pt-16 px-6">
    <slot />
  </div>

  <div class="absolute bottom-2 left-0 right-0 px-6">
    <div class="flex items-center">
      <!-- Logo -->
      <img src="/statics/logo_haui.png" alt="Logo trường" class="h-6 mr-4" />
      
      <!-- Tên trường -->
      <span class="text-sm text-gray-600 font-small mr-4">
        Trường Đại học Công Nghiệp Hà Nội
      </span>
      
      <!-- Line kéo hết phần còn lại -->
      <div class="border-t-2 border-blue-600 flex-grow"></div>
    </div>
  </div>
</template>